require('../../common/welcome')('bootstrap5')
