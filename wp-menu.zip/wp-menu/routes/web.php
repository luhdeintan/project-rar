<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\MenuController;
use App\Http\Controllers\MejaController;
use App\Http\Controllers\KodeController;
use App\Http\Controllers\KategoriController;
use App\Http\Controllers\KasirController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\AksesController;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\InfoController;
use App\Http\Controllers\PesananController;
use App\Http\Controllers\ScannerController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//----------------------------------------
// User akan menggunakan auth kedepannya
//----------------------------------------



//logout
Route::get('/logout', [LoginController::class, 'logout']);
Route::get('/signout', [AksesController::class, 'signout']);


//untuk yang middlewarenya guest, dijadikan satu semua di sini biar rapi codenya
Route::middleware('guest')->group(function () {
    //login pegunjung
    Route::get('/', [AksesController::class, 'index']);
    Route::post('/', [AksesController::class, 'makeSession']);
    Route::get('/scanner', [ScannerController::class, 'index']);
    //untuk login
    Route::get('/login', [LoginController::class, 'index'])->name('login');
    Route::post('/login', [LoginController::class, 'authenticate']);
});



//untuk yang middlewarenya akses, dijadikan satu semua di sini biar rapi codenya
Route::middleware('auth:akses')->group(function () {
    //Pelanggan
    Route::get('/welcome', [MenuController::class, 'welcome']);
    // Route::get('/detailmenu/{id}', [MenuController::class, 'detailMenu']);
    Route::get('/kategorimenu', [MenuController::class, 'kategori']);

    Route::resource('detailmenu', PesananController::class)->except('creat', 'index');
    Route::get('/keranjang', [PesananController::class, 'keranjang']);

    // confirm cancle
    Route::post('/confirmcancle/{id}', [PesananController::class, 'confirmCancle']);

    //switch status
    Route::post('/pesan', [PesananController::class, 'statusSwitch']);

    //status pesanan
    Route::get('/detail-pesanan', [InfoController::class, 'detailPesanan']);
});



//untuk yang middlewarenya auth, dijadikan satu semua biar rapi codenya
Route::middleware('auth')->group(function () {
    Route::get('/dashboard-admin', [LoginController::class, 'adminDashboard']);
    Route::get('/dashboard', [InfoController::class, 'dashboardList']);

    //profile update
    Route::get('/profile', [LoginController::class, 'show']);
    Route::get('/profileupdate', [LoginController::class, 'showKasir']);

    Route::put('/profile/{id}', [LoginController::class, 'profileAdmin']);
    Route::put('/profileupdate/{id}', [LoginController::class, 'profileKasir'])->name('profile.kasir');

    //admin
    Route::resource('menu', MenuController::class);
    Route::resource('qrcode', KodeController::class)->except('creat', 'show', 'edit' ); //kasir dan admin
    Route::get('/print/{id}', [KodeController::class, 'print']);

    Route::resource('meja', MejaController::class)->except('show', 'create', 'edit');
    Route::resource('kategori', KategoriController::class)->except('admin', 'create', 'edit');
    Route::resource('kasir', KasirController::class);
    Route::resource('admin', AdminController::class);
    // belum di cek tapi udah jadi
    Route::get('/history-penjualan', [InfoController::class, 'historySale']);
    Route::put('/historypenjualan/{id}', [InfoController::class, 'historyDelete']);

    //kasir
    Route::post('/add-process', [InfoController::class, 'addProcess']);

    Route::get('/process', [InfoController::class, 'indexProcess']);
    Route::post('/process', [InfoController::class, 'finishProcess']);
    Route::put('/process/{id}', [InfoController::class, 'canceledProcess']);

    Route::get('/menus', [MenuController::class, 'index']);
    Route::post('/statuschange/{id}', [MenuController::class, 'statusMenuChange']);

    Route::get('/history', [InfoController::class, 'history']);
});

