<?php echo $__env->make('partials.navkasir', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('container'); ?>
<div class="container">
    <div class="d-flex flex-column align-items-stretch flex-shrink-0 bg-white mt-4">
        <a href="/" class="d-flex align-items-center flex-shrink-0 p-3 link-dark text-decoration-none">
            <span class="fs-5 fw-semibold"><i class="bi bi-clock-history"></i> Process</span>
        </a>
        <nav class="border-bottom" style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">Process</li>
                <li class="breadcrumb-item active" aria-current="page">Order Process List</li>
            </ol>
        </nav>

        <div class="my-3 p-3 bg-body rounded shadow-sm">
            <?php if(session()->has('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong>Berhasil!</strong> <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            <?php endif; ?>

            <?php if(!$pesanan->count()): ?>
            <div class="alert alert-warning alert-dismissible fade show" role="alert">
                <strong>Pesanan kosong.</strong> Data pesanan pelanggan belum tersedia saat ini.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            <?php else: ?>
            <h6 class="border-bottom pb-2 mb-0">Order List</h6>
            <?php $__currentLoopData = $pesanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pesan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="d-flex text-muted pt-3">
                <input type="hidden" name="id_pesan" value="<?php echo e($pesan->id); ?>">
                <button class="btn btn-success text-center" type="button" data-bs-toggle="modal"
                    data-bs-target="#finish<?php echo e($pesan->id); ?>" data-bs-toggle="tooltip" data-bs-placement="top"
                    title="finish" style="height:32; width:32; padding:0; margin-right:8"><i class="bi bi-plus-lg"
                        style="margin: auto"></i></button>
                
                <div class="modal fade" id="finish<?php echo e($pesan->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel"
                    aria-hidden="true">
                    <form action="/process" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id_pesan" value="<?php echo e($pesan->id); ?>">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Ready</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                        aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    Ubah menjadi status "Ready" pesanan <?php echo e($pesan->menu); ?> ?
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button>

                                    <button type="submit" class="btn btn-Success">Ready</button>

                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="pb-3 mb-0 small lh-sm border-bottom w-100">
                    <div class="d-flex justify-content-between mb-2">
                        <strong class="text-dark"><?php echo e($pesan->menu); ?>

                            <span class="badge rounded-pill bg-secondary"><?php echo e($pesan->quantity); ?></span>
                            <?php if($pesan->note != 'none'): ?>
                            <span
                                class="strong d-inline px-3 badge <?php echo e($pesan->note == "Hot" ? "bg-danger" : "bg-primary"); ?>"><?php echo e($pesan->note); ?></span>
                            <?php endif; ?>
                        </strong>
                        <a href="#" class="text-danger" data-bs-toggle="modal"
                            data-bs-target="#exampleModal<?php echo e($pesan->id); ?>" data-bs-toggle="tooltip"
                            data-bs-placement="top">Cancle</a>

                        
                        <div class="modal fade" id="exampleModal<?php echo e($pesan->id); ?>" tabindex="-1"
                            aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <form action="/process/<?php echo e($pesan->id); ?>" method="post">
                                <?php echo method_field('put'); ?>
                                <?php echo csrf_field(); ?>
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="exampleModalLabel">Batalkan Pesanan?</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            Berikan konfirmasi Anda mengapa membatalkan
                                            <strong><?php echo e($pesan->menu); ?></strong> : <br>
                                            <div class="form-group mt-2">
                                                
                                                <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"
                                                    name="message">menu habis</textarea>
                                                <small class="text-danger">*wajib mengisi</small>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-light"
                                                data-bs-dismiss="modal">Close</button>
                                            <button type="submit" class="btn btn-danger">Send</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>

                    </div>
                    <span class="d-block">Time : <span><?php echo e($pesan->updated_at->format('g:i a')); ?></span> | <span>Meja
                            <?php echo e($pesan->kode->meja->no_meja); ?> <i class="bi bi-dash-lg"></i>
                            <?php echo e($pesan->kode->meja->lokasi); ?></span></span>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\di sini\Pejuang Skripsi\Laravel 8\apps\wp-24-01-2022\wp-menu\resources\views/kasir/process.blade.php ENDPATH**/ ?>