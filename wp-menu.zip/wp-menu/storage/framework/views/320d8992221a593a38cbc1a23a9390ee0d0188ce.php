

<?php echo $__env->make('partials.navadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('container'); ?>
<div class="container">
    <div class="d-flex flex-column align-items-stretch flex-shrink-0 bg-white mt-4">
        <a href="/dashboard-admin" class="d-flex align-items-center flex-shrink-0 p-3 link-dark text-decoration-none">
            <span class="fs-5 fw-semibold"><i class="bi bi-person-workspace fs-3"></i> Admin</span>
        </a>
        <nav class="border-bottom" style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">Admin</li>
                <li class="breadcrumb-item active" aria-current="page">Data Admin</li>
            </ol>
        </nav>
    </div>
    <table class="table">
        <thead class="table-dark">
            <tr>
                <th>No.</th>
                <th>Nama</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>1</td>
                <td>Intania Mentari Mustika</td>
                <td>
                    <a href="/data-admin/nama-admin" class="text-decoration-none"><button type="button"
                            class="btn btn-primary" data-bs-toggle="tooltip" data-bs-placement="top" title="see"><i
                                class="bi bi-eye"></i></button></a>
                    <a href="/data-admin/edit/nama-admin" class="text-decoration-none"><button type="button"
                            class="btn btn-success" data-bs-toggle="tooltip" data-bs-placement="top" title="edit"><i
                                class="bi bi-pencil"></i></button></a>
                    <a href="#" class="text-decoration-none"><button type="button" class="btn btn-danger"
                            data-bs-toggle="tooltip" data-bs-placement="top" title="delete"><i class="bi bi-trash" data-bs-toggle="modal"
                            data-bs-target="#exampleModal"></i></button></a>
                    
                    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel"
                        aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Hapus</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                        aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    Data yang dihapus tidak dapat diakses kembali. <br> Yakin akan menghapus?
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary"
                                        data-bs-dismiss="modal">Close</button>
                                    <button type="button" class="btn btn-danger">Hapus</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </td>
            </tr>
        </tbody>
    </table>
</div>

<script>
    var myModal = document.getElementById('myModal')
    var myInput = document.getElementById('myInput')

    myModal.addEventListener('shown.bs.modal', function () {
        myInput.focus()
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Punya SAYA\di sini\Pejuang Skripsi\Laravel 8\applications\wp-menu\resources\views/admin/pegawai/admin.blade.php ENDPATH**/ ?>