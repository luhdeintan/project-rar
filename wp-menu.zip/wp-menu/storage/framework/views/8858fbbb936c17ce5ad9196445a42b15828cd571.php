

<?php echo $__env->make('partials.navkasir', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('container'); ?>
<div class="container">
    <div class="d-flex flex-column align-items-stretch flex-shrink-0 bg-white mt-4">
        <a href="/" class="d-flex align-items-center flex-shrink-0 p-3 link-dark text-decoration-none">
            <span class="fs-5 fw-semibold"><i class="bi bi-clock fs-3"></i> History</span>
        </a>
        <nav class="border-bottom" style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">History</li>
                <li class="breadcrumb-item active" aria-current="page">History list</li>
            </ol>
        </nav>
    </div>
</div>

<div class="container pt-4">

        <a class="text-decoration-none" href="/history/cook">
            <div class="card bg-warning mb-3 mx-auto text-dark col" style="max-width: 30rem;">
                <div class="card-header">Cook</div>
                <div class="card-body">
                    <p class="bi bi-egg-fill fs-1"></p>
                    <h5 class="card-title">Pesanan sedang dibuat</h5>
                    <p class="card-text">Cek daftar pesanan yang masih dalam tahap pembuatan</p>
                </div>
            </div>
        </a>
        <a class="text-decoration-none" href="/history/ready">
            <div class="card bg-success mb-3 mx-auto text-light col" style="max-width: 30rem;">
                <div class="card-header">Ready</div>
                <div class="card-body">
                    <p class="bi bi-patch-check-fill fs-1"></p>
                    <h5 class="card-title">Pesanan telah dihidangkan</h5>
                    <p class="card-text">Lihat riwayat pesanan yang sudah dilakukan hari ini</p>
                </div>
            </div>
        </a>


</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Punya SAYA\di sini\Pejuang Skripsi\Laravel 8\applications\wp-menu\resources\views/kasir/history-pesanan.blade.php ENDPATH**/ ?>