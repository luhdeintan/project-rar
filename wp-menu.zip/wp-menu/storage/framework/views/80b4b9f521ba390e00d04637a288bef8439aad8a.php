

<?php echo $__env->make('partials.navuser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('container'); ?>
<main class="container">
    <div class="p-4 p-md-5 mb-4 text-white rounded bg-dark">
        <div class="col-md-10 px-0">
            <h1 class="display-4 fst-italic">Relax and Enjoy!</h1>
            <p class="lead my-3">Pilihan menu menarik untuk menemani waktumu bersantai! Berbagai varian minuman dan
                snack yang beragam untuk melengkapi hari-harimu yang penuh warna.</p>
            <p class="lead mb-0 text-white fw-bold">#menu #coffe #drink #snack</p>
        </div>
    </div>
    <h3 class="mx-3">Espresso</h3>
    <hr>
    <div class="row mb-2 justify-content-center mb-6">
        
        <div class="card px-0 my-3 mx-4 justify-content-center" style="width: 18rem;">
            <img src="https://source.unsplash.com/1200x600?coffee-milk" class="card-img-top" alt="...">
            <div class="card-body">
                <h3 class="mb-0">Espresso Milk</h3>
                <div class="mb-1 text-muted">Espresso dengan tambahan susu</div>
                <strong class="d-inline-block mb-2 text-success">Rp 20.000</strong><br>
                <a href="/menu/single-menu" class="stretched-link">Detail menu</a>
            </div>
        </div>
        
        <div class="card px-0 my-3 mx-4 justify-content-center" style="width: 18rem;">
            <img src="https://source.unsplash.com/1200x600?milk" class="card-img-top" alt="...">
            <div class="card-body">
                <h3 class="mb-0">Espresso Milk</h3>
                <div class="mb-1 text-muted">Espresso dengan tambahan susu</div>
                <strong class="d-inline-block mb-2 text-success">Rp 20.000</strong><br>
                <a href="/menu/single-menu" class="stretched-link">Detail menu</a>
            </div>
        </div>
        
        <div class="card px-0 my-3 mx-4 justify-content-center" style="width: 18rem;">
            <img src="https://source.unsplash.com/1200x600?greentea" class="card-img-top" alt="...">
            <div class="card-body">
                <h3 class="mb-0">Espresso Milk</h3>
                <div class="mb-1 text-muted">Espresso dengan tambahan susu</div>
                <strong class="d-inline-block mb-2 text-success">Rp 20.000</strong><br>
                <a href="/menu/single-menu" class="stretched-link">Detail menu</a>
            </div>
        </div>
        
        <div class="card px-0 my-3 mx-4 justify-content-center" style="width: 18rem;">
            <img src="https://source.unsplash.com/1200x600?greentea" class="card-img-top" alt="...">
            <div class="card-body">
                <h3 class="mb-0">Espresso Milk</h3>
                <div class="mb-1 text-muted">Espresso dengan tambahan susu</div>
                <strong class="d-inline-block mb-2 text-success">Rp 20.000</strong><br>
                <a href="/menu/single-menu" class="stretched-link">Detail menu</a>
            </div>
        </div>
    </div>



    <h3 class="mx-3">Arabika</h3>
    <hr>
    <div class="row mb-2 justify-content-center mb-6">
        
        <div class="card px-0 my-3 mx-4" style="width: 18rem;">
            <img src="https://source.unsplash.com/1200x600?coffee" class="card-img-top" alt="...">
            <div class="card-body">
                <h3 class="mb-0">Espresso Milk</h3>
                <div class="mb-1 text-muted">Espresso dengan tambahan susu</div>
                <strong class="d-inline-block mb-2 text-success">Rp 20.000</strong><br>
                <a href="/menu/single-menu" class="stretched-link">Detail menu</a>
            </div>
        </div>
        
        <div class="card px-0 my-3 mx-4" style="width: 18rem;">
            <img src="https://source.unsplash.com/1200x600?espresso" class="card-img-top" alt="...">
            <div class="card-body">
                <h3 class="mb-0">Espresso Milk</h3>
                <div class="mb-1 text-muted">Espresso dengan tambahan susu</div>
                <strong class="d-inline-block mb-2 text-success">Rp 20.000</strong><br>
                <a href="/menu/single-menu" class="stretched-link">Detail menu</a>
            </div>
        </div>
        
        <div class="card px-0 my-3 mx-4" style="width: 18rem;">
            <img src="https://source.unsplash.com/1200x600?arabika" class="card-img-top" alt="...">
            <div class="card-body">
                <h3 class="mb-0">Espresso Milk</h3>
                <div class="mb-1 text-muted">Espresso dengan tambahan susu</div>
                <strong class="d-inline-block mb-2 text-success">Rp 20.000</strong><br>
                <a href="/menu/single-menu" class="stretched-link">Detail menu</a>
            </div>
        </div>
    </div>
</main>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Punya SAYA\di sini\Pejuang Skripsi\Laravel 8\applications\wp-menu\resources\views/menu.blade.php ENDPATH**/ ?>