<div class="container">
  <header class="blog-header py-3">
    <div class="row flex-nowrap justify-content-between align-items-center">
      <div class="col-8">
        <a class="blog-header-logo text-dark text-decoration-none fs-2 font-weight-bold" href="/menu">Warung Pejalan</a>
      </div>
      <div class="col-4 d-flex justify-content-end align-items-center">
        <?php echo csrf_field(); ?>
        <form action="/signout" method="get" class="d-flex my-auto">
            <button class="btn btn-sm btn-outline-secondary" type="submit" href="/">Sign out</button>
        </form>
      </div>
    </div>
  </header>

  
  <div class="nav-scrollerpy-1 mb-2">
    <nav class="nav d-flex justify-content-center">
      <a class="px-3 py-2 fw-bold nav-link text-dark <?php echo e($active == 'menu' ? 'active text-decoration-underline' : 'text-decoration-none'); ?>"  href="/welcome">Menu</a>
      <a class="px-3 py-2 fw-bold nav-link text-dark  <?php echo e($active == 'kategori' ? 'active text-decoration-underline' : 'text-decoration-none'); ?>" href="/kategorimenu">Kategori</a>
      <a class="px-3 py-2 fw-bold nav-link text-dark  <?php echo e($active == 'keranjang' ? 'active text-decoration-underline' : 'text-decoration-none'); ?>" href="/keranjang">Keranjang</a>
      <a class="px-3 py-2 fw-bold nav-link text-dark  <?php echo e($active == 'detail' ? 'active text-decoration-underline' : 'text-decoration-none'); ?>" href="/detail-pesanan">Detail</a>
    </nav>
  </div>
</div>
<?php /**PATH D:\di sini\Pejuang Skripsi\Laravel 8\apps\wp-24-01-2022\wp-menu\resources\views/partials/navuser.blade.php ENDPATH**/ ?>