

<?php echo $__env->make('partials.navkasir', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('container'); ?>
<div class="container">
    <div class="d-flex flex-column align-items-stretch flex-shrink-0 bg-white mt-4">
        <a href="/" class="d-flex align-items-center flex-shrink-0 p-3 link-dark text-decoration-none">
            <span class="fs-5 fw-semibold"><i class="bi bi-speedometer2 fs-3"></i> Dashboard</span>
        </a>
        <nav class="border-bottom" style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">Dashboard</li>
                <li class="breadcrumb-item active" aria-current="page">Order list</li>
            </ol>
        </nav>
        <div class="list-group list-group-flush border-bottom scrollarea">
            <ul class="list-group">
                <a href="/dashboard/order-list/detail" class="text-decoration-none">
                    <li class="list-group-item-action bg-dark text-light lh-tight px-3">
                        <div class="d-flex w-100 align-items-center justify-content-between">
                            <div>
                                <div class="mt-3">
                                    <strong class="">Pesanan "<span>Maria Valensa</span>"</strong><br>
                                    <small>Time : <span>13:00</span> | Meja <span>12DG</span></small>
                                </div>
                                <div class="mt-3">
                                    <p>Coffe latte, Espresso, Dalgona...</p>
                                </div>
                            </div>
                            <div>
                                <button type="button" class="btn btn-outline-light mx-auto my-auto">Check</button>
                            </div>
                        </div>
                    </li>
                </a>
                <li class="list-group-item list-group-item list-group-item-action py-3 lh-tight">
                    <div class="d-flex w-100 align-items-center justify-content-between">
                        <strong class="mb-1">Pesanan "<span>Sumara Amanta</span>"</strong>
                        <small class="text-muted">Meja :<span>13DG</span></small>
                    </div>
                    <div class="col-10 mb-1 small">Time : <span>13:02</span> </div>
                </li>
                <li class="list-group-item list-group-item list-group-item-action py-3 lh-tight">
                    <div class="d-flex w-100 align-items-center justify-content-between">
                        <strong class="mb-1">Pesanan "<span>Anjalika Okta</span>"</strong>
                        <small class="text-muted">Meja :<span>14DG</span></small>
                    </div>
                    <div class="col-10 mb-1 small">Time : <span>13:05</span> </div>
                </li>
                <li class="list-group-item list-group-item list-group-item-action py-3 lh-tight">
                    <div class="d-flex w-100 align-items-center justify-content-between">
                        <strong class="mb-1">Pesanan "<span>Dika</span>"</strong>
                        <small class="text-muted">Meja :<span>14BK</span></small>
                    </div>
                    <div class="col-10 mb-1 small">Time : <span>13:06</span> </div>
                </li>
                <li class="list-group-item list-group-item list-group-item-action py-3 lh-tight">
                    <div class="d-flex w-100 align-items-center justify-content-between">
                        <strong class="mb-1">Pesanan "<span>Purnamanta Ridi</span>"</strong>
                        <small class="text-muted">Meja :<span>13BK</span></small>
                    </div>
                    <div class="col-10 mb-1 small">Time : <span>13:07</span> </div>
                </li>
            </ul>



        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\di sini\Pejuang Skripsi\Laravel 8\apps\wp-24-01-2022\wp-menu\resources\views/kasir/dashboard-olist.blade.php ENDPATH**/ ?>