

<?php echo $__env->make('partials.navadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('container'); ?>
<div class="container">
    <div class="d-flex flex-column align-items-stretch flex-shrink-0 bg-white mt-4">
        <a href="/dashboard-admin" class="d-flex align-items-center flex-shrink-0 p-3 link-dark text-decoration-none">
            <span class="fs-5 fw-semibold"><i class="bi bi-people-fill fs-3"></i> Kasir</span>
        </a>
        <nav class="border-bottom mb-5" style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">Kasir</li>
                <li class="breadcrumb-item active" aria-current="page">Data Kasir</li>
            </ol>
        </nav>
    </div>

    <?php if(session()->has('success')): ?>

    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Berhasil!</strong> <?php echo e(session('success')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php endif; ?>

    <a href="/kasir/create" class="text-end d-flex mb-2 text-decoration-none">
        <button class="btn btn-success"><i class="bi bi-people-fill"></i> New Kasir</button>
    </a>

    <table class="table mb-5">
        <thead class="table-dark">
            <tr>
                <th>#</th>
                <th>Nama</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php if($kasir->count()): ?>
            <?php $__currentLoopData = $kasir; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kasir): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($kasir->nama); ?></td>
                <td>
                    
                    <a href="/kasir/<?php echo e($kasir->id); ?>" class="text-decoration-none"><button type="button"
                            class="btn btn-primary" data-bs-toggle="tooltip" data-bs-placement="top" title="see"><i
                                class="bi bi-eye"></i></button></a>
                    
                    <a href="/kasir/<?php echo e($kasir->id); ?>/edit" class="text-decoration-none"><button type="button"
                            class="btn btn-success" data-bs-toggle="tooltip" data-bs-placement="top" title="edit"><i
                                class="bi bi-pencil"></i></button></a>
                    
                    <a href="#" class="text-decoration-none" data-bs-toggle="modal"
                            data-bs-target="#exampleModal<?php echo e($kasir->id); ?>"><button type="button"
                                class="btn btn-danger" data-bs-toggle="tooltip" 
                                title="delete"><i class="bi bi-trash"></i></button></a>
                    <!-- Modal Delete -->
                    <div class="modal fade" id="exampleModal<?php echo e($kasir->id); ?>" tabindex="-1"
                        aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Hapus</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                        aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    Data yang dihapus tidak dapat diakses kembali. <br> Yakin akan menghapus?
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-light"
                                        data-bs-dismiss="modal">Close</button>
                                    <form action="/kasir/<?php echo e($kasir->id); ?>" method="post">
                                        <?php echo method_field('delete'); ?>
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-danger">Hapus</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
            <div class="alert alert-warning alert-dismissible fade show" role="alert">
                <strong>Data kosong!</strong> Tambahkan data untuk mengisi tabel.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<script>
    var myModal = document.getElementById('myModal')
    var myInput = document.getElementById('myInput')

    myModal.addEventListener('shown.bs.modal', function () {
        myInput.focus()
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\di sini\Pejuang Skripsi\Laravel 8\apps\wp-menu\resources\views/admin/pegawai/kasir/kasir.blade.php ENDPATH**/ ?>