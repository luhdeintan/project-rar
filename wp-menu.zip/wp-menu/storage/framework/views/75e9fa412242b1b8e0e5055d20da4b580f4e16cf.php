<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
        <p class="navbar-brand my-auto">Warung Pejalan | </p>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link <?php echo e($active == 'dashboard' ? 'active' : ''); ?>" aria-current="page"
                        href="/dashboard-admin">Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e($active == 'profile' ? 'active' : ''); ?>" href="/profile">Profile</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e($active == 'penjualan' ? 'active' : ''); ?>" href="/penjualan">Penjualan</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e($active == 'menu' ? 'active' : ''); ?>" href="/menu">Menu</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e($active == 'kategori' ? 'active' : ''); ?>" href="/kategori">Kategori</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e($active == 'meja' ? 'active' : ''); ?>" href="/meja">Meja</a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle <?php echo e($active == 'kasir' | $active == 'admin' ? 'active' : ''); ?>" href="#" id="navbarDropdownMenuLink" role="button"
                        data-bs-toggle="dropdown" aria-expanded="false">
                        Pegawai
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                        <li><a class="dropdown-item" href="/kasir">Kasir</a></li>
                        <li><a class="dropdown-item" href="/admin">Admin</a></li>
                    </ul>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e($active == 'qr-code' ? 'active' : ''); ?>" href="/qr-code"><i
                            class="bi bi-qr-code-scan"></i> QR-Code</a>
                </li>
            </ul>
            <form class="d-flex my-auto">
                <?php echo csrf_field(); ?>
                <button class="btn btn-outline-success" type="submit">Logout</button>
            </form>
        </div>
    </div>
</nav><?php /**PATH D:\di sini\Pejuang Skripsi\Laravel 8\apps\wp-menu\resources\views/partials/navadmin.blade.php ENDPATH**/ ?>