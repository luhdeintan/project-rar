

<?php echo $__env->make('partials.navadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('container'); ?>
<div class="container">
    <div class="d-flex flex-column align-items-stretch flex-shrink-0 bg-white mt-4">
        <a href="/dashboard-admin" class="d-flex align-items-center flex-shrink-0 p-3 link-dark text-decoration-none">
            <span class="fs-5 fw-semibold"><i class="bi bi-file-earmark-binary fs-3"></i> Meja</span>
        </a>
        <nav class="border-bottom mb-5" style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">Meja</li>
                <li class="breadcrumb-item active" aria-current="page">Tabel data</li>
            </ol>
        </nav>
    </div>

    <?php if(session()->has('success')): ?>

    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Berhasil!</strong> <?php echo e(session('success')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php endif; ?>

    
    <button class="btn btn-success mb-2" data-bs-toggle="modal" data-bs-target="#add"><i
            class="bi bi-file-earmark-binary"></i> New Meja</button>
    
    <form action="/meja" method="POST">
        <?php echo csrf_field(); ?>
        <div class="modal fade" id="add" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header bg-success text-light">
                        <h5 class="modal-title" id="exampleModalLabel"><i class="bi bi-file-earmark-binary"></i> Tambah
                            Meja</h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"
                            aria-label="Close"></button>
                    </div>
                    <div class="modal-body mx-3 mb-3">
                        <label class="labels">No. Meja</label><input type="text" class="form-control mb-2"
                            placeholder="ex: DE01" value="" name="no_meja" required>
                        <label class="labels">Lokasi</label><input type="text" class="form-control"
                            placeholder="ex: depan" value="" name="lokasi" required>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-success">Tambah</button>
                    </div>
                </div>
            </div>
        </div>
    </form>


    
    <div class="table-responsive-xl">
        <table class="table table-striped table-hover table-bordered">
            <thead class="table-dark">
                <tr>
                    <td>#</td>
                    <td>No. Meja</td>
                    <td>Lokasi</td>
                    <td>Aksi</td>
                </tr>
            </thead>
            <tbody>
                <?php if($meja->count()): ?>
                <?php $__currentLoopData = $meja; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meja): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($meja->no_meja); ?></td>
                    <td><?php echo e($meja->lokasi); ?></td>
                    <td>
                        <a href="#" class="text-decoration-none" data-bs-toggle="modal"
                            data-bs-target="#edit<?php echo e($meja->id); ?>"><button type="button" class="btn btn-primary"
                                data-bs-toggle="tooltip" data-bs-placement="top" title="edit"><i
                                    class="bi bi-pencil"></i></button></a>
                        <a href="#" class="text-decoration-none" data-bs-toggle="modal"
                            data-bs-target="#exampleModal<?php echo e($meja->id); ?>"><button type="button" class="btn btn-danger"
                                data-bs-toggle="tooltip" data-bs-placement="top" title="delete"><i
                                    class="bi bi-trash"></i></button></a>
                        
                        <div class="modal fade" id="exampleModal<?php echo e($meja->id); ?>" tabindex="-1"
                            aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Hapus</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                            aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        Data yang dihapus tidak dapat diakses kembali. <br> Yakin akan menghapus?
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary"
                                            data-bs-dismiss="modal">Close</button>
                                        <form action="/meja/<?php echo e($meja->id); ?>" method="post">
                                            <?php echo method_field('delete'); ?>
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="btn btn-danger">Hapus</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <form action="/meja/<?php echo e($meja->id); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?>
                            <div class="modal fade" id="edit<?php echo e($meja->id); ?>" tabindex="-1"
                                aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog modal-dialog-centered">
                                    <div class="modal-content">
                                        <div class="modal-header bg-primary text-light">
                                            <h5 class="modal-title" id="exampleModalLabel"><i class="bi bi-pencil"></i>
                                                Edit Meja</h5>
                                            <button type="button" class="btn-close btn-close-white"
                                                data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body mx-3 mb-3">
                                            <label class="labels">No. Meja</label>
                                            <input type="text" class="form-control mb-2"
                                                value="<?php echo e(old('no_meja', $meja->no_meja)); ?>" name="no_meja" required>
                                            <label class="labels">Lokasi</label>
                                            <input type="text" class="form-control" 
                                                value="<?php echo e(old('lokasi', $meja->lokasi)); ?>" name="lokasi" required>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-light"
                                                data-bs-dismiss="modal">Close</button>
                                            <button type="submit" class="btn btn-primary">Edit</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                <div class="alert alert-warning alert-dismissible fade show" role="alert">
                    <strong>Data kosong!</strong> Tambahkan data untuk mengisi tabel.
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <?php endif; ?>

            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\di sini\Pejuang Skripsi\Laravel 8\apps\wp-menu\resources\views/admin/meja/meja.blade.php ENDPATH**/ ?>