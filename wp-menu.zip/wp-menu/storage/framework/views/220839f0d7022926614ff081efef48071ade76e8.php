

<?php echo $__env->make('partials.navadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('container'); ?>
<div class="container">
    <div class="container">
        <div class="d-flex flex-column align-items-stretch flex-shrink-0 bg-white mt-4">
            <a href="/dashboard-admin"
                class="d-flex align-items-center flex-shrink-0 p-3 link-dark text-decoration-none">
                <span class="fs-5 fw-semibold"><i class="bi bi-receipt-cutoff fs-3"></i> Penjualan</span>
            </a>
            <nav class="border-bottom" style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">Penjualan</li>
                    <li class="breadcrumb-item active" aria-current="page">Daftar info</li>
                </ol>
            </nav>
        </div>
    </div>
    <div class="card mt-5 mx-5">
        <div class="card-header bg-success text-light">
            Pendapatan
        </div>
        <div class="card-body">
            <h5 class="card-title">Pendapatan Hari Ini</h5>
            <p class="card-text">Daftar penjualan menu hari ini pada Cafe Warung Pejalan.</p>
            <a href="#" class="btn btn-success">Check</a>
        </div>
    </div>
    <div class="card mt-5 mx-5">
        <div class="card-header bg-primary text-light">
            History Bulanan
        </div>
        <div class="card-body">
            <h5 class="card-title">Penjualan Bulanan</h5>
            <p class="card-text">Perkembangan penjualan per bulan pada Cafe Warung Pejalan.</p>
            <a href="#" class="btn btn-primary">Check</a>
        </div>
    </div>
    <div class="card mt-5 mx-5">
        <div class="card-header bg-warning text-dark">
            Pembatalan
        </div>
        <div class="card-body">
            <h5 class="card-title">Pesanan dibatalkan</h5>
            <p class="card-text">Histori pemesanan yang dibatalkan.</p>
            <a href="#" class="btn btn-warning">Check</a>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Punya SAYA\di sini\Pejuang Skripsi\Laravel 8\applications\wp-menu\resources\views/admin/penjualan.blade.php ENDPATH**/ ?>