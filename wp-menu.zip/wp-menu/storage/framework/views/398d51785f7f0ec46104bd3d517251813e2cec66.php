

<?php echo $__env->make('partials.navadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('container'); ?>

<div class="container">
    <div class="d-flex flex-column align-items-stretch flex-shrink-0 bg-white mt-4">
        <a href="/" class="d-flex align-items-center flex-shrink-0 p-3 link-dark text-decoration-none">
            <span class="fs-5 fw-semibold"><i class="bi bi-person-rolodex fs-3"></i> Profile</span>
        </a>
        <nav class="border-bottom" style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">Dashboard</li>
                <li class="breadcrumb-item active" aria-current="page">Profile saya</li>
            </ol>
        </nav>
    </div>


    
    <form action="" method="post">
        <?php echo csrf_field(); ?>
        <div class="container rounded bg-white mb-5">
            <div class="row">
                
                <div class="col-md-3 border-right">
                    <div class="d-flex flex-column align-items-center text-center">
                        <img class="rounded-circle mt-5" width="150px"
                            src="<?php echo e(isset($photo) ? $photo : "https://source.unsplash.com/200x200?profile"); ?>"> <br>
                        <p class="font-weight-bold lh-1">Upload photo</p>
                        <span class="text-black-50"><input class="form-control form-control-sm" id="formFileSm"
                                type="file"></span>
                    </div>
                </div>


                <div class="col-md-5 border-right">
                    <div class="p-3 pt-5">
                        <div class="d-flex justify-content-between align-items-center mb-4">
                            <h4 class="text-right">Profile Edit</h4>
                        </div>
                        
                        <div class="row mb-3">
                            <div class="col-md-12"><label class="labels">Nama</label><input type="text"
                                    class="form-control" placeholder="ex : 082145678899" value="" name="nama" required>
                            </div>
                        </div>
                        
                        <div class="row mb-3">
                            <div class="col-md-12"><label class="labels">Alamat</label><input type="text"
                                    class="form-control" placeholder="ex : 082145678899" value="" name="alamat"
                                    required></div>
                        </div>
                        
                        <div class="row mb-3">
                            <div class="col-md-12"><label class="labels">No. Tlp</label><input type="text"
                                    class="form-control" placeholder="ex : 082145678899" value="" name="alamat"
                                    required></div>
                        </div>
                    </div>
                </div>


                
                <div class="col-md-4">
                    <div class="p-3 pt-5">
                        <div class="d-flex justify-content-between align-items-center mb-4">
                            <h4>Akses login</h4>
                        </div>
                        
                        <div class="row mb-3">
                            <div class="col-md-12"><label class="labels">Username</label><input type="text"
                                    class="form-control" placeholder="username" value="" name="username" required>
                            </div>
                        </div>
                        
                        <div class="row mb-3">
                            <div class="col-md-12"><label class="labels">password</label><input type="text"
                                    class="form-control" placeholder="password" value="" name="password" id="pass-able"
                                    required>
                            </div>
                            <small>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="" id="flexCheckChecked"
                                        onclick="myFunction()" checked>
                                    <label class="form-check-label" for="flexCheckChecked">
                                        Tampilkan password
                                    </label>
                                </div>
                            </small>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="mt-5 text-center">
                <button class="btn btn-primary profile-button" type="button" data-bs-toggle="modal"
                    data-bs-target="#exampleModal">Simpan</button>
            </div>
            
            <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel"
                aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Simpan perubahan?</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            Apakah Anda ingin mengubah profile dengan data yang baru?
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="button" class="btn btn-primary">Simpan</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>
</div>
</div>

<script>
    function myFunction() {
        var x = document.getElementById("pass-able");
        if (x.type === "password") {
            x.type = "text";
        } else {
            x.type = "password";
        }
    }
</script>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Punya SAYA\di sini\Pejuang Skripsi\Laravel 8\applications\wp-menu\resources\views/admin/profile.blade.php ENDPATH**/ ?>