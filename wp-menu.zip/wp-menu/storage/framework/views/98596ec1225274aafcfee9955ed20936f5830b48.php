<?php echo $__env->make('partials.navuser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('container'); ?>
<div class="container ">
    <div class="p-4 p-md-5 mb-4 text-white rounded bg-dark">
        <div class="col-md-10 px-0">
            <h3 class="display-6 fst-italic">Detail Pesanan</h3>
            <p class="lad my-3">Informasi menu pesanan Anda beserta total pembayaran</p>
            <small class=" mb-0 text-white fw-bold">#bill #smallesanan #menus</p>
        </div>
    </div>

    <?php if($bill): ?>
    <div class="card text-white bg-success mb-3 mx-auto">
        <div class="card-header">Order list detail</div>
        <div class="card-body">
            <p class="bi bi-patch-check-fill fs-1"></p>
            <h5 class="card-title mb-0">Info Pembayaran</h5>
            <small class="opacity-50">At <?php echo e($bill->updated_at->format('g:i a')); ?> |
                <?php echo e($bill->updated_at->format('F d, Y')); ?></small>
            <p class="card-text mt-3 fst-italic">* Pembayaran dilakukan di kasir, sesuai dengan informasi berikut.</p>
            <div class="container mt-3">
                <div class="row border border-light mb-2">
                    <div class="col-2 fw-bold">
                        No.
                    </div>
                    <div class="col-4 fw-bold">
                        Menu
                    </div>
                    <div class="col-2 fw-bold text-center">
                        Qty
                    </div>
                    <div class="col-4 fw-bold">
                        Jumlah
                    </div>
                </div>
                <?php
                $total;
                ?>
                <?php $__currentLoopData = $bills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pesan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row">
                    <div class="col-2">
                        <?php echo e($loop->iteration); ?>

                    </div>
                    <div class="col-4">
                        <?php echo e($pesan->menu); ?>

                    </div>
                    <div class="col-2 text-center">
                        <?php echo e($pesan->quantity); ?>

                    </div>
                    <div class="col-4">
                        Rp. <?php echo number_format($pesan->jumlah,0,',','.'); ?>
                    </div>
                </div>
                <?php
                $total =+ $pesan->jumlah
                ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="row bg-light text-success mt-2">
                    <div class="col-8 text-end">
                        <strong>Total :</strong>
                    </div>
                    <div class="col-4">
                        <strong>Rp. <?php echo number_format($sum,0,',','.'); ?></strong>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php else: ?>
    <div class="alert alert-warning" role="alert">
        <strong>Belum melakukan pemesanan.</strong> Lakukan pemesanan terlebih dahulu pada <a href="/kategori" class="alert-link">Kategori</a> atau melalui <a href="/welcome" class="alert-link">Menu</a>.
    </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\di sini\Pejuang Skripsi\Laravel 8\apps\wp-24-01-2022\wp-menu\resources\views/detail-pesanan.blade.php ENDPATH**/ ?>