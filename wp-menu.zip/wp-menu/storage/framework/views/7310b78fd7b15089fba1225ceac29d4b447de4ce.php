

<?php echo $__env->make('partials.navuser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('container'); ?>
<div class="container">
    <div class="p-4 p-md-5 mb-4 text-white rounded bg-dark">
        <div class="col-md-10 px-0">
            <h1 class="display-4 fst-italic">Keranjang Pesanan</h1>
            <p class="lead my-3">Cek daftar pesananmu dan tambah menu-menu yang kamu inginkan!</p>
            <p class="lead mb-0 text-white fw-bold">#pesan #daftarpesan</p>
        </div>
    </div>


    
    <form action="" method="post" class="mb-5">
        <?php echo csrf_field(); ?>

        <span class="badge bg-primary mb-3 mt-4 text-end d-flex px-4 py-2">Make Order</span>

        <ol class="list-group list-group-numbered">
            <li class="list-group-item d-flex justify-content-between align-items-start">
                <div class="ms-2 me-auto">
                    <div class="fw-bold">Latte Espresso <span class="badge bg-secondary rounded-pill">2</span></div>
                    Rp 26.000
                </div>
                <a href="#"><span class="badge rounded-pill bg-primary my-2 mx-2 p-2"><i
                            class="bi bi-pencil-fill"></i></span></a>
                <span class="badge rounded-pill bg-danger my-2 mx-2 p-2"><i class="bi bi-trash-fill"></i></span>
            </li>
            <li class="list-group-item d-flex justify-content-between align-items-start">
                <div class="ms-2 me-auto">
                    <div class="fw-bold">Milk Coffe <span class="badge bg-secondary rounded-pill">2</span></div>
                    Rp 17.000
                </div>
                <a href="#"><span class="badge rounded-pill bg-primary my-2 mx-2 p-2"><i
                            class="bi bi-pencil-fill"></i></span></a>
                <span class="badge rounded-pill bg-danger my-2 mx-2 p-2"><i class="bi bi-trash-fill"></i></span>
            </li>
            
            <p class="list-group-item list-group-item-success text-end fw-bold mb-0">Total : Rp 86.000</p>
        </ol>
        <div class="d-grid gap-2 d-lg-flex justify-content-lg-end">
            <button type="button" class="btn btn-primary btn-lg btn-block my-3" data-toggle="button"
                aria-pressed="false" autocomplete="off">Kirim pesanan</i></button>
        </div>
    </form>




    
    <span class="badge bg-warning mb-3 mt-4 text-end d-flex px-4 py-2" style="color: black">Wait Order</span>

    <ol class="list-group list-group-numbered">
        <li class="list-group-item d-flex justify-content-between align-items-start">
            <div class="ms-2 me-auto">
                <div class="fw-bold">Latte Espresso <span class="badge bg-secondary rounded-pill">2</span></div>
                Rp 26.000
            </div>
        </li>
        <li class="list-group-item d-flex justify-content-between align-items-start">
            <div class="ms-2 me-auto">
                <div class="fw-bold">Milk Coffe <span class="badge bg-secondary rounded-pill">2</span></div>
                Rp 17.000
            </div>
        </li>
        
        <p class="list-group-item list-group-item-success text-end mb-5 fw-bold">Total : Rp 86.000</p>
    </ol>

    
    <span class="badge bg-success mb-3 mt-4 text-end d-flex px-4 py-2"> Order Success on December 12, 2021 | 13:08</span>

    <ol class="list-group list-group-numbered">
        <li class="list-group-item d-flex justify-content-between align-items-start">
            <div class="ms-2 me-auto">
                <div class="fw-bold">Latte Espresso</div>
                Rp 26.000
            </div>
            <span class="badge bg-primary rounded-pill">2</span>
        </li>
        <li class="list-group-item d-flex justify-content-between align-items-start">
            <div class="ms-2 me-auto">
                <div class="fw-bold">Milk Coffe</div>
                Rp 17.000
            </div>
            <span class="badge bg-primary rounded-pill">2</span>
        </li>
        
        <p class="list-group-item list-group-item-success text-end mb-5 fw-bold">Total : Rp 86.000</p>
    </ol>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Punya SAYA\di sini\Pejuang Skripsi\Laravel 8\applications\wp-menu\resources\views/keranjang.blade.php ENDPATH**/ ?>