<?php echo $__env->make('partials.navadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('container'); ?>
<main class="container">
    <div class="d-flex flex-column align-items-stretch flex-shrink-0 bg-white mt-4">
        <a href="/dashboard-admin" class="d-flex align-items-center flex-shrink-0 p-3 link-dark text-decoration-none">
            <span class="fs-5 fw-semibold"><i class="bi bi-speedometer2 fs-3"></i> Dashboard</span>
        </a>
        <nav class="border-bottom" style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">Dashboard</li>
                <li class="breadcrumb-item active" aria-current="page">info</li>
            </ol>
        </nav>
    </div>

    <div class="container">
        <div class="row my-5">
            <div class="col-sm-6">
                <a href="/history-penjualan" class="text-white" style="text-decoration: none">
                    <div class="card text-white bg-success">
                        <div class="card-body">
                            <h5 class="card-title"><i class="bi bi-cash-coin"></i> Penjualan hari ini</h5>
                            <h1 class="card-text">Rp. <?php echo number_format($order,0,',','.'); ?></h1>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-sm-6">
                <a href="/history-penjualan" class="text-white"  style="text-decoration: none;">
                    <div class="card text-white bg-primary" >
                        <div class="card-body">
                            <h5 class="card-title"><i class="bi bi-people-fill"></i> Pengunjung hari ini</h5>
                            <h1 class="card-text"><?php echo e($user); ?></h1>
                        </div>
                    </div>
                </a>
            </div>
        </div>



        
    </div>


</main>






<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\di sini\Pejuang Skripsi\Laravel 8\apps\wp-24-01-2022\wp-menu\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>