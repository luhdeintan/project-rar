

<?php echo $__env->make('partials.navkasir', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('container'); ?>

<div class="container">
    <div class="d-flex flex-column align-items-stretch flex-shrink-0 bg-white mt-4">
        <a href="/" class="d-flex align-items-center flex-shrink-0 p-3 link-dark text-decoration-none">
            <span class="fs-5 fw-semibold"><i class="bi bi-clock fs-3"></i> History</span>
        </a>
        <nav class="border-bottom" style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">History</li>
                <li class="breadcrumb-item" aria-current="page">History list</li>
                <li class="breadcrumb-item active" aria-current="page">Cook</li>
            </ol>
        </nav>
    </div>


    <div class="list-group list-group-flush border-bottom scrollarea">
        <ul class="list-group">

            <li class="list-group-item bg-warning lh-tight px-3">
                <a href="/dashboard/order-list/detail" class="text-decoration-none text-dark">
                    <div class="d-flex w-100 align-items-center justify-content-between">
                        <div>
                            <div class="mt-3">
                                <strong class="">Pesanan "<span>Maria Valensa</span>"</strong><br>
                                <small>Time : <span>13:00</span> | Meja <span>12DG</span></small>
                            </div>
                            <div class="mt-3">
                                <p>Coffe latte, Espresso, Dalgona...</p>
                            </div>
                        </div>
                        <div>
                            <button type="button" class="btn btn-outline-dark mx-auto my-auto">Check</button>
                        </div>
                    </div>
                </a>
            </li>

            <li class="list-group-item lh-tight px-3">
                <a href="/dashboard/order-list/detail" class="text-decoration-none text-dark">
                    <div class="d-flex w-100 align-items-center justify-content-between">
                        <div>
                            <div class="mt-3">
                                <strong class="">Pesanan "<span>Anjelina</span>"</strong><br>
                                <small>Time : <span>13:01</span> | Meja <span>13DG</span></small>
                            </div>
                            <div class="mt-3">
                                <p>Coffe latte, Espresso, Dalgona...</p>
                            </div>
                        </div>
                        <div>
                            <button type="button" class="btn btn-outline-dark mx-auto my-auto">Check</button>
                        </div>
                    </div>
                </a>
            </li>
            <li class="list-group-item lh-tight px-3">
                <a href="/dashboard/order-list/detail" class="text-decoration-none text-dark">
                    <div class="d-flex w-100 align-items-center justify-content-between">
                        <div>
                            <div class="mt-3">
                                <strong class="">Pesanan "<span>Dicky Apriano/span>"</strong><br>
                                <small>Time : <span>13:05</span> | Meja <span>14DG</span></small>
                            </div>
                            <div class="mt-3">
                                <p>Coffe latte, Espresso, Dalgona...</p>
                            </div>
                        </div>
                        <div>
                            <button type="button" class="btn btn-outline-dark mx-auto my-auto">Check</button>
                        </div>
                    </div>
                </a>
            </li>
        </ul>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Punya SAYA\di sini\Pejuang Skripsi\Laravel 8\applications\wp-menu\resources\views/kasir/history-cook.blade.php ENDPATH**/ ?>