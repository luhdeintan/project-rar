

<?php echo $__env->make('partials.navadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('container'); ?>
<div class="container">
    <div class="container">
        <div class="d-flex flex-column align-items-stretch flex-shrink-0 bg-white mt-4">
            <a href="/dashboard-admin" class="d-flex align-items-center flex-shrink-0 p-3 link-dark text-decoration-none">
                <span class="fs-5 fw-semibold"><i class="bi bi-speedometer2 fs-3"></i> Dashboard</span>
            </a>
            <nav class="border-bottom" style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">Dashboard</li>
                    <li class="breadcrumb-item active" aria-current="page">info</li>
                </ol>
            </nav>
        </div>
    </div>
    <div class="container mt-4">
        <div class="row justify-content-center">
            <div class="col-md-4 pt-3 px-5 justify-content-center">
                <a href="/penjualan/hari-ini" class="text-decoration-none text-light d-flex">
                    <div class="card bg-success justify-content-center mx-auto" style="width: 20rem;">
                        <div class="card-body shadow">
                            <h5 class="card-title">Pendapatan hari ini</h5><br>
                            <h3 class="card-subtitle mb-2 text-light">Rp 235.000
                            </h3><br>
                            <p class="card-text fst-italic">Dengan pemesanan 32 menu</p>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-md-4 pt-3 px-5 justify-content-center">
                <a href="/penjualan/penjualan-bulanan" class="text-decoration-none text-light d-flex ">
                    <div class="card bg-primary justify-content-center mx-auto" style="width: 20rem;">
                        <div class="card-body">
                            <h5 class="card-title">History Bulan Penjualan</h5><br>
                            <h3 class="card-subtitle mb-2 text-light">Rp 1.420.000
                            </h3><br>
                            <p class="card-text fst-italic">Dengan pemesanan 76 menu</p>
                        </div>
                    </div>
                </a>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Punya SAYA\di sini\Pejuang Skripsi\Laravel 8\applications\wp-menu\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>