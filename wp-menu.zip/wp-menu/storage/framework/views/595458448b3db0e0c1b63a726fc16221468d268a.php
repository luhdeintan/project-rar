

<?php echo $__env->make('partials.navadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('container'); ?>
<div class="container">
    <div class="d-flex flex-column align-items-stretch flex-shrink-0 bg-white mt-4">
        <a href="/dashboard-admin" class="d-flex align-items-center flex-shrink-0 p-3 link-dark text-decoration-none">
            <span class="fs-5 fw-semibold"><i class="bi bi-journal-text fs-3"></i> Menu</span>
        </a>
        <nav class="border-bottom mb-5" style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">Menu</li>
                <li class="breadcrumb-item active" aria-current="page">Tabel data</li>
            </ol>
        </nav>
    </div>

    <?php if(session()->has('success')): ?>

    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Berhasil!</strong> <?php echo e(session('success')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php endif; ?>

    <a href="/menu/create" class="text-end d-flex mb-2 text-decoration-none">
        <button class="btn btn-success"><i class="bi bi-journal-text"></i> New Menu</button>
    </a>

    
    <div class="table-responsive-xl">
        <table class="table table-striped table-hover table-bordered">
            <thead class="table-dark">
                <tr>
                    <td>No.</td>
                    <td>Nama</td>
                    <td>Kategori</td>
                    <td>Harga</td>
                    <td>type</td>
                    <td>Aksi</td>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($menu->nama); ?></td>
                    <td><?php echo e($menu->kategori->nama); ?></td>
                    <td><?php echo e($menu->harga); ?></td>
                    <td><?php echo e($menu->type); ?></td>
                    <td>
                        
                        <a href="/menu/<?php echo e($menu->id); ?>" class="text-decoration-none"><button type="button"
                                class="btn btn-primary" data-bs-toggle="tooltip" data-bs-placement="top" title="see"><i
                                    class="bi bi-eye"></i></button></a>
                        
                        <a href="/menu/<?php echo e($menu->id); ?>/edit" class="text-decoration-none"><button type="button"
                                class="btn btn-warning" data-bs-toggle="tooltip" data-bs-placement="top" title="edit"><i
                                    class="bi bi-pencil"></i></button></a>
                        
                        <form action="/menu/<?php echo e($menu->id); ?>" method="post" class="d-inline">
                            <?php echo method_field('delete'); ?>
                            <?php echo csrf_field(); ?>
                            <button
                                class="btn btn-danger" type="submit" title="delete" onclick="return confirm('Hapus data menu?')"><i class="bi bi-trash"></i>
                            </button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\di sini\Pejuang Skripsi\Laravel 8\apps\wp-24-01-2022\wp-menu\resources\views/admin/menu/menu.blade.php ENDPATH**/ ?>