

<?php echo $__env->make('partials.navuser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('container'); ?>
<div class="container">
    <div class="p-4 p-md-5 mb-4 text-white rounded bg-dark">
        <div class="col-md-10 px-0">
            <h1 class="display-4 fst-italic">Varian menu dalam kategori</h1>
            <p class="lead my-3">Beragam kategori menu mulai dari Coffee hingga Snack. Cek menu kesukaanmu di sini!</p>
            <p class="lead mb-0 text-white fw-bold">#menu #kategori</p>
        </div>
    </div>
    <div class="card text-center">
        <div class="card-header">
            <ul class="nav nav-tabs card-header-tabs">
                <li class="nav-item">
                    <a class="nav-link active" aria-current="true" href="/kategori/kopi">Arabika</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/kategori/espresso">Robusta</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/kategori/minuman-lainnya">Espresso</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/kategori/minuman-lainnya">Minuman</a>
                </li>
            </ul>
        </div>
        <div class="card-body text-start">
            <h3 class="mx-3">Hot Arabika</h3>
            <hr>
            <div class="row mb-2 justify-content-center mb-6">
                
                <div class="card px-0 my-3 mx-3" style="width: 18rem;">
                    <img src="https://source.unsplash.com/1200x600?coffee" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h3 class="mb-0">Espresso Milk</h3>
                        <div class="mb-1 text-muted">Espresso dengan tambahan susu</div>
                        <strong class="d-inline-block mb-2 text-success">Rp 20.000</strong><br>
                        <a href="/menu/single-menu" class="stretched-link">Detail menu</a>
                    </div>
                </div>
                
                <div class="card px-0 my-3 mx-3" style="width: 18rem;">
                    <img src="https://source.unsplash.com/1200x600?coffee" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h3 class="mb-0">Espresso Milk</h3>
                        <div class="mb-1 text-muted">Espresso dengan tambahan susu</div>
                        <strong class="d-inline-block mb-2 text-success">Rp 20.000</strong><br>
                        <a href="#" class="stretched-link">Detail menu</a>
                    </div>
                </div>
                
                <div class="card px-0 my-3 mx-3" style="width: 18rem;">
                    <img src="https://source.unsplash.com/1200x600?coffee" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h3 class="mb-0">Espresso Milk</h3>
                        <div class="mb-1 text-muted">Espresso dengan tambahan susu</div>
                        <strong class="d-inline-block mb-2 text-success">Rp 20.000</strong><br>
                        <a href="#" class="stretched-link">Detail menu</a>
                    </div>
                </div>
            </div>

            <h3 class="mx-3">Cold Arabika</h3>
            <hr>
        </div>
    </div>
</div>


    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Punya SAYA\di sini\Pejuang Skripsi\Laravel 8\applications\wp-menu\resources\views/kategori.blade.php ENDPATH**/ ?>