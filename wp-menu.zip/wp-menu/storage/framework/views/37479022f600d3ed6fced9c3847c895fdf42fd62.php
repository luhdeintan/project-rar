<?php echo $__env->make('partials.navadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('container'); ?>
<div class="container">
    <div class="d-flex flex-column align-items-stretch flex-shrink-0 bg-white mt-4">
        <a href="/dashboard-admin" class="d-flex align-items-center flex-shrink-0 p-3 link-dark text-decoration-none">
            <span class="fs-5 fw-semibold"><i class="bi bi-qr-code-scan fs-3"></i> QR-Code</span>
        </a>
        <nav class="border-bottom mb-5" style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">QR-Code</li>
                <li class="breadcrumb-item active" aria-current="page">Tabel data</li>
            </ol>
        </nav>
    </div>

    <?php if(session()->has('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Berhasil!</strong> <?php echo e(session('success')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php endif; ?>

    <button class="btn btn-success mb-2" data-bs-toggle="modal" data-bs-target="#add">
        <i class="bi bi-qr-code-scan"></i> New QR-Code
    </button>
    
    <form action="/qrcode" method="POST">
        <?php echo csrf_field(); ?>
        <div class="modal fade" id="add" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header bg-success text-light">
                        <h5 class="modal-title" id="exampleModalLabel"><i class="bi bi-qr-code-scan"></i> Tambah QR-Code
                        </h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"
                            aria-label="Close"></button>
                    </div>
                    <div class="modal-body mx-3 my-3">
                        
                        <div class="mb-3">
                            <label class="labels">No. Meja</label>
                            <select class="form-select <?php $__errorArgs = ['no_meja'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                aria-label="Default select example" name="no_meja">
                                <?php $__currentLoopData = $meja; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(old('no_meja') == $m->id): ?>
                                <option value="<?php echo e($m->id); ?>" selected><?php echo e($m->no_meja); ?></option>
                                <?php else: ?>
                                <option value="<?php echo e($m->id); ?>"><?php echo e($m->no_meja); ?></option>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        
                        
                        
                        <div class="mb-3">
                            <label class="labels">Status</label><select
                                class="form-select <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                aria-label="Default select example" name="status">
                                <option value="ready">READY</option>
                                <option value="used">USED</option>
                                <option value="finish">FINISH</option>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-success">Tambah</button>
                    </div>
                </div>
            </div>
        </div>
    </form>

    
    <div class="table-responsive-xl">
        <table class="table table-striped table-hover table-bordered">
            <thead class="table-dark">
                <tr>
                    <td>#</td>
                    <td>ID Meja</td>
                    <td>Kode Generate</td>
                    <td>Waktu</td>
                    <td>Status</td>
                    <td>Aksi</td>
                </tr>
            </thead>
            <tbody>
                <?php if($kode->count()): ?>
                <?php $__currentLoopData = $kode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($kode->meja->no_meja); ?></td>
                    <td><?php echo e($kode->kode_generate); ?></td>
                    <td><?php echo e($kode->waktu); ?></td>
                    <td><span class="badge bg-success">USED</span></td>
                    <td>
                        <a href="/QR-Code/code-id" class="text-decoration-none"><button type="button"
                                class="btn btn-primary" data-bs-toggle="tooltip" data-bs-placement="top" title="see"><i
                                    class="bi bi-eye"></i></button></a>
                        <a href="/QR-Code/edit/code-id" class="text-decoration-none"><button type="button"
                                class="btn btn-success" data-bs-toggle="tooltip" data-bs-placement="top" title="edit"><i
                                    class="bi bi-pencil"></i></button></a>
                        <a href="#" class="text-decoration-none"><button type="button" class="btn btn-danger"
                                data-bs-toggle="tooltip" data-bs-placement="top" title="delete"><i class="bi bi-trash"
                                    data-bs-toggle="modal" data-bs-target="#exampleModal"></i></button></a>
                        
                        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel"
                            aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Hapus</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                            aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        Data yang dihapus tidak dapat diakses kembali. <br> Yakin akan menghapus?
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary"
                                            data-bs-dismiss="modal">Close</button>
                                        <button type="button" class="btn btn-danger">Hapus</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </td>
                </tr>
            </tbody>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
            <div class="alert alert-warning alert-dismissible fade show" role="alert">
                <strong>Data kosong!</strong> Tambahkan data untuk mengisi tabel.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            <?php endif; ?>
        </table>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\di sini\Pejuang Skripsi\Laravel 8\apps\wp-24-01-2022\wp-menu\resources\views/admin/qrcode/qrcode.blade.php ENDPATH**/ ?>