

<?php $__env->startSection('container'); ?>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
        <p class="navbar-brand my-auto">Warung Pejalan | </p>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="#">Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">History</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Profil</a>
                </li>
            </ul>
            <form class="d-flex">
                <?php echo csrf_field(); ?>
                <button class="btn btn-outline-success" type="submit">Logout</button>
            </form>
        </div>
    </div>
</nav>

<div class="container">
    <div class="d-flex flex-column align-items-stretch flex-shrink-0 bg-white">
        <a href="/" class="d-flex align-items-center flex-shrink-0 p-3 link-dark text-decoration-none border-bottom">
            <span class="fs-5 fw-semibold"><i class="bi bi-speedometer2 fs-3"></i> Dashboard</span>
        </a>
        <div class="row mt-4 px-4">
            <div class="card bg-dark border border-none col-lg-4 mx-auto" style="color: white;">
                <div class="card-body">
                    <div class="title">
                        <h5 class="card-title"><i class="bi bi-file-text-fill"></i> Daftar Pesanan</h5>
                    </div>
                    <div class="sub-title">
                        <small class="disable" style="color: grey">Dec 12, 2021 | <span class="badge bg-warning text-dark">25 order list</span></small>
                    </div>
                    <div class="text my-3">
                        <p class="card-text">Periksa daftar pesanan hari ini, semakin cepat pelayanan, pelanggan semakin senang</p>
                    </div>
                    <a href="#" class="btn btn-primary">Check it now</a>
                </div>
            </div>

            <div class="card bg-dark border border-none col-lg-4 mx-auto" style="color: white;">
                <div class="card-body">
                    <div class="title">
                        <h5 class="card-title"><i class="bi bi-file-text-fill"></i> Daftar Pesanan</h5>
                    </div>
                    <div class="sub-title">
                        <small class="disable" style="color: grey">Dec 12, 2021 | <span class="badge bg-warning text-dark">25 order list</span></small>
                    </div>
                    <div class="text my-3">
                        <p class="card-text">Periksa daftar pesanan hari ini, semakin cepat pelayanan, pelanggan semakin senang</p>
                    </div>
                    <a href="#" class="btn btn-primary">Check it now</a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Punya SAYA\di sini\Pejuang Skripsi\Laravel 8\applications\wp-menu\resources\views/dashboard-kasir.blade.php ENDPATH**/ ?>