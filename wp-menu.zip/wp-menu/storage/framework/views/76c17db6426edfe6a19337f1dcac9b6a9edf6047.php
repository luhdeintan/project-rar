<?php echo $__env->make('partials.navuser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('container'); ?>
<div class="container">
    <div class="p-4 p-md-5 mb-4 text-white rounded bg-dark">
        <div class="col-md-10 px-0">
            <h1 class="display-6 fst-italic">Various Categories</h1>
            <p class=" my-3">Pencarian menu berdasarkan kategori</p>
            <small class=" mb-0 text-white fw-bold">#menu #kategori</small>
        </div>
    </div>
    <div class="card">
        <div class="card-body tab-content">
            <!-- Nav tabs -->
            <ul class="nav nav-tabs" role="tablist">
                <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($loop->first): ?>
                <li class="nav-item">
                    <a class="nav-link active" data-toggle="tab"
                        href="#<?php echo e(str_replace(' ', '', $k->nama)); ?>"><?php echo e($k->nama); ?></a>
                </li>
                <?php else: ?>
                <li class="nav-item">
                    <a class="nav-link" data-toggle="tab"
                        href="#<?php echo e(str_replace(' ', '', $k->nama)); ?>"><?php echo e($k->nama); ?></a>
                </li>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>

            <!-- Tab panes -->
            <div class="tab-content">
                <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($loop->first): ?>
                <div id="<?php echo e(str_replace(' ', '', $k->nama)); ?>" class="container tab-pane active" style="padding-left: 0px"><br>
                    <h3 style="margin-left: 12px"><?php echo e($k->nama); ?></h3>
                    <div class="row" style="padding-right: 38px;">
                        <?php $__currentLoopData = $k->menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($item->active == 1): ?>
                        <a href="<?php echo e(($item->status == 'empty') ? '#' : '/detailmenu/'.$item->id); ?>"
                            class="text-decoration-none <?php echo e(($item->status == 'empty') ? 'disabled text-secondary' : 'text-primary'); ?>">

                            <div class="card shadow px-0 my-3 mx-4 justify-content-center d-flex flex-column-reverse"
                                style="<?php echo e(($item->status == 'empty') ? 'background-color: #ceccbf' : ''); ?>">
                                <div class="d-flex flex-row pe-2 ps-3" style="margin-left: 0px;">
                                    <div>
                                        <img src="<?php echo e(asset('menu-img/'. $item->gambar)); ?>"
                                            class="card-img-top mt-3" alt="<?php echo e($item->nama); ?>"
                                            style="<?php echo e(($item->status == 'empty') ? 'filter: grayscale(100%)' : ''); ?>; width:64px; height:64px; object-fit: cover; border-radius:5%;">
                                    </div>
                                    <div class=" media-body px-3" style="width:100%; padding-top: 10px; padding-bottom:10px">
                                        <h4 class="mb-0 <?php echo e(($item->status == 'empty') ? 'text-muted' : ''); ?>">
                                            <?php echo e($item->nama); ?></h4>
                                        <div class="mb-1 text-muted"><?php echo e($item->bahan); ?></div>
                                        <strong
                                            class="d-inline-block mb-2 text-success <?php echo e(($item->status == 'empty') ? 'text-muted' : ''); ?>">Rp. <?php echo number_format($item->harga,0,',','.'); ?></strong><br>
                                        <a href="<?php echo e(($item->status == 'empty') ? '#' : '/detailmenu/'.$item->id); ?>"
                                            class="text-decoration-none <?php echo e(($item->status == 'empty') ? 'disabled text-secondary' : 'text-primary'); ?>"><?php echo e(($item->status == 'empty') ? 'Empty' : 'Detail menu'); ?></a>
                                    </div>
                                </div>
                            </div>
                        </a>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <?php else: ?>
                <div id="<?php echo e(str_replace(' ', '', $k->nama)); ?>" class="container tab-pane fade" style="padding-left: 0px"><br>
                    <h3 style="margin-left: 12px"><?php echo e($k->nama); ?></h3>
                    <div class="row" style="padding-right: 38px;">
                        <?php $__currentLoopData = $k->menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($item->active == 1): ?>
                        <a href="<?php echo e(($item->status == 'empty') ? '#' : '/detailmenu/'.$item->id); ?>"
                            class="text-decoration-none <?php echo e(($item->status == 'empty') ? 'disabled text-secondary' : 'text-primary'); ?>">

                            <div class="card shadow px-0 my-3 mx-4 justify-content-center d-flex flex-column-reverse"
                                style="<?php echo e(($item->status == 'empty') ? 'background-color: #ceccbf' : ''); ?>">
                                <div class="d-flex flex-row px-3">
                                    <div>
                                        <img src="<?php echo e(asset('menu-img/'. $item->gambar)); ?>"
                                            class="card-img-top mt-3" alt="<?php echo e($item->nama); ?>"
                                            style="<?php echo e(($item->status == 'empty') ? 'filter: grayscale(100%)' : ''); ?>; width:64px; height:64px; object-fit: cover; border-radius:5%">
                                    </div>
                                    <div class=" media-body px-3" style="width:100%; padding-top: 10px; padding-bottom:10px">
                                        <h4 class="mb-0 <?php echo e(($item->status == 'empty') ? 'text-muted' : ''); ?>">
                                            <?php echo e($item->nama); ?></h4>
                                        <div class="mb-1 text-muted"><?php echo e($item->bahan); ?></div>
                                        <strong
                                            class="d-inline-block mb-2 text-success <?php echo e(($item->status == 'empty') ? 'text-muted' : ''); ?>">Rp. <?php echo number_format($item->harga,0,',','.'); ?></strong><br>
                                        <a href="<?php echo e(($item->status == 'empty') ? '#' : '/detailmenu/'.$item->id); ?>"
                                            class="text-decoration-none <?php echo e(($item->status == 'empty') ? 'disabled text-secondary' : 'text-primary'); ?>"><?php echo e(($item->status == 'empty') ? 'Empty' : 'Detail menu'); ?></a>
                                    </div>
                                </div>
                            </div>
                        </a>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\di sini\Pejuang Skripsi\Laravel 8\apps\wp-24-01-2022\wp-menu\resources\views/kategori.blade.php ENDPATH**/ ?>