<?php echo $__env->make('partials.navadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('container'); ?>

<div class="container">
    <div class="d-flex flex-column align-items-stretch flex-shrink-0 bg-white mt-4">
        <a href="/" class="d-flex align-items-center flex-shrink-0 p-3 link-dark text-decoration-none">
            <span class="fs-5 fw-semibold"><i class="bi bi-person-workspace fs-3"></i> Admin</span>
        </a>
        <nav class="border-bottom" style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">Admin</li>
                <li class="breadcrumb-item" aria-current="page">Data Admin</li>
                <li class="breadcrumb-item active" aria-current="page">Detail Admin</li>
            </ol>
        </nav>
    </div>


    
    <form action="" method="post">
        <?php echo csrf_field(); ?>
        <div class="container rounded bg-white mb-5">
            <div class="row">
                
                <div class="col-md-3 border-right">
                    <div class="d-flex flex-column align-items-center text-center">
                        <img class="rounded-circle mt-5" style="height:150px; width:150px;"
                            src="<?php echo e(asset('upload/'. $admin->gambar)); ?>"> <br>
                    </div>
                </div>


                <div class="col-md-5 border-right">
                    <div class="p-3 pt-5">
                        <div class="d-flex justify-content-between align-items-center mb-4">
                            <h4 class="text-right">Profile Admin</h4>
                        </div>
                        
                        <div class="row mb-3">
                            <div class="col-md-12"><label class="labels">Nama</label><input type="text"
                                    class="form-control" value="<?php echo e($admin->nama); ?>" disabled>
                            </div>
                        </div>
                        
                        <div class="row mb-3">
                            <div class="col-md-12"><label class="labels">Tempat Lahir</label><input type="text"
                                    class="form-control" value="<?php echo e($admin->tempat_lahir); ?>" disabled>
                            </div>
                        </div>
                        
                        <div class="row mb-3">
                            <div class="col-md-12"><label class="labels">Tgl. Lahir</label><input type="text"
                                    class="form-control" value="<?php echo e($admin->tgl_lahir); ?>" disabled>
                            </div>
                        </div>
                        
                        <div class="row mb-3">
                            <div class="col-md-12"><label class="labels">Gender</label><input type="text"
                                    class="form-control" value="<?php echo e($admin->gender); ?>" disabled>
                            </div>
                        </div>
                        
                        <div class="row mb-3">
                            <div class="col-md-12">
                                <label class="labels">Alamat</label>
                                <textarea class="form-control"
                                    id="exampleFormControlTextarea1" rows="3" name="alamat" disabled>
                                    <?php echo e($admin->alamat); ?>

                                </textarea>
                            </div>
                        </div>
                        
                        <div class="row mb-3">
                            <div class="col-md-12"><label class="labels">No. Tlp</label><input type="text"
                                    class="form-control" value="<?php echo e($admin->no_tlp); ?>" disabled></div>
                        </div>
                    </div>
                </div>


                
                <div class="col-md-4">
                    <div class="p-3 pt-5">
                        <div class="d-flex justify-content-between align-items-center mb-4">
                            <h4>Akses login</h4>
                        </div>
                        
                        <div class="row mb-3">
                            <div class="col-md-12"><label class="labels">Username</label><input type="text"
                                    class="form-control" value="<?php echo e($admin->user->username); ?>" disabled>
                            </div>
                        </div>
                        
                        
                    </div>
                </div>
            </div>
            
            <div class="mt-5 text-center">
                <a href="/admin/<?php echo e($admin->id); ?>/edit" class="text-decoration-none">
                    <button class="btn btn-success profile-button" type="button" data-bs-toggle="modal"
                        data-bs-target="#exampleModal"><i class="bi bi-pencil"></i> Edit Data</button>
                </a>
            </div>
        </div>
    </form>
</div>

<script>
    function myFunction() {
        var x = document.getElementById("pass-able");
        if (x.type === "password") {
            x.type = "text";
        } else {
            x.type = "password";
        }
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\di sini\Pejuang Skripsi\Laravel 8\apps\wp-24-01-2022\wp-menu\resources\views/admin/pegawai/admin/show.blade.php ENDPATH**/ ?>