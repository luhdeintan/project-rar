

<?php echo $__env->make('partials.navadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('container'); ?>
<div class="container">
    <div class="d-flex flex-column align-items-stretch flex-shrink-0 bg-white mt-4">
        <a href="/dashboard-admin" class="d-flex align-items-center flex-shrink-0 p-3 link-dark text-decoration-none">
            <span class="fs-5 fw-semibold"><i class="bi bi-tag fs-3"></i> Kategori</span>
        </a>
        <nav class="border-bottom mb-5" style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">Kategori</li>
                <li class="breadcrumb-item active" aria-current="page">Tabel data</li>
            </ol>
        </nav>
    </div>


    <button class="btn btn-success mb-2" data-bs-toggle="modal" data-bs-target="#add"><i
            class="bi bi-tag"></i> New Kategori</button>
    
    <form action="">
        <div class="modal fade" id="add" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header bg-success text-light">
                        <h5 class="modal-title" id="exampleModalLabel"><i class="bi bi-tag"></i> Tambah
                            Kategori</h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"
                            aria-label="Close"></button>
                    </div>
                    <div class="modal-body mx-3 mb-3">
                        <label class="labels">Kategori</label><input type="text" class="form-control mb-2"
                            placeholder="ex: Snack" value="" name="kategori" required>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button>
                        <button type="button" class="btn btn-success">Tambah</button>
                    </div>
                </div>
            </div>
        </div>
    </form>


    
    <div class="table-responsive-xl">
        <table class="table table-striped table-hover table-bordered">
            <thead class="table-dark">
                <tr>
                    <td>No.</td>
                    <td>Kategori</td>
                    <td>Aksi</td>
                </tr>
            </thead>
            <tbody>
                <td>1</td>
                <td>Espresso</td>
                <td>
                    <a href="/meja/edit/no-meja" class="text-decoration-none" data-bs-toggle="modal"
                        data-bs-target="#edit"><button type="button" class="btn btn-primary"
                            data-bs-toggle="tooltip" data-bs-placement="top" title="edit"><i
                                class="bi bi-pencil"></i></button></a>
                    <a href="#" class="text-decoration-none" data-bs-toggle="modal"
                        data-bs-target="#exampleModal"><button type="button" class="btn btn-danger"
                            data-bs-toggle="tooltip" data-bs-placement="top" title="delete"><i
                                class="bi bi-trash"></i></button></a>
                    
                    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel"
                        aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Hapus</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                        aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    Data yang dihapus tidak dapat diakses kembali. <br> Yakin akan menghapus?
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-light"
                                        data-bs-dismiss="modal">Close</button>
                                    <button type="button" class="btn btn-danger">Hapus</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <form action="" method="post">
                        <div class="modal fade" id="edit" tabindex="-1" aria-labelledby="exampleModalLabel"
                            aria-hidden="true">
                            <div class="modal-dialog modal-dialog-centered">
                                <div class="modal-content">
                                    <div class="modal-header bg-primary text-light">
                                        <h5 class="modal-title" id="exampleModalLabel"><i
                                class="bi bi-pencil"></i> Edit Kategori</h5>
                                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"
                                            aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body mx-3 mb-3">
                                        <label class="labels">No. Meja</label><input type="text"
                                            class="form-control mb-2" placeholder="ex: DE01" value="" name="no_meja"
                                            required>
                                        <label class="labels">Lokasi</label><input type="text" class="form-control"
                                            placeholder="ex: depan" value="" name="lokasi" required>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-light"
                                            data-bs-dismiss="modal">Close</button>
                                        <button type="button" class="btn btn-primary">Edit</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </td>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Punya SAYA\di sini\Pejuang Skripsi\Laravel 8\applications\wp-menu\resources\views/admin/kategori/kategori.blade.php ENDPATH**/ ?>