

<?php echo $__env->make('partials.navuser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('container'); ?>
<div class="container ">
    <div class="p-4 p-md-5 mb-4 text-white rounded bg-dark">
        <div class="col-md-10 px-0">
            <h1 class="display-4 fst-italic">Status Pesanan</h1>
            <p class="lead my-3">Lihat perkembangan pesananmu, bersiap menunggu untuk dihidangkan!</p>
            <p class="lead mb-0 text-white fw-bold">#pesan #status #readyornot</p>
        </div>
    </div>
    
    <div class="card text-white bg-secondary mb-3 mx-auto" style="max-width: 30rem;">
        <div class="card-header">Menunggu</div>
        <div class="card-body">
            <p class="bi bi-clock-history fs-1"></p>
            <h5 class="card-title">Pesanan dalam antrian</h5>
            <p class="card-text">Pesanan masih dalam antrian. Pastikan kembali untuk memesan menu yang tepat sebelum pesanan dibuat.</p>
        </div>
    </div>
    <div class="card text-white bg-warning mb-3 mx-auto" style="max-width: 30rem;">
        <div class="card-header">Racik meracik</div>
        <div class="card-body">
            <p class="bi bi-egg-fill fs-1"></p>
            <h5 class="card-title">Pesanan sedang dibuat</h5>
            <p class="card-text">Sudah siap untuk menunggu aroma nikmat dari pesanan Anda? Denga segera akan kami hidangkan!</p>
        </div>
    </div>
    <div class="card text-white bg-success mb-3 mx-auto" style="max-width: 30rem;">
        <div class="card-header">Segera dihidangkan!</div>
        <div class="card-body">
            <p class="bi bi-patch-check-fill fs-1"></p>
            <h5 class="card-title mb-0">Pesanan Anda telah siap</h5>
            <small class="opacity-50">At 12:00 | Desember 12, 2021</small>
            <p class="card-text mt-3">Selamat menikmati hidangan. Bila perlu tambahan, silahkan memesan kembali.</p>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Punya SAYA\di sini\Pejuang Skripsi\Laravel 8\applications\wp-menu\resources\views/status.blade.php ENDPATH**/ ?>