<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Admin;
use App\Models\Kasir;
use App\Models\Akses;
use App\Models\Pesanan;
use App\Models\Meja;
use App\Models\Kode;
use App\Models\Menu;
use App\Models\Kategori;
use App\Models\User;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        // admin
        Admin::create([
            'nama' => 'Intania',
            'alamat' => 'Jl. Ahmadwani No. 18',
            'tempat_lahir' => 'Karanganyar',
            'tgl_lahir' => '1999-08-29',
            'gender' => 'Perempuan',
            'no_tlp' => '09877',
            'gambar' => 'noimage.jpg',
            'user_id' => 1
        ]);
        Admin::create([
            'nama' => 'Mentari',
            'alamat' => 'Jl. Ahmadwani No. 18',
            'tempat_lahir' => 'Karanganyar',
            'tgl_lahir' => '1999-08-29',
            'gender' => 'Perempuan',
            'no_tlp' => '876534',
            'gambar' => 'noimage.jpg',
            'user_id' => 2
        ]);
        Admin::create([
            'nama' => 'Mustika',
            'alamat' => 'Jl. Ahmadwani No. 18',
            'tempat_lahir' => 'Karanganyar',
            'tgl_lahir' => '1999-08-29',
            'gender' => 'Perempuan',
            'no_tlp' => '087264',
            'gambar' => 'noimage.jpg',
            'user_id' => 3
        ]);


        // kasir
        Kasir::create([
            'nama' => 'Rinjani',
            'alamat' => 'Jl. Ahmadwani No. 18',
            'tempat_lahir' => 'Karanganyar',
            'tgl_lahir' => '1999-08-29',
            'gender' => 'Perempuan',
            'no_tlp' => '4545342',
            'gambar' => 'noimage.jpg',
            'user_id' => 4
        ]);

        Kasir::create([
            'nama' => 'Intania',
            'alamat' => 'Jl. Ahmadwani No. 18',
            'tempat_lahir' => 'Karanganyar',
            'tgl_lahir' => '1999-08-29',
            'gender' => 'Perempuan',
            'no_tlp' => '0823983463',
            'gambar' => 'noimage.jpg',
            'user_id' => 5
        ]);

        Kasir::create([
            'nama' => 'Muhammad',
            'alamat' => 'Jl. Ahmadwani No. 18',
            'tempat_lahir' => 'Karanganyar',
            'tgl_lahir' => '1999-08-29',
            'gender' => 'Laki-laki',
            'no_tlp' => '0823033863',
            'gambar' => 'noimage.jpg',
            'user_id' => 6
        ]);

        //meja
        Meja::create([
            'no_meja' => 'DE01',
            'lokasi' => 'Depan'
        ]);
        Meja::create([
            'no_meja' => 'DE02',
            'lokasi' => 'Depan'
        ]);
        Meja::create([
            'no_meja' => 'DE03',
            'lokasi' => 'Depan'
        ]);
        Meja::create([
            'no_meja' => 'BE01',
            'lokasi' => 'Belakang'
        ]);
        Meja::create([
            'no_meja' => 'BE02',
            'lokasi' => 'Belakang'
        ]);
        Meja::create([
            'no_meja' => 'BE03',
            'lokasi' => 'Belakang'
        ]);
        Meja::create([
            'no_meja' => 'TE01',
            'lokasi' => 'Tengah'
        ]);
        Meja::create([
            'no_meja' => 'TE02',
            'lokasi' => 'Tengah'
        ]);
        Meja::create([
            'no_meja' => 'TE03',
            'lokasi' => 'Tengah'
        ]);
        Meja::create([
            'no_meja' => 'SA01',
            'lokasi' => 'Samping'
        ]);
        Meja::create([
            'no_meja' => 'SA02',
            'lokasi' => 'Samping'
        ]);
        Meja::create([
            'no_meja' => 'SA03',
            'lokasi' => 'Samping'
        ]);

        //akses
        Akses::factory(6)->create();

        //user
        User::factory(6)->create();

        //kalau mau isi dengan nilai tetap, pakai ini aja
        Kategori::create([
            'nama' => 'Kopi Arabika',
            'type' => 'Minuman'
        ]);

        Kategori::create([
            'nama' => 'Kopi Robusta',
            'type' => 'Minuman'
        ]);

        Kategori::create([
            'nama' => 'Esspresso Base',
            'type' => 'Minuman'
        ]);

        Kategori::create([
            'nama' => 'Minuman',
            'type' => 'Minuman'
        ]);

        Kategori::create([
            'nama' => 'Makanan',
            'type' => 'Makanan'
        ]);

        //arabika
        Menu::create([
            "kategori_id" => 1,
            "status" => 'ready',
            "nama" => "Tubruk",
            "harga" => "12000",
            "gambar" => "tubruk-arabika.jpg",
            'bahan' => 'biji kopi, susu',
            'deskripsi' => 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ducimus fuga voluptas quae alias porro aut eum velit id nemo eveniet incidunt praesentium et excepturi eos exercitationem officia dolorem, vero natus?'
        ]);
        Menu::create([
            "kategori_id" => 1,
            "status" => 'ready',
            "nama" => "V60",
            "harga" => "12000",
            "gambar" => "arabika.jpg",
            'bahan' => 'biji kopi, susu',
            'deskripsi' => 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ducimus fuga voluptas quae alias porro aut eum velit id nemo eveniet incidunt praesentium et excepturi eos exercitationem officia dolorem, vero natus?'
        ]);
        Menu::create([
            "kategori_id" => 1,
            "status" => 'ready',
            "nama" => "Vietnam Drip",
            "harga" => "12000",
            "gambar" => "vietnam-drip-arabika.jpg",
            'bahan' => 'biji kopi, susu',
            'deskripsi' => 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ducimus fuga voluptas quae alias porro aut eum velit id nemo eveniet incidunt praesentium et excepturi eos exercitationem officia dolorem, vero natus?'
        ]);

        //robusta
        Menu::create([
            "kategori_id" => 2,
            "status" => 'ready',
            "nama" => "Tubruk",
            "harga" => "8000",
            "gambar" => "tubruk-robusta.jpg",
            'bahan' => 'biji kopi, susu',
            'deskripsi' => 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ducimus fuga voluptas quae alias porro aut eum velit id nemo eveniet incidunt praesentium et excepturi eos exercitationem officia dolorem, vero natus?'
        ]);
        Menu::create([
            "kategori_id" => 2,
            "status" => 'ready',
            "nama" => "Kopi Susu",
            "harga" => "10000",
            "gambar" => "kopi-susu-robusta.jpg",
            'bahan' => 'biji kopi, susu',
            'deskripsi' => 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ducimus fuga voluptas quae alias porro aut eum velit id nemo eveniet incidunt praesentium et excepturi eos exercitationem officia dolorem, vero natus?'
        ]);
        Menu::create([
            "kategori_id" => 2,
            "status" => 'ready',
            "nama" => "V60",
            "harga" => "10000",
            "gambar" => "v60-robusta.jpg",
            'bahan' => 'biji kopi, susu',
            'deskripsi' => 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ducimus fuga voluptas quae alias porro aut eum velit id nemo eveniet incidunt praesentium et excepturi eos exercitationem officia dolorem, vero natus?'
        ]);
        Menu::create([
            "kategori_id" => 2,
            "status" => 'ready',
            "nama" => "Vietnam Drip",
            "harga" => "10000",
            "gambar" => "vietnam-drip-robusta.jpg",
            'bahan' => 'biji kopi, susu',
            'deskripsi' => 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ducimus fuga voluptas quae alias porro aut eum velit id nemo eveniet incidunt praesentium et excepturi eos exercitationem officia dolorem, vero natus?'
        ]);
        Menu::create([
            "kategori_id" => 2,
            "status" => 'ready',
            "nama" => "Hitam Manis",
            "harga" => "10000",
            "gambar" => "hitam-manis-robusta.jpg",
            'bahan' => 'biji kopi, susu',
            'deskripsi' => 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ducimus fuga voluptas quae alias porro aut eum velit id nemo eveniet incidunt praesentium et excepturi eos exercitationem officia dolorem, vero natus?'
        ]);

        //espresso
        Menu::create([
            "kategori_id" => 3,
            "status" => 'ready',
            "nama" => "Espresso",
            "harga" => "10000",
            "gambar" => "espresso-espresso.jpg",
            'bahan' => 'biji kopi, susu',
            'deskripsi' => 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ducimus fuga voluptas quae alias porro aut eum velit id nemo eveniet incidunt praesentium et excepturi eos exercitationem officia dolorem, vero natus?'
        ]);
        Menu::create([
            "kategori_id" => 3,
            "status" => 'ready',
            "nama" => "Espresso Susu",
            "harga" => "12000",
            "gambar" => "espresso-susu-espresso.jpg",
            'bahan' => 'biji kopi, susu',
            'deskripsi' => 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ducimus fuga voluptas quae alias porro aut eum velit id nemo eveniet incidunt praesentium et excepturi eos exercitationem officia dolorem, vero natus?'
        ]);
        Menu::create([
            "kategori_id" => 3,
            "status" => 'ready',
            "nama" => "Espresso Lemon",
            "harga" => "12000",
            "gambar" => "espresso-lemon-espresso.jpg",
            'bahan' => 'biji kopi, susu',
            'deskripsi' => 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ducimus fuga voluptas quae alias porro aut eum velit id nemo eveniet incidunt praesentium et excepturi eos exercitationem officia dolorem, vero natus?'
        ]);
        Menu::create([
            "kategori_id" => 3,
            "status" => 'ready',
            "nama" => "Americano",
            "harga" => "12000",
            "gambar" => "americano-espresso.jpg",
            'bahan' => 'biji kopi, susu',
            'deskripsi' => 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ducimus fuga voluptas quae alias porro aut eum velit id nemo eveniet incidunt praesentium et excepturi eos exercitationem officia dolorem, vero natus?'
        ]);
        Menu::create([
            "kategori_id" => 3,
            "status" => 'ready',
            "nama" => "Cappucino",
            "harga" => "14000",
            "gambar" => "cappucino-espresso.jpg",
            'bahan' => 'biji kopi, susu',
            'deskripsi' => 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ducimus fuga voluptas quae alias porro aut eum velit id nemo eveniet incidunt praesentium et excepturi eos exercitationem officia dolorem, vero natus?'
        ]);
        Menu::create([
            "kategori_id" => 3,
            "status" => 'ready',
            "nama" => "Caffelatte",
            "harga" => "14000",
            "gambar" => "coffee-latte-espresso.jpg",
            'bahan' => 'biji kopi, susu',
            'deskripsi' => 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ducimus fuga voluptas quae alias porro aut eum velit id nemo eveniet incidunt praesentium et excepturi eos exercitationem officia dolorem, vero natus?'
        ]);
        Menu::create([
            "kategori_id" => 3,
            "status" => 'ready',
            "nama" => "Moccacino",
            "harga" => "15000",
            "gambar" => "moccacino-espresso.jpg",
            'bahan' => 'biji kopi, susu',
            'deskripsi' => 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ducimus fuga voluptas quae alias porro aut eum velit id nemo eveniet incidunt praesentium et excepturi eos exercitationem officia dolorem, vero natus?'
        ]);
        Menu::create([
            "kategori_id" => 3,
            "status" => 'ready',
            "nama" => "Orange Americano",
            "harga" => "14000",
            "gambar" => "orange-americano-espresso.jpg",
            'bahan' => 'biji kopi, susu',
            'deskripsi' => 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ducimus fuga voluptas quae alias porro aut eum velit id nemo eveniet incidunt praesentium et excepturi eos exercitationem officia dolorem, vero natus?'
        ]);
        Menu::create([
            "kategori_id" => 3,
            "status" => 'ready',
            "nama" => "Vanilla Latte",
            "harga" => "15000",
            "gambar" => "vanilla-latte-espresso.jpg",
            'bahan' => 'biji kopi, susu',
            'deskripsi' => 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ducimus fuga voluptas quae alias porro aut eum velit id nemo eveniet incidunt praesentium et excepturi eos exercitationem officia dolorem, vero natus?'
        ]);

        //minuman
        Menu::create([
            "kategori_id" => 4,
            "status" => 'ready',
            "nama" => "Cokelat",
            "harga" => "10000",
            "gambar" => "cokelat-minuman.jpg",
            'bahan' => 'bubuk coklat, susu kental manis',
            'deskripsi' => 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ducimus fuga voluptas quae alias porro aut eum velit id nemo eveniet incidunt praesentium et excepturi eos exercitationem officia dolorem, vero natus?'
        ]);
        Menu::create([
            "kategori_id" => 4,
            "status" => 'ready',
            "nama" => "Cokelat Susu",
            "harga" => "14000",
            "gambar" => "coklat-susus-minuman.jpg",
            'bahan' => 'bubuk coklat, susu kental manis',
            'deskripsi' => 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ducimus fuga voluptas quae alias porro aut eum velit id nemo eveniet incidunt praesentium et excepturi eos exercitationem officia dolorem, vero natus?'
        ]);
        Menu::create([
            "kategori_id" => 4,
            "status" => 'ready',
            "nama" => "Greentea",
            "harga" => "10000",
            "gambar" => "greentea-minuman.jpg",
            'bahan' => 'greentea bubuk',
            'deskripsi' => 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ducimus fuga voluptas quae alias porro aut eum velit id nemo eveniet incidunt praesentium et excepturi eos exercitationem officia dolorem, vero natus?'
        ]);
        Menu::create([
            "kategori_id" => 4,
            "status" => 'ready',
            "nama" => "Greentea Susu",
            "harga" => "14000",
            "gambar" => "greentea-susu-minuman.jpg",
            'bahan' => 'greentea bubuk, susu',
            'deskripsi' => 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ducimus fuga voluptas quae alias porro aut eum velit id nemo eveniet incidunt praesentium et excepturi eos exercitationem officia dolorem, vero natus?'
        ]);
        Menu::create([
            "kategori_id" => 4,
            "status" => 'ready',
            "nama" => "Red Velvet",
            "harga" => "10000",
            "gambar" => "red-velvet-minuman.jpg",
            'bahan' => 'red velvet bubuk',
            'deskripsi' => 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ducimus fuga voluptas quae alias porro aut eum velit id nemo eveniet incidunt praesentium et excepturi eos exercitationem officia dolorem, vero natus?'
        ]);
        Menu::create([
            "kategori_id" => 4,
            "status" => 'ready',
            "nama" => "Red Velvet Susu",
            "harga" => "14000",
            "gambar" => "red-velvet-susu-minuman.jpg",
            'bahan' => 'red velvet bubuk, susu',
            'deskripsi' => 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ducimus fuga voluptas quae alias porro aut eum velit id nemo eveniet incidunt praesentium et excepturi eos exercitationem officia dolorem, vero natus?'
        ]);
        Menu::create([
            "kategori_id" => 4,
            "status" => 'ready',
            "nama" => "Teh",
            "harga" => "8000",
            "gambar" => "teh-minuman.jpg",
            'bahan' => 'teh tubruk',
            'deskripsi' => 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ducimus fuga voluptas quae alias porro aut eum velit id nemo eveniet incidunt praesentium et excepturi eos exercitationem officia dolorem, vero natus?'
        ]);
        Menu::create([
            "kategori_id" => 4,
            "status" => 'ready',
            "nama" => "Teh Leci",
            "harga" => "8000",
            "gambar" => "teh-leci-minuman.jpg",
            'bahan' => 'teh tubruk, sirup leci',
            'deskripsi' => 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ducimus fuga voluptas quae alias porro aut eum velit id nemo eveniet incidunt praesentium et excepturi eos exercitationem officia dolorem, vero natus?'
        ]);
        Menu::create([
            "kategori_id" => 4,
            "status" => 'ready',
            "nama" => "Teh Lemon",
            "harga" => "8000",
            "gambar" => "teh-lemon-minuman.jpg",
            'bahan' => 'teh tubruk, sirup lemon, air lemon',
            'deskripsi' => 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ducimus fuga voluptas quae alias porro aut eum velit id nemo eveniet incidunt praesentium et excepturi eos exercitationem officia dolorem, vero natus?'
        ]);
        Menu::create([
            "kategori_id" => 4,
            "status" => 'ready',
            "nama" => "Jahe",
            "harga" => "8000",
            "gambar" => "jahe-minuman.jpg",
            'bahan' => 'jahe seduh, rempah-rempah',
            'deskripsi' => 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ducimus fuga voluptas quae alias porro aut eum velit id nemo eveniet incidunt praesentium et excepturi eos exercitationem officia dolorem, vero natus?'
        ]);
        Menu::create([
            "kategori_id" => 4,
            "status" => 'ready',
            "nama" => "Jahe Susu",
            "harga" => "10000",
            "gambar" => "jahe-susu-minuman.jpg",
            'bahan' => 'jahe seduh, rempah-rempah, susu',
            'deskripsi' => 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ducimus fuga voluptas quae alias porro aut eum velit id nemo eveniet incidunt praesentium et excepturi eos exercitationem officia dolorem, vero natus?'
        ]);
        Menu::create([
            "kategori_id" => 4,
            "status" => 'ready',
            "nama" => "Uwuh",
            "harga" => "10000",
            "gambar" => "wedang-uwuh-minuman.jpg",
            'bahan' => 'bahan uwuh',
            'deskripsi' => 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ducimus fuga voluptas quae alias porro aut eum velit id nemo eveniet incidunt praesentium et excepturi eos exercitationem officia dolorem, vero natus?'
        ]);
        Menu::create([
            "kategori_id" => 4,
            "status" => 'ready',
            "nama" => "Rosela",
            "harga" => "10000",
            "gambar" => "rosela-minuman.jpg",
            'bahan' => 'bunga rosela, teh tubruk',
            'deskripsi' => 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ducimus fuga voluptas quae alias porro aut eum velit id nemo eveniet incidunt praesentium et excepturi eos exercitationem officia dolorem, vero natus?'
        ]);
        Menu::create([
            "kategori_id" => 4,
            "status" => 'ready',
            "nama" => "Avocado",
            "harga" => "10000",
            "gambar" => "avocado-minuman.jpg",
            'bahan' => 'bubuk avocado',
            'deskripsi' => 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ducimus fuga voluptas quae alias porro aut eum velit id nemo eveniet incidunt praesentium et excepturi eos exercitationem officia dolorem, vero natus?'
        ]);
        Menu::create([
            "kategori_id" => 4,
            "status" => 'ready',
            "nama" => "Avocado Susu",
            "harga" => "14000",
            "gambar" => "avocado-milk-minuman.jpg",
            'bahan' => 'bubuk avocado, susu',
            'deskripsi' => 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ducimus fuga voluptas quae alias porro aut eum velit id nemo eveniet incidunt praesentium et excepturi eos exercitationem officia dolorem, vero natus?'
        ]);
        Menu::create([
            "kategori_id" => 4,
            "status" => 'ready',
            "nama" => "kopi-susu-gula-aren-minuman.jpg",
            "harga" => "14000",
            "gambar" => "gula-aren.jpg",
            'bahan' => 'biji kopi, susu, gula aren',
            'deskripsi' => 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ducimus fuga voluptas quae alias porro aut eum velit id nemo eveniet incidunt praesentium et excepturi eos exercitationem officia dolorem, vero natus?'
        ]);
        Menu::create([
            "kategori_id" => 4,
            "status" => 'ready',
            "nama" => "Telang",
            "harga" => "10000",
            "gambar" => "telang-minuman.jpg",
            'bahan' => 'telang seduh',
            'deskripsi' => 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ducimus fuga voluptas quae alias porro aut eum velit id nemo eveniet incidunt praesentium et excepturi eos exercitationem officia dolorem, vero natus?'
        ]);
        Menu::create([
            "kategori_id" => 4,
            "status" => 'ready',
            "nama" => "Telang Susu",
            "harga" => "14000",
            "gambar" => "telang-susu-minuman.jpg",
            'bahan' => 'bunga telang, gula, susu',
            'deskripsi' => 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ducimus fuga voluptas quae alias porro aut eum velit id nemo eveniet incidunt praesentium et excepturi eos exercitationem officia dolorem, vero natus?'
        ]);
        Menu::create([
            "kategori_id" => 4,
            "status" => 'ready',
            "nama" => "Kopi Susu Telang",
            "harga" => "14000",
            "gambar" => "kopi-susu-telang-minuman.jpg",
            'bahan' => 'biji kopi, susu, bunga telang',
            'deskripsi' => 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ducimus fuga voluptas quae alias porro aut eum velit id nemo eveniet incidunt praesentium et excepturi eos exercitationem officia dolorem, vero natus?'
        ]);


        //makanan
        Menu::create([
            "kategori_id" => 5,
            "status" => 'ready',
            "nama" => "Mie Goreng",
            "harga" => "8000",
            "gambar" => "mie-goreng.jpg",
            'bahan' => 'mie',
            'deskripsi' => 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ducimus fuga voluptas quae alias porro aut eum velit id nemo eveniet incidunt praesentium et excepturi eos exercitationem officia dolorem, vero natus?'
        ]);
        Menu::create([
            "kategori_id" => 5,
            "status" => 'ready',
            "nama" => "Mie Rebus",
            "harga" => "8000",
            "gambar" => "mie-rebus.jpg",
            'bahan' => 'mie',
            'deskripsi' => 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ducimus fuga voluptas quae alias porro aut eum velit id nemo eveniet incidunt praesentium et excepturi eos exercitationem officia dolorem, vero natus?'
        ]);
        Menu::create([
            "kategori_id" => 5,
            "status" => 'ready',
            "nama" => "Mie Rebus + Telur",
            "harga" => "10000",
            "gambar" => "mie-rebus-telur.jpg",
            'bahan' => 'mie, telur',
            'deskripsi' => 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ducimus fuga voluptas quae alias porro aut eum velit id nemo eveniet incidunt praesentium et excepturi eos exercitationem officia dolorem, vero natus?'
        ]);
        Menu::create([
            "kategori_id" => 5,
            "status" => 'ready',
            "nama" => "Mie Goreng + Telur",
            "harga" => "10000",
            "gambar" => "mie-goreng-telur.jpg",
            'bahan' => 'mie, telur',
            'deskripsi' => 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ducimus fuga voluptas quae alias porro aut eum velit id nemo eveniet incidunt praesentium et excepturi eos exercitationem officia dolorem, vero natus?'
        ]);
        Menu::create([
            "kategori_id" => 5,
            "status" => 'ready',
            "nama" => "Roti Bakar Coklat",
            "harga" => "8000",
            "gambar" => "roti-bakar-coklat.jpg",
            'bahan' => 'roti, selai cokelat, susu cokelat kental manis',
            'deskripsi' => 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ducimus fuga voluptas quae alias porro aut eum velit id nemo eveniet incidunt praesentium et excepturi eos exercitationem officia dolorem, vero natus?'
        ]);
        Menu::create([
            "kategori_id" => 5,
            "status" => 'ready',
            "nama" => "Roti Bakar Keju",
            "harga" => "8000",
            "gambar" => "roti-bakar-keju.jpg",
            'bahan' => 'roti, keju, susu vanila kental manis',
            'deskripsi' => 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ducimus fuga voluptas quae alias porro aut eum velit id nemo eveniet incidunt praesentium et excepturi eos exercitationem officia dolorem, vero natus?'
        ]);
        Menu::create([
            "kategori_id" => 5,
            "status" => 'ready',
            "nama" => "Roti Bakar Coklat Keju",
            "harga" => "8000",
            "gambar" => "roti-coklat-keju.jpg",
            'bahan' => 'roti, selai cokelat, susu cokelat kental manis, keju',
            'deskripsi' => 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ducimus fuga voluptas quae alias porro aut eum velit id nemo eveniet incidunt praesentium et excepturi eos exercitationem officia dolorem, vero natus?'
        ]);
        Menu::create([
            "kategori_id" => 5,
            "status" => 'ready',
            "nama" => "Tempe Mendoan",
            "harga" => "10000",
            "gambar" => "tempe-mendoan.jpg",
            'bahan' => 'tempe dengan lapis tepung dan daun bawang',
            'deskripsi' => 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ducimus fuga voluptas quae alias porro aut eum velit id nemo eveniet incidunt praesentium et excepturi eos exercitationem officia dolorem, vero natus?'
        ]);
        Menu::create([
            "kategori_id" => 5,
            "status" => 'ready',
            "nama" => "Kentang Goreng",
            "harga" => "10000",
            "gambar" => "kentang-goreng.jpg",
            'bahan' => 'kentang dengan saos mayonaise',
            'deskripsi' => 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ducimus fuga voluptas quae alias porro aut eum velit id nemo eveniet incidunt praesentium et excepturi eos exercitationem officia dolorem, vero natus?'
        ]);
        Menu::create([
            "kategori_id" => 5,
            "status" => 'ready',
            "nama" => "Cireng",
            "harga" => "10000",
            "gambar" => "cireng.jpg",
            'bahan' => 'Berisi daging ayam pedas',
            'deskripsi' => 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ducimus fuga voluptas quae alias porro aut eum velit id nemo eveniet incidunt praesentium et excepturi eos exercitationem officia dolorem, vero natus?'
        ]);
    }
}
