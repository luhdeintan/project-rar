<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePesanansTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('pesanans', function (Blueprint $table) {
            $table->id();
            $table->integer('menu_id');
            $table->string('menu');
            $table->foreignId('kode_id');
            $table->integer('quantity');
            $table->integer('harga');
            $table->integer('jumlah');
            $table->string('status');
            $table->string('note');
            $table->string('message');
            $table->string('checked');
            $table->timestamps();
            $table->boolean('active')->default(1);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('pesanans');
    }
}
