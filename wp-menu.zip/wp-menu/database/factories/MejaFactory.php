<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use Carbon\Carbon;

class MejaFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        // return [
        //     'no_meja' => $this->faker->unique()->bothify('??-##'),
        //     'lokasi' =>$this->faker->shuffle(['Tengah', 'Depan', 'Belakang'])
        // ];
    }
}
