<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

class AdminFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'nama' => $this->faker->name(),
            'alamat' => $this->faker->address(),
            'no_tlp' => $this->faker->phoneNumber(),
            'gambar' => $this->faker->image(),
            'tempat_lahir' => $this->faker->countryCode(),
            'tgl_lahir' => $this->faker->date("Y/m/d"),
            'gender'=> $this->faker->name('Perempuan'),
            // 'akses_id' => mt_rand(1, 3)
        ];
    }
}
