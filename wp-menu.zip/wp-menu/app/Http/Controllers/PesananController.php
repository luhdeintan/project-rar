<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Blade;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;
use App\Models\Pesanan;
use App\Models\Menu;
use App\Models\Kategori;

class PesananController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $kode_id = Auth::guard('akses')->user()->id;

        $request->validate([
            'menu_id' => 'required',
            'quantity' =>'required'
        ]);

        if($request->has('note'))
        {
            $request->validate([
                'note' => 'required'
            ]);

            $note = $request->note;
        } else {
            $note = "none";
        }

        //untuk menu yang sudah ada + tambah quantity
        $menus = Pesanan::where('kode_id', $kode_id)->where('menu_id', $request->menu_id)->where('note', $note)->where('status', 'makeOrder')->first();

        if($menus)
        {
            $add = $menus->quantity + $request->quantity;

            Pesanan::where('id', $menus->id)->update([
                'quantity' => $add,
                'note' => $note,
                'jumlah' => $add * $request->harga
            ]);
        } else {
            $menu = Menu::where('id', $request->menu_id)->first();

        Pesanan::create([
            'menu_id' => $request->menu_id,
            'menu' => $menu->nama,
            'kode_id' => $kode_id,
            'quantity' => $request->quantity,
            'harga' => $request->harga,
            'jumlah' => $request->quantity * $request->harga,
            'note' => $note,
            'status' => 'makeOrder',
            'message' => 'none',
            'checked' => 'none'
        ]);
        }

        return redirect('/keranjang')->with('success', 'Pesanan Anda telah ditambahkan!');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $menu = Menu::find($id);

        Blade::directive('harga', function ( $expression ) {
            return "Rp. <?php echo number_format($expression,0,',','.'); ?>";
        });

		return view('single-menu', [
            'title' => 'Warung Pejalan | ' . $menu->nama,
            'menu' => $menu
        ]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $pesanan = Pesanan::find($id);
        $menu = Menu::where('id', $pesanan->menu_id)->first();

        Blade::directive('harga', function ( $expression ) {
            return "Rp. <?php echo number_format($expression,0,',','.'); ?>";
        });

		return view('single-menu', [
            'title' => 'Warung Pejalan | ' . $pesanan->menu,
            'pesanan' => $pesanan,
            'menu' => $menu
        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        if($request->quantity == null || $request->quantity == 0) {
            Pesanan::find($id)->update([
                'active' => 0
            ]);

            return redirect('/keranjang')->with('success', 'Menu berhasil dihapus dari pesanan!');
        }

        $request->validate([
            'menu_id' => 'required',
            'quantity' =>'required'
        ]);

        if($request->has('note'))
        {
            $request->validate([
                'note' => 'required'
            ]);

            $note = $request->note;
        }
        else {
            $note = "none";
        }

        $menus = Pesanan::find($id);

        //berlaku umtuk minuman saja
        if($note != $request->oldNote)
        {
            //jika note menu berubah menjadi es atau hot dengan menu_id sama
            $sameMenu = Pesanan::where('kode_id', $menus->kode_id)->where('menu_id', $request->menu_id)->where('note', $note)->where('status', 'makeOrder')->first();

            if($sameMenu)
            {
                Pesanan::where('menu_id', $sameMenu->menu_id)->update([
                    'quantity' => $request->quantity + $sameMenu->quantity,
                    'note' => $note,
                    'jumlah' => ($request->quantity + $sameMenu->quantity) * $request->harga
                ]);

                Pesanan::where('id', $id)->delete();
            }

            return redirect('/keranjang')->with('success', 'Menu' . $sameMenu->menu . ' berhasil diubah!');
        }
        //berlaku untuk makanan atau tidak ada perubahan note
        else
        {
            Pesanan::where('id', $menus->id)->update([
                'quantity' => $request->quantity,
                'note' => $note,
                'jumlah' => $request->quantity * $request->harga
            ]);

            return redirect('/keranjang')->with('success', 'Menu' . $menus->menu . ' berhasil diubah!');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        Pesanan::find($id)->update([
            'active' => 0
        ]);

        return redirect('/keranjang')->with('success', 'Menu berhasil dihapus dari pesanan!');
    }

    /**
     * Route keranjang
     *
     * view order list and status
     */
    public function keranjang()
    {
        Blade::directive('rp', function ( $expression ) {
            return "Rp. <?php echo number_format($expression,0,',','.'); ?>";
        });

        $kode = Auth::guard('akses')->user()->id;


        //pesanan yang makeOrder
        $makeOrder = Pesanan::where('kode_id', $kode)->where('status', 'makeOrder')->where('active', 1)->get();
        //pesanan yang waitOrder
        $waitOrder = Pesanan::where('kode_id', $kode)->where('status', 'waitOrder')->where('active', 1)->get();
        //pesanan yang orderProcess
        $orderProcess = Pesanan::where('kode_id', $kode)->where('status', 'orderProcess')->where('active', 1)->get();
        //pesanan yang orderSuccess
        // $orderSuccess = Pesanan::where('kode_id', $kode)->where('status', 'orderSuccess')->where('active', 1)->get();
        $time = Pesanan::where('kode_id', $kode)->where('status', 'orderSuccess')->where('active', 1)->orderBy('updated_at', 'desc')->first();
        // pesana yang orderCanceled
        $orderCanceled = Pesanan::where('kode_id', $kode)->where('status', 'orderCanceled')->where('checked', 'none')->where('active', 1)->get();

        $sumMake = $makeOrder->sum('jumlah');
        $sumWait = $waitOrder->sum('jumlah');
        $sumProcess = $orderProcess->sum('jumlah');
        // $sumSuccess = $orderSuccess->sum('jumlah');

        return view('keranjang', [
            "active" => 'keranjang',
            "title" => 'Warung Pejalan | Keranjang',
            'kode' => $kode,
            'makeOrder' => $makeOrder,
            'sumMake' => $sumMake,
            'waitOrder' => $waitOrder,
            'sumWait' => $sumWait,
            'orderProcess' => $orderProcess,
            'sumProcess' => $sumProcess,
            'time' => $time,
            'orderCanceled' => $orderCanceled
        ]);

    }


    /**
     * makeOrder
     *
     * function untuk mengubah status makeOrder menjadi waitOrder
     */
    public function statusSwitch(Request $request)
    {
        // $data = $request->except('_token');

        $pesanan = Pesanan::where('kode_id', $request->kodeID)->where('active', 1)->get();

        foreach ($pesanan as $p)
        {
            Pesanan::where('kode_id', $request->kodeID)->where('status', 'makeOrder')->update([
                'status' => 'waitOrder'
            ]);
        }

        return redirect('/keranjang')->with('success', 'Pesanan berhasil dikirim! Pesanan Anda sedang dalam proses pembuatan');
    }

    /**
     * confirm cancle
     *
     * konfirmasi pembatalan dari pelanggan
     */
    public function confirmCancle(Request $request, $id)
    {
        Pesanan::find($id)->update([
            'checked' => $request->checked,
            'updated_at' => Carbon::now()
        ]);

        return redirect()->back();
    }
}
