<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Blade;
use Illuminate\Support\Collection;
use Carbon\Carbon;
use App\Models\Admin;
use App\Models\User;
use App\Models\Menu;
use App\Models\Kategori;


class MenuController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    // menampilkan list data
    public function index()
    {
        $user = Auth::id();
        $admin = Admin::where('user_id', $user)->first();
        $level = User::where('id', $user)->first();

        if($level->level == 1 || $level->level == 2){
            $menu = Menu::where('active', 1)->get();
            return view('admin.menu.menu', [
                "active" => 'menu',
                "title" => 'WP-Admin | Menu',
                "menu" => $menu,
                'user' => $user
            ]);
        } else {
            return redirect('/login');
        }
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    //menampilkan halaman creat data (halaman upload data misalnya) ***
    public function create()
    {
        $user = Auth::id();
        $admin = Admin::where('user_id', $user)->first();
        $level = User::where('id', $user)->first();

        if($level->level == 1){
            $kategori = Kategori::all();
            return view('admin.menu.tambah', [
                'title' => 'WP-Admin | Menu',
                'active' => 'menu',
                'kategori' => $kategori
            ]);
        } elseif ($level->level == 2){
            return redirect()->intended('/dashboard');
        } else {
            return redirect('/login');
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    // untuk merekam data ke database (mengupload file)***
    public function store(Request $request)
    {
        $request->validate([
            'nama' => 'required|string|max:255',
            'gambar' => 'image|file|max:1024',
            'harga' => 'required|integer',
            'bahan' => 'required|string',
            'deskripsi' => 'required|string',
            'kategori_id' => 'required',
            'status' => 'required'
        ]);

        $menusama = Menu::where('nama', $request->nama)->where('kategori_id', $request->kategori_id)->where('active', 1)->first();

        if($menusama)
        {
            return redirect()->back()->with('failed', 'Menu dengan kategori sama telah terdaftar!');
        }

        // if ($request->file('gambar')) {
        //     $validateData['gambar'] = $request->file('gambar')->store('menu-img');
        // }

        if ($request->hasFile('gambar')) {
            $file = $request->file('gambar');
            $gambar = md5($file->getClientOriginalName().rand(0000,9999)).'.'.$file->getClientOriginalExtension();
            $file->move('menu-img',$gambar);

            Menu::create([
                'nama' => $request->nama,
                'gambar' => $gambar,
                'harga' => $request->harga,
                'bahan' => $request->bahan,
                'deskripsi' => $request->deskripsi,
                'kategori_id' => $request->kategori_id,
                'status' => $request->status
            ]);
        }

        return redirect('/menu')->with('success', 'Menu baru telah ditambahkan.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    // menampilkan detail data
    public function show($id)
    {
        $user = Auth::id();
        $admin = Admin::where('user_id', $user)->first();
        $level = User::where('id', $user)->first();

        if($level->level == 1){
            $menu = Menu::find($id);
        $kategori = Kategori::all();
            return view('admin.menu.show', [
               'title' => 'WP-Admin | Menu',
               'active' => 'menu',
               'menu' => $menu,
              'kategori' => $kategori
            ]);
        } elseif ($level->level == 2){
            return redirect()->intended('/dashboard');
        } else {
            return redirect('/login');
        }

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    // menampilkan halaman edit data++++
    public function edit($id)
    {
        $user = Auth::id();
        $admin = Admin::where('user_id', $user)->first();
        $level = User::where('id', $user)->first();

        if($level->level == 1 || $level->level == 2){
            $menu = Menu::find($id);
            $kategori = Kategori::where('active', 1)->get();
            return view('admin.menu.edit', [
                'title' => 'WP-Admin | Menu',
                'active' => 'menu',
                'menu' => $menu,
                'kategori' => $kategori
            ]);
        } else {
            return redirect('/login');
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    //untuk mengubah data di database++++
    public function update(Request $request, $id)
    {
        $validateData = $request->validate([
            'nama' => 'required|string|max:255',
            'harga' => 'required|integer',
            'bahan' => 'required|string',
            'deskripsi' => 'required|string',
            'kategori_id' => 'required',
            'status' => 'required'
        ]);

        $menusama = Menu::where('nama', $request->nama)->where('kategori_id', $request->kategori_id)->where('active', 1)->first();

        if($request->oldKategori != $request->kategori_id)
        {
            if($menusama)
            {
                return redirect()->back()->with('failed', 'Menu dengan kategori sama telah terdaftar!');
            }
        }

        $data = [
            'nama' => $request->nama,
            'harga' => $request->harga,
            'bahan' => $request->bahan,
            'deskripsi' => $request->deskripsi,
            'kategori_id' => $request->kategori_id,
            'status' => $request->status
        ];

        if ($request->hasFile('gambar'))
        {
            $request->validate([
                'gambar' => 'image|file|max:1024'
            ]);

            $file = $request->file('gambar');
            $gambar = md5($file->getClientOriginalName().rand(0000,9999)).'.'.$file->getClientOriginalExtension();
            $data['gambar'] = $gambar;
            $file->move('menu-img',$gambar);

            //hapus gambar
            if(file_exists("menu-img/".$request->oldImage)) unlink("menu-img/".$request->oldImage);
        }

        Menu::where('id', $id)->update($data);

        return redirect('/menu')->with('success', 'Menu berhasil di-update!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    //untuk menghapus data dan file
    public function destroy($id)
    {
        $menu = Menu::find($id);
        // karena hanya ubah active, ini dimatikan
        // if ($menu->gambar) {
        //     Storage::delete($menu->gambar);
        // }

        // Menu::destroy($id);
        Menu::find($id)->update([
            'active' => 0
        ]);

        return redirect('/menu')->with('success', 'Menu berhasil dihapus');
    }


    //-----------------------------------------------------------------------------------
    //
    //                              KASIR SECTION
    //
    //----------------------------------------------------------------------------------

    public function statusMenuChange(Request $request, $id)
    {
        Menu::find($id)->update([
            'status' => $request->status,
            'updated_at' => Carbon::today()
        ]);

        $menu = Menu::find($id);

        return redirect()->back()->with('success', "Status " . $menu->nama . " berhasil diubah!");
    }


    //-----------------------------------------------------------------------------------
    //
    //                              PELANGGAN SECTION
    //
    //----------------------------------------------------------------------------------

    public function welcome()
    {

        $kategori = Kategori::where('active', 1);
        $menu = null;

        Blade::directive('currency', function ( $expression ) {
            return "Rp. <?php echo number_format($expression,0,',','.'); ?>";
        });

        if(request('search')){
            $menu = Menu::where('active', 1)->where('nama', 'like', '%' . request('search') . '%')->get();
        }

		return view('menu', [
            "active" => 'menu',
            "title" => 'Warung Pejalan | Welcome!',
            "kategori" => $kategori->get(),
            "menu" => $menu
        ]);
    }

    public function kategori()
    {
        $menu = Menu::where('active', 1)->get();
        $kategori = Kategori::where('active', 1)->get();

        Blade::directive('price', function ( $expression ) {
            return "Rp. <?php echo number_format($expression,0,',','.'); ?>";
        });

			return view('kategori', [
                "active" => 'kategori',
                "title" => 'Warung Pejalan | Kategori',
                "menu" => $menu,
                "kategori" => $kategori
            ]);
    }
}
