<?php

namespace App\Http\Controllers;

use App\Models\Kategori;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class KategoriController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $user = Auth::id();
        $level = User::where('id', $user)->first();

        if($level->level == 1){
            $kategori = Kategori::where('active', 1)->get();
            return view('admin.kategori.kategori', [
                "active" => 'kategori',
                "title" => 'WP-Admin | Kategori',
                "kategori" => $kategori
            ]);
        } elseif ($level->level == 2){
            return redirect()->intended('/dashboard');
        } else {
            return redirect('/login');
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validateData = $request->validate([
            'nama' => 'required|string|max:255',
            'type' => 'required|string|max:255'
        ]);

        $kategoriSama = Kategori::where('nama', $request->nama)->where('active', 1)->first();

        if ($kategoriSama) {
            return redirect('/kategori')->with('failed', 'Kategori dengan nama sama sudah terdaftar!');
        }

        Kategori::create($validateData);

        return redirect('/kategori')->with('success', 'Kategori baru telah ditambahkan.');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Kategori  $kategori
     * @return \Illuminate\Http\Response
     */
    public function show(Kategori $kategori)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Kategori  $kategori
     * @return \Illuminate\Http\Response
     */
    public function edit(Kategori $kategori)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Kategori  $kategori
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Kategori $kategori)
    {

        $validateData = $request->validate([
            'nama' => 'required|string|max:255',
            'type' => 'required|string|max:255'
        ]);

        $kategoriSama = Kategori::where('nama', $request->nama)->where('active', 1)->first();

        if($request->oldKategori != $request->nama) {
            if ($kategoriSama)
            {
                return redirect('/kategori')->with('failed', 'Kategori dengan nama sama sudah terdaftar!');
            }
        }

        Kategori::where('id', $kategori->id)->update($validateData);

        return redirect('/kategori')->with('success', 'Kategori berhasil di-update!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Kategori  $kategori
     * @return \Illuminate\Http\Response
     */
    public function destroy(Kategori $kategori)
    {
        // Kategori::destroy($kategori->id);
        $kategori->update([
            'active' => 0
        ]);
        return redirect('/kategori')->with('success', 'Kategori berhasil dihapus');
    }
}
