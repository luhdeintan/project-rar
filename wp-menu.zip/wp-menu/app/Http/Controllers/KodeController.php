<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Carbon;
use App\Models\Kode;
use App\Models\Meja;
use App\Models\User;
use \Milon\Barcode\DNS1D;
use \Milon\Barcode\DNS2D;
// use SimpleSoftwareIO\QrCode\Facades\QrCode;

class KodeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //auth
        $id = Auth::id();
        $user = User::where('id', $id)->first();

        if ($user->level == 1 || $user->level == 2) {
            return view('admin.qrcode.qrcode', [
                "active" => 'qrcode',
                "title" => 'Warung Pejalan | QR-Code',
                "kode" => Kode::where('active', 1)->orderBy('updated_at', 'desc')->get(),
                "meja" => Meja::where('active', 1)->orderBy('updated_at', 'desc')->get(),
                "mejaselect" => Meja::where('active', 1)->orderBy('updated_at', 'desc')->get(),
                "user" => $user->level
            ]);
        } else {
            return redirect('/login');
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // no meja is id meja
        $request->validate([
            'no_meja' => 'required'
        ]);

        // apakah data memiliki id dengan status yang sama, count hanya bisa digunakan dengan menggunakan get saja
        $mejaReady = Kode::where('meja_id', $request->no_meja)->where('active', 1)->where('status', "ready")->get();
        $mejaUsed = Kode::where('meja_id', $request->no_meja)->where('active', 1)->where('status', "used")->get();

        if ($mejaUsed->count() || $mejaReady->count()) {
            return back()->with('failed', 'Meja yang sama masih aktif');
        } else {
            $current_time = \Carbon\Carbon::now()->timestamp;
            $kodeGenerate = $request->no_meja . '-' . $current_time;

            Kode::create([
                'meja_id' => $request->no_meja,
                'kode_generate' => $kodeGenerate
            ]);

            return redirect('/qrcode')->with('success', 'Kode baru telah ditambahkan.');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        // no meja is id meja
        $request->validate([
            'no_meja' => 'required',
            'status' => 'required'
        ]);

        if ($request->oldMeja != $request->no_meja) {
            if ($request->status == 'ready' || $request->status == 'used') {
                $kodeUsed = Kode::where('meja_id', $request->no_meja)->where('status', 'used')->where('active', 1)->first();
                $kodeReady = Kode::where('meja_id', $request->no_meja)->where('status', 'ready')->where('active', 1)->first();

                if ($kodeUsed || $kodeReady) {
                    return back()->with('failed', 'Status Meja telah terdaftar dalam tabel');
                }
            }
        }

        $current_time = \Carbon\Carbon::now()->timestamp;
        $kodeGenerate = $request->no_meja . '-' . $current_time;

        Kode::find($id)->update([
            'meja_id' => $request->no_meja,
            'status' => $request->status,
            'kode_generate' => $kodeGenerate
        ]);

        return redirect('/qrcode')->with('success', 'Kode baru telah diupdate.');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        // Kode::destroy($id);

        Kode::find($id)->update([
            'active' => 0
        ]);

        return redirect('/qrcode')->with('success', 'Kode berhasil dihapus');
    }

    public function print($kode_generate)
    {
        //auth
        $id = Auth::id();
        $user = User::where('id', $id)->first();

        $kode = Kode::where('active', 1)->where('kode_generate', $kode_generate)->first();

        if ($user->level == 1 || $user->level == 2) {
            return view('admin.qrcode.print', [
                "kode" => $kode
            ]);
        } else {
            return redirect('/login');
        }
    }
}
