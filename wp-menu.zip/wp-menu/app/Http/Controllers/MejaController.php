<?php

namespace App\Http\Controllers;

use App\Models\Meja;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;

class MejaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $user = Auth::id();
        $level = User::where('id', $user)->first();

        if($level->level == 1){
            $meja = Meja::where('active', 1)->get();
            return view('admin.meja.meja', [
                "active" => 'meja',
                "title" => 'WP-Admin | Meja',
                "meja" => $meja
            ]);
        } elseif ($level->level == 2){
            return redirect()->intended('/dashboard');
        } else {
            return redirect('/login');
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validateData = $request->validate([
            'no_meja' => 'required|string|max:255',
            'lokasi' => 'required|string|max:255'
        ]);

        $mejaSama = Meja::where('no_meja', $request->no_meja)->where('active', 1)->first();

        if($mejaSama){
            return back()->with('failed', 'Meja dengan nomor sama telah terdaftar!');
        } else {
            Meja::create($validateData);
            return redirect('/meja')->with('success', 'Meja baru telah ditambahkan.');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Meja  $meja
     * @return \Illuminate\Http\Response
     */
    public function show(Meja $meja)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Meja  $meja
     * @return \Illuminate\Http\Response
     */
    public function edit(Meja $meja)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Meja  $meja
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Meja $meja)
    {
        $validateData = $request->validate([
            'no_meja' => 'required|string|max:255',
            'lokasi' => 'required|string|max:255'
        ]);

        // cek no meja berubah atau tidak
        if($request->oldMeja != $request->no_meja){
            //meja sama
            $mejaSama = Meja::where('no_meja', $request->no_meja)->where('active', 1)->first();
            if($mejaSama)
            {
                return back()->with('failed', 'Nomor Meja yang diinput telah terdaftar!');
            } else {
                Meja::where('id', $meja->id)->update($validateData);

                return redirect('/meja')->with('success', 'Meja berhasil di-update!');
            }
        } else {
            Meja::where('id', $meja->id)->update($validateData);

            return redirect('/meja')->with('success', 'Meja berhasil di-update!');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Meja  $meja
     * @return \Illuminate\Http\Response
     */
    public function destroy(Meja $meja)
    {
        // Meja::destroy($meja->id);
        $meja->update([
            'active' => 0
        ]);
        return redirect('/meja')->with('success', 'Meja berhasil dihapus');
    }
}
