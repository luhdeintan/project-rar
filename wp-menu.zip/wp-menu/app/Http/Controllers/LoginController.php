<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Blade;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Crypt;
use App\Models\User;
use App\Models\Admin;
use App\Models\Kode;
use App\Models\Kasir;
use App\Models\Pesanan;
use Carbon\Carbon;

class LoginController extends Controller
{
    public function index()
    {
        return view('login', [
            'title' => 'Cafe WP | Login'
        ]);
    }

    public function authenticate(Request $request)
    {
        $credentials = $request->validate([
            'username' => 'required',
            'password' => 'required'
        ]);

        if(Auth::attempt($credentials)) {
            $request->session()->regenerate();

            $user = User::where('username', $request->username)->first();

            if($user->level == 1) {
                return redirect()->intended('/dashboard-admin');
            }
            elseif($user->level == 2){
                return redirect()->intended('/dashboard');
            } else {
                return redirect('/login')->with('loginError', 'Password atau Username Anda salah!');
            }
        } else {
            return redirect('/login')->with('loginError', 'Password atau Username Anda salah!');
        }
    }

    public function logout()
    {
        Auth::logout();

        request()->session()->invalidate();

        request()->session()->regenerateToken();

        return redirect('/login');
    }

    //admin dashboard
    public function adminDashboard()
    {
        $user = Auth::id();
        $admin = Admin::where('user_id', $user)->first();
        $level = User::where('id', $user)->first();

        $sumUser = Kode::where('status','finish')->where('active', 1)->whereDate('updated_at', date('Y-m-d'))->count();
        // $sumUserYesterday = Kode::where('status','finish')->where('updated_at', $yesterday)->count();
        $sumOrder = Pesanan::where('status','orderSuccess')->where('active', 1)->whereDate('updated_at', date('Y-m-d'))->sum('jumlah');
        // $sumOrderYesterday = Pesanan::where('status','orderSuccess')->where('updated_at', Carbon::now())->sum('jumlah');

        Blade::directive('rupiahnya', function ( $expression ) {
            return "Rp. <?php echo number_format($expression,0,',','.'); ?>";
        });


        if($level->level === 1) {
            return view('admin.dashboard', [
                "active" => 'dashboard',
                "title" => 'WP-Admin | Admin',
                "admin" => $admin,
                "user" => $sumUser,
                "order" => $sumOrder
            ]);
        } elseif ($level->level === 2) {
            return redirect('/dashboard');
        }
        else {
            return redirect('/login');
        }

    }

    //admin profile is here
    public function show()
    {
        $user = Auth::id();
        $admin = Admin::where('user_id', $user)->first();
        $level = User::where('id', $user)->first();


        if($level->level == 1)
        {
            return view('admin.profile', [
                "active" => 'profile',
                "title" => 'WP-Admin | Profile',
                "admin" => $admin,
                "user" => $user
            ]);
        } elseif ($level->level == 2) {
            return redirect('/dashboard');
        }
        else {
            return redirect('/login');
        }
    }

    // kasir profile is here
    public function showKasir()
    {
        $user = Auth::id();
        $kasir = Kasir::where('user_id', $user)->first();
        $level = User::where('id', $user)->first();

        if($level->level == 2)
        {
            return view('kasir.profile', [
                "active" => 'profile',
                "title" => 'WP-Kasir | Profile',
                "kasir" => $kasir,
                "user" => $user
            ]);
        } elseif ($level->level == 1) {
            return redirect('/dashboard-admin');
        }
        else {
            return redirect('/login');
        }
    }

    //update profile admin
    public function profileAdmin(Request $request, $id)
    {
        // $auth = Auth::user();
        $request->validate([
            'nama' => 'required|string|max:255',
            'tempat_lahir' => 'required|string|max:255',
            'tgl_lahir' => 'required|date|max:255',
            'gender' => 'required|max:255',
            'alamat' => 'required|string|max:255',
            'no_tlp' => 'required|numeric|digits_between:11,12',
            'username' => 'required|string'
        ]);

        //cekusername and number
        if($request->oldUsername != $request->username || $request->oldNumber != $request->no_tlp)
        {
            $tlp = Kasir::where('no_tlp', $request->no_tlp)->where('active', 1)->first();
            $username = User::where('username', $request->username)->where('active', 1)->first();

            if ($request->oldUsername != $request->username && $request->oldNumber != $request->no_tlp){
                if ($tlp && $username) {
                    return back()->with('failed', 'Username dan No.tlp telah terdaftar.');
                }

            } elseif ($request->oldNumber != $request->no_tlp) {
                if ($tlp) {
                    return back()->with('failed', 'No.tlp telah terdaftar');
                }
            } else {
                if ($username) {
                    return back()->with('failed', 'Username telah terdaftar');
                }
            }
            // if($request->oldUsername != $request->username && $request->oldNumber != $request->no_tlp)
            // {
            //     $request->validate([
            //         'username' => 'required|unique:users',
            //         'no_tlp'=>'required|unique:admins'
            //     ]);
            // } elseif ($request->oldUsername != $request->username) {
            //     $request->validate([
            //         'username' => 'required|unique:users'
            //     ]);
            // } else {
            //     $request->validate([
            //         'no_tlp'=>'required|unique:admins'
            //     ]);
            // }

            //update username
            User::find($id)->update(['username' => $request->username]);
        }

        //cek password
        if($request->password_baru !== null)
        {
            $request->validate([
            'password' => 'required|max:225'
            ]);

            if(Hash::check($request->password, $request->oldPassword) == false)
            {
                return back()->with('failed', 'Password lama Anda tidak sesuai');
            } else {
                User::find($id)->update(['password' => Hash::make($request->password_baru)]);
            }
        }

        $data = [
            'nama' => $request->nama,
            'tempat_lahir' => $request->tempat_lahir,
            'tgl_lahir' => $request->tgl_lahir,
            'gender' => $request->gender,
            'alamat' => $request->alamat,
            'no_tlp' => $request->no_tlp
        ];

        //cek gambar
        if ($request->hasFile('gambar')) {

            $request->validate([
                'gambar' => 'image|file|max:1024'
            ]);

            $file = $request->file('gambar');
            $gambar = md5($file->getClientOriginalName().rand(0000,9999)).'.'.$file->getClientOriginalExtension();
            $data['gambar'] = $gambar;
            $file->move('upload',$gambar);

            //hapus gambar
            if(file_exists("upload/".$request->gambar)) unlink("upload/".$request->gambar);
        }

        //update data
        auth()->user()->admin->update($data);


        return redirect('/profile')->with('success', 'Profile telah diperbarui.');
    }

    //update profile kasir
    public function profileKasir(Request $request, $id)
    {
        $request->validate([
            'nama' => 'required|max:255',
            'tempat_lahir' => 'required|max:255',
            'tgl_lahir' => 'required|max:255',
            'gender' => 'required|max:255',
            'alamat' => 'required|max:255',
            'no_tlp'=>'required|numeric|digits_between:11,12',
            'username' => 'required|string'
        ]);

        //cekusername
        if($request->oldUsername != $request->username || $request->oldNumber != $request->no_tlp)
        {
            $tlp = Kasir::where('no_tlp', $request->no_tlp)->where('active', 1)->first();
            $username = User::where('username', $request->username)->where('active', 1)->first();

            if ($request->oldUsername != $request->username && $request->oldNumber != $request->no_tlp){
                if ($tlp && $username) {
                    return back()->with('failed', 'Username dan No.tlp telah terdaftar.');
                }

            } elseif ($request->oldNumber != $request->no_tlp) {
                if ($tlp) {
                    return back()->with('failed', 'No.tlp telah terdaftar');
                }
            } else {
                if ($username) {
                    return back()->with('failed', 'Username telah terdaftar');
                }
            }

            // if($request->oldUsername != $request->username && $request->oldNumber != $request->no_tlp)
            // {
            //     $request->validate([
            //         'username' => 'required|unique:users',
            //         'no_tlp'=>'required|numeric|digits_between:11,12|unique:kasirs'
            //     ]);
            // } elseif ($request->oldUsername != $request->username) {
            //     $request->validate([
            //         'username' => 'required|unique:users'
            //     ]);
            // } else {
            //     $request->validate([
            //         'no_tlp'=>'required|numeric|digits_between:11,12|unique:kasirs'
            //     ]);
            // }

            //update username. Karena dibuat oleh admin, jadi kalau berubah saja baru disimpan perubahannya
            User::find($id)->update(['username' => $request->username]);
        }

        //cek password
        if($request->password_baru !== null)
        {
            $request->validate([
            'password' => 'required|max:225'
            ]);

            if(Hash::check($request->password, $request->oldPassword) == false)
            {
                return back()->with('failed', 'Password lama Anda tidak sesuai');
            } else {
                User::find($id)->update(['password' => Hash::make($request->password_baru)]);
            }
        }

        $data = [
            'nama' => $request->nama,
            'tempat_lahir' => $request->tempat_lahir,
            'tgl_lahir' => $request->tgl_lahir,
            'gender' => $request->gender,
            'alamat' => $request->alamat,
            'no_tlp' => $request->no_tlp
        ];

        //cek gambar
        if ($request->hasFile('gambar')) {

            $request->validate([
                'gambar' => 'image|file|max:1024'
            ]);

            $file = $request->file('gambar');
            $gambar = md5($file->getClientOriginalName().rand(0000,9999)).'.'.$file->getClientOriginalExtension();
            $data['gambar'] = $gambar;
            $file->move('upload',$gambar);

            //hapus gambar
            if(file_exists("upload/".$request->gambar)) unlink("upload/".$request->gambar);
        }

        //update data
        auth()->user()->kasir->update($data);

        return redirect('/profileupdate')->with('success', 'Profile telah diperbarui.');
    }
}
