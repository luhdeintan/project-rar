<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Blade;
use App\Models\Pesanan;
use App\Models\User;
use Carbon\Carbon;
use App\Models\Kode;
use App\Models\Menu;
use App\Models\Kategori;

class InfoController extends Controller
{
    public function detailPesanan()
    {
        $kode = Auth::guard('akses')->user()->id;

        //pesanan yang orderSuccess
        $bill = Pesanan::where('kode_id', $kode)->where('status', 'orderSuccess')->where('checked','OK')->orderBy('updated_at', 'desc')->whereDate('updated_at', Carbon::today())->first();
        $bills = Pesanan::where('kode_id', $kode)->where('status', 'orderSuccess')->where('checked','OK')->get();
        $sum = $bills->sum('jumlah');

        // dd($bill);

        Blade::directive('rp', function ( $expression ) {
            return "Rp. <?php echo number_format($expression,0,',','.'); ?>";
        });


        return view('detail-pesanan', [
            "active" => 'detail',
            "title" => 'Warung Pejalan | Detail Pesanan',
            'bill' => $bill,
            'bills' => $bills,
            'sum' => $sum
        ]);
    }

    public function dashboardList()
    {
        $user = Auth::id();
        $level = User::where('id', $user)->first();

        if($level->level === 2){
            return view('kasir.dashboard', [
                'title' => 'WP-Kasir | Dashboard',
                'active' => 'dashboard',
                'pesanan' => Pesanan::where('status', 'waitOrder')->where('active', 1)->get()
            ]);
        } elseif($level->level === 1){
            return redirect('/dashboard-admin');
        } else {
            return redirect('/login');
        }
    }

    public function addProcess(Request $request)
    {
        $pesan = Pesanan::where('id', $request->id_pesan)->update([
            'status' => 'orderProcess',
            'updated_at' => Carbon::now()
        ]);

        return redirect('/dashboard')->with('success', 'Pesanan ditambahkan dalam process!');
    }

    public function indexProcess()
    {
        $pesan = Pesanan::where('status','orderProcess')->oldest()->get();
        return view('kasir.process', [
            "active" => 'progress',
            "title" => 'WP-Kasir | Process',
            "pesanan" => $pesan
        ]);
    }

    public function finishProcess(Request $request)
    {
        $pesan = Pesanan::where('id', $request->id_pesan)->update([
            'status' => 'orderSuccess',
            'updated_at' => Carbon::now(),
            'checked' => 'OK'
        ]);

        return redirect()->back()->with('success', 'Proses berhasil!');
    }

    public function canceledProcess(Request $request, $id)
    {
        $request->validate([
            'message' => 'required|string'
        ]);

        Pesanan::where('id', $id)->update([
            'status' => 'orderCanceled',
            'message' => $request->message
        ]);

        return redirect()->back()->with('success', 'Pesanan telah dibatalkan!');
    }

    // for kasir
    public function history()
    {

        $historySuccess = Pesanan::whereDate('updated_at', date('Y-m-d'))->orderBy('updated_at', 'desc')->where('status', 'orderSuccess')->where('active', 1)->get();
        $historyCanceled = Pesanan::whereDate('updated_at', date('Y-m-d'))->orderBy('updated_at', 'desc')->where('status', 'orderCanceled')->where('active', 1)->get();


        return view('kasir.history', [
            "active" => 'history',
            "title" => 'WP-Kasir | History',
            'historySuccess' => $historySuccess,
            'historyCanceled' => $historyCanceled
        ]);
    }

    //for admin
    public function historySale()
    {
        Blade::directive('rp', function ( $expression ) {
            return "Rp. <?php echo number_format($expression,0,',','.'); ?>";
        });

        $historyall = Kode::where('status','finish')->where('active', 1)->orderBy('updated_at', 'desc')->get();

        return view('admin.history', [
            "active" => 'history',
            "title" => 'WP-Admin | History',
            'history' => $historyall
        ]);
    }

    public function historyDelete($id)
    {
        $pesanan = Pesanan::where('kode_id', $id)->get();

        foreach($pesanan as $p){
            $p->update([
                'active' => 0
            ]);
        }
        // $pesanan->destroy();

        // Kode::find($id)->delete();
        Kode::find($id)->update([
            'active' => 0
        ]);

        return redirect()->back()->with('success', 'History telah dihapus');
    }

    public function menuStatusIndex()
    {
        //
    }

    public function menuStatusUpdate()
    {
        //
    }
}
