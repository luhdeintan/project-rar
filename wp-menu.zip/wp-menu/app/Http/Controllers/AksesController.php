<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Kode;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redis;
use Illuminate\Support\Facades\Validator;

class AksesController extends Controller
{
    //halaman pertama
    public function index(Request $request)
    {
        return view('akses', [
            'title' => 'Cafe WP | Login'
        ]);
    }


    //membuat session
    public function makeSession(Request $request)
    {
        $credential = $request->validate([
            'kode_generate' => 'required'
        ]);

        // $id = explode("-", $request->kode_generate);

        // $kodeReady = Kode::where('meja_id', $id[0])->where('active', 1)->where('status', 'ready')->exists();
        $kodeReady = Kode::where('kode_generate', $request->kode_generate)->where('active', 1)->where('status', 'ready')->exists();
        // $kodeUsed = Kode::where('meja_id', $id[0])->where('status', 'used')->where('active', 1)->exists();
        $kodeUsed = Kode::where('kode_generate', $request->kode_generate)->where('status', 'used')->where('active', 1)->exists();

        if ($kodeReady){
                Kode::where('kode_generate', $request->kode_generate)->update([
                    'status' => 'used',
                    'updated_at' => Carbon::today()
                ]);
                $user = Kode::where('kode_generate', $request->kode_generate)->first();

                Auth::guard('akses')->login($user);
                return redirect('/welcome');
            }
            elseif ($kodeUsed) {
                $user = Kode::where('kode_generate', $request->kode_generate)->first();

                Auth::guard('akses')->login($user);
                return redirect('/welcome');
            } else {
                return redirect('/')->with('failed', 'Kode tidak valid!');
        }
	}


    public function signout()
    {
        if (Auth::guard('akses')->check()) {
            Auth::guard('akses')->logout();
          }

        return redirect('/');
    }
}
