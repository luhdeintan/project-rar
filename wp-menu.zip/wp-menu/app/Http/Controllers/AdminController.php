<?php

namespace App\Http\Controllers;

use App\Models\Admin;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class AdminController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $user = Auth::id();
        $level = User::where('id', $user)->first();

        if($level->level == 1){
            // $admin = Admin::all();
            $admin = Admin::where('active', 1)->get();
            return view('admin.pegawai.admin.admin', [
                "active" => 'admin',
                "title" => 'WP-Admin | Admin',
                "admin" => $admin,
            ]);
        } elseif ($level->level == 2){
            return redirect()->intended('/dashboard');
        } else {
            return redirect('/login');
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $user = Auth::id();
        $level = User::where('id', $user)->first();

        if($level->level == 1){
            return view('admin.pegawai.admin.tambah', [
                'title' => 'WP-Admin | Admin',
                'active' => 'admin'
            ]);
        } elseif ($level->level == 2){
            return redirect()->intended('/dashboard');
        } else {
            return redirect('/login');
        }

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'nama' => 'required|string|max:255',
            'gambar' => 'required|image|file|max:1024',
            'tempat_lahir' => 'required|string|max:255',
            'tgl_lahir' => 'required|date|max:255',
            'gender' => 'required',
            'alamat' => 'required|string|max:255',
            'no_tlp' => 'required|numeric|digits_between:11,12',
            'username' => 'required|string',
            'password' => 'required|string|max:225',
            'level' =>'required'
        ]);

        if ($request->no_tlp || $request->username) {
            $tlpSama = Admin::where('no_tlp', $request->no_tlp)->where('active', 1)->first();
            $usernameSama = User::where('username', $request->username)->where('active', 1)->first();

            if($tlpSama && $usernameSama) {
                $request->validate([
                    'no_tlp' => 'unique:admins',
                    'username' => 'unique:users'
                ]);
            } elseif ($tlpSama) {
                $request->validate([
                    'no_tlp' => 'unique:admins'
                ]);
            } else {
                $request->validate([
                    'username' => 'unique:users'
                ]);
            }
        }

        if ($request->hasFile('gambar')) {
            $file = $request->file('gambar');
            $gambar = md5($file->getClientOriginalName().rand(0000,9999)).'.'.$file->getClientOriginalExtension();
            $file->move('upload',$gambar);
            User::create([
                'username' => $request->username,
                'password' => Hash::make($request->password),
                'level' => $request->level
            ])->admin()->create([
                'nama' => $request->nama,
                'gambar' => $gambar,
                'tempat_lahir' => $request->tempat_lahir,
                'tgl_lahir' => $request->tgl_lahir,
                'gender' => $request->gender,
                'alamat' => $request->alamat,
                'no_tlp' => $request->no_tlp
            ]);
        }

        return redirect('/admin')->with('success', 'Admin baru telah ditambahkan.');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Admin  $admin
     * @return \Illuminate\Http\Response
     */
    public function show(Admin $admin)
    {
        $user = Auth::id();
        $level = User::where('id', $user)->first();

        if($level->level == 1){
            return view('admin.pegawai.admin.show', [
                'title' => 'WP-Admin | Admin',
                'active' => 'admin',
                'admin' => $admin
            ]);
        } elseif ($level->level == 2){
            return redirect()->intended('/dashboard');
        } else {
            return redirect('/login');
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Admin  $admin
     * @return \Illuminate\Http\Response
     */
    public function edit(Admin $admin)
    {
        $user = Auth::id();
        $level = User::where('id', $user)->first();

        if($level->level == 1){
            $admin = $admin;
            return view('admin.pegawai.admin.edit', [
                'title' => 'WP-Admin | Pegawai Admin',
                'active' => 'admin',
                'admin' => $admin
            ]);
        } elseif ($level->level == 2){
            return redirect()->intended('/dashboard');
        } else {
            return redirect('/login');
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Admin  $admin
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Admin $admin)
    {
        $request->validate([
            'nama' => 'required|string|max:255',
            'tempat_lahir' => 'required|string|max:255',
            'tgl_lahir' => 'required|date|max:255',
            'gender' => 'required',
            'alamat' => 'required|string|max:255',
            'username' => 'required|string|max:255',
            'no_tlp'=>'required|numeric|digits_between:11,12'
        ]);

        //cekusername dan no tlp
        if($request->oldUsername != $request->username || $request->oldNumber != $request->no_tlp)
        {
            $tlpSama = Admin::where('no_tlp', $request->no_tlp)->where('active', 1)->first();

            if($request->oldUsername != $request->username && $request->oldNumber != $request->no_tlp){
                $request->validate([
                    'username' => 'required|string|unique:users',
                    'no_tlp'=>'required|numeric|digits_between:11,12'
                ]);

                if($tlpSama){
                    $request->validate([
                        'no_tlp'=>'required|numeric|digits_between:11,12|unique:admins'
                    ]);
                }
            } elseif($request->oldUsername != $request->username) {
                $request->validate([
                    'username' => 'required|string|unique:users'
                ]);
            } else {
                $request->validate([
                    'no_tlp'=>'required|numeric|digits_between:11,12'
                ]);

                if($tlpSama){
                    $request->validate([
                        'no_tlp'=>'required|numeric|digits_between:11,12|unique:admins'
                    ]);
                }
            }
        }

        //cek password
        if($request->password !== null)
        {
            $request->validate([
            'password' => 'required|string|max:225'
            ]);
        }

        $data = [
            'nama' => $request->nama,
            'tempat_lahir' => $request->tempat_lahir,
            'tgl_lahir' => $request->tgl_lahir,
            'gender' => $request->gender,
            'alamat' => $request->alamat,
            'no_tlp' => $request->no_tlp,
        ];

        //cek gambar
        if ($request->hasFile('gambar')) {

            $request->validate([
                'gambar' => 'image|file|max:1024'
            ]);

            $file = $request->file('gambar');
            $gambar = md5($file->getClientOriginalName().rand(0000,9999)).'.'.$file->getClientOriginalExtension();
            $data['gambar'] = $gambar;
            $file->move('upload',$gambar);

            //hapus gambar
            if(file_exists("upload/".$admin->gambar)) unlink("upload/".$admin->gambar);
        }

        $admin->update($data);

        if($request->password){
            $admin->user->update([
            'password' => Hash::make($request->password)
            ]);
        }

        if($request->username){
            $admin->user->update([
                'username' => $request->username,
            ]);
        }

        return redirect('/admin')->with('success', 'Data Admin telah diperbarui.');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Admin  $admin
     * @return \Illuminate\Http\Response
     */
    public function destroy(Admin $admin)
    {
        // karena hanya di ubah activenya, ini dimatikan
        // if(file_exists("upload/".$admin->gambar)) unlink("upload/".$admin->gambar);

        // $admin->user->delete();
        // $admin->delete();
        $admin->update([
            'active' => 0
        ]);
        $admin->user->update([
            'active' => 0
        ]);

        return redirect('/admin')->with('success', 'Admin berhasil dihapus');
    }
}
