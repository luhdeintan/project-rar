<?php

namespace App\Http\Controllers;

use App\Models\Kasir;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class KasirController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $user = Auth::id();
        $level = User::where('id', $user)->first();

        if($level->level == 1){
            $kasir = Kasir::where('active', 1)->get();
            return view('admin.pegawai.kasir.kasir', [
                "active" => 'kasir',
                "title" => 'WP-Admin | Kasir',
                "kasir" => $kasir,
            ]);
        } elseif ($level->level == 2){
            return redirect()->intended('/dashboard');
        } else {
            return redirect('/login');
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $user = Auth::id();
        $level = User::where('id', $user)->first();

        if($level->level == 1){
            return view('admin.pegawai.kasir.tambah', [
                'title' => 'WP-Admin | Kasir',
                'active' => 'kasir',
            ]);
        } elseif ($level->level == 2){
            return redirect()->intended('/dashboard');
        } else {
            return redirect('/login');
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'nama' => 'required|string|max:255',
            'gambar' => 'required|image|file|max:1024',
            'tempat_lahir' => 'required|string|max:255',
            'tgl_lahir' => 'required|date|max:255',
            'gender' => 'required',
            'alamat' => 'required|string|max:255',
            'password' => 'required|string|max:225',
            'level' =>'required'
        ]);

        if ($request->no_tlp || $request->username) {
            $tlpSama = Kasir::where('no_tlp', $request->no_tlp)->where('active', 1)->first();
            $usernameSama = User::where('username', $request->username)->where('active', 1)->first();

            if($tlpSama && $usernameSama) {
                $request->validate([
                    'no_tlp' => 'required|numeric|digits_between:11,12|unique:kasirs',
                    'username' => 'required|string|unique:users'
                ]);
            } elseif ($tlpSama) {
                $request->validate([
                    'no_tlp' => 'required|numeric|digits_between:11,12|unique:kasirs'
                ]);
            } else {
                $request->validate([
                    'username' => 'required|string|unique:users'
                ]);
            }
        }

        if ($request->hasFile('gambar')) {
            $file = $request->file('gambar');
            $gambar = md5($file->getClientOriginalName().rand(0000,9999)).'.'.$file->getClientOriginalExtension();
            $file->move('upload', $gambar);
            User::create([
                'username' => $request->username,
                'password' => Hash::make($request->password),
                'level' => $request->level
            ])->kasir()->create([
                'nama' => $request->nama,
                'gambar' => $gambar,
                'tempat_lahir' => $request->tempat_lahir,
                'tgl_lahir' => $request->tgl_lahir,
                'gender' => $request->gender,
                'alamat' => $request->alamat,
                'no_tlp' => $request->no_tlp
            ]);
        }

        return redirect('/kasir')->with('success', 'Kasir baru telah ditambahkan.');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Kasir  $kasir
     * @return \Illuminate\Http\Response
     */
    public function show(Kasir $kasir)
    {
        $user = Auth::id();
        $level = User::where('id', $user)->first();

        if($level->level == 1){
            return view('admin.pegawai.kasir.show', [
                'title' => 'WP-Admin | Kasir',
                'active' => 'kasir',
                'kasir' => $kasir
            ]);
        } elseif ($level->level == 2){
            return redirect()->intended('/dashboard');
        } else {
            return redirect('/login');
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Kasir  $kasir
     * @return \Illuminate\Http\Response
     */
    public function edit(Kasir $kasir)
    {
        $user = Auth::id();
        $level = User::where('id', $user)->first();

        if($level->level == 1){
            $data = $kasir;
            return view('admin.pegawai.kasir.edit', [
                'title' => 'WP-Admin | Pegawai Kasir',
                'active' => 'kasir',
                'kasir' => $data
            ]);
        } elseif ($level->level == 2){
            return redirect()->intended('/dashboard');
        } else {
            return redirect('/login');
        }
    }
    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Kasir  $kasir
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Kasir $kasir)
    {
        $request->validate([
            'nama' => 'required|string|max:255',
            'tempat_lahir' => 'required|string|max:255',
            'tgl_lahir' => 'required|date|max:255',
            'gender' => 'required|max:255',
            'alamat' => 'required|string|max:255',
            'username' => 'required|string|max:255',
            'no_tlp'=>'required|numeric|digits_between:11,12'
        ]);

        //cekusername
        if($request->oldUsername != $request->username || $request->oldNumber != $request->no_tlp)
        {
            $tlpSama = Kasir::where('no_tlp', $request->no_tlp)->where('active', 1)->first();
            if($request->oldUsername != $request->username && $request->oldNumber != $request->no_tlp){
                $request->validate([
                    'username' => 'required|string|unique:users',
                    'no_tlp'=>'required|numeric|digits_between:11,12'
                ]);

                if($tlpSama){
                    $request->validate([
                        'no_tlp'=>'required|numeric|digits_between:11,12|unique:kasirs'
                    ]);
                }
            } elseif($request->oldUsername != $request->username){
                $request->validate([
                    'username' => 'required|string|unique:users'
                ]);
            } else {
                $request->validate([
                    'no_tlp'=>'required|numeric|digits_between:11,12'
                ]);
                if($tlpSama){
                    $request->validate([
                        'no_tlp'=>'required|numeric|digits_between:11,12|unique:kasirs'
                    ]);
                }
            }
        }

        //cek password
        if($request->password !== null)
        {
            $request->validate([
            'password' => 'string|max:225'
            ]);
        }

        $data = [
            'nama' => $request->nama,
            'tempat_lahir' => $request->tempat_lahir,
            'tgl_lahir' => $request->tgl_lahir,
            'gender' => $request->gender,
            'alamat' => $request->alamat,
            'no_tlp' => $request->no_tlp,
        ];

        //cek gambar
        if ($request->hasFile('gambar')) {

            $request->validate([
                'gambar' => 'image|file|max:1024'
            ]);

            $file = $request->file('gambar');
            $gambar = md5($file->getClientOriginalName().rand(0000,9999)).'.'.$file->getClientOriginalExtension();
            $data['gambar'] = $gambar;
            $file->move('upload',$gambar);

            //hapus gambar
            if(file_exists("upload/".$kasir->gambar)) unlink("upload/".$kasir->gambar);
        }

        $kasir->update($data);

        if($request->password){
            $kasir->user->update([
            'password' => Hash::make($request->password)
            ]);
        }

        if($request->username){
            $kasir->user->update([
                'username' => $request->username,
            ]);
        }

        return redirect('/kasir')->with('success', 'Data Kasir telah diperbarui.');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Kasir  $kasir
     * @return \Illuminate\Http\Response
     */
    public function destroy(Kasir $kasir)
    {
        // karena hanya diubah activenya, maka ini dimatikan
        // if(file_exists("upload/".$kasir->gambar)) unlink("upload/".$kasir->gambar);

        //delete tabel user
        // $kasir->user->delete();
        $kasir->user->update([
            'active' => 0
        ]);

        //delete table kasir
        // $kasir->delete();
        $kasir->update([
            'active' => 0
        ]);

        return redirect('/kasir')->with('success', 'Kasir berhasil dihapus');
    }
}
