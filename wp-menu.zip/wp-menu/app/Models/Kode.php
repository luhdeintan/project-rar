<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Foundation\Auth\User as Authenticatable;

class Kode extends Authenticatable
{
    protected $guarded = ['id'];

    protected $guard = 'akses';

    use HasFactory;

    public function meja()
    {
        return $this->belongsTo(Meja::class);
    }

    public function pesanan()
    {
        return $this->hasMany(Pesanan::class);
    }
}
