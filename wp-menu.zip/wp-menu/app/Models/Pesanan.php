<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Psy\TabCompletion\Matcher\FunctionsMatcher;

class Pesanan extends Model
{
    protected $guarded = ['id'];

    use HasFactory;
    // public function admin()
    // {
    //     return $this->hasMany(Menu::class);
    //

    public function kode()
    {
        return $this->belongsTo(Kode::class);
    }

    // public function menu()
    // {
    //     return $this->hasMany(Menu::class);
    // }
}
