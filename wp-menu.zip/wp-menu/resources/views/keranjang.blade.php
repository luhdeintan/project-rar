@extends('layouts.base')

@include('partials.navuser')

@section('container')
<div class="container">
    <div class="p-4 p-md-5 mb-4 text-white rounded bg-dark">
        <div class="col-md-10 px-0">
            <h3 class="display-6 fst-italic">Keranjang Pesanan</h3>
            <p class="my-3">Cek daftar dan status pesananmu di sini!</p>
            <small class="mb-0 text-white fw-bold">#pesan #daftarpesan</small>
        </div>
    </div>

    {{-- tombol tambah pesanan --}}
    @if(!$makeOrder->count() && !$waitOrder->count() && !$orderProcess->count())
    <div class="d-grid gap-2 d-lg-flex justify-content-lg-end">
        <a href="/kategorimenu" class="btn btn-success btn-lg btn-block my-2" data-toggle="button" aria-pressed="false"
            autocomplete="off"><i class="bi bi-plus"></i> Mulai Pesan</a>
    </div>
    @endif

    {{-- tidak ada pesanan --}}
    @if(!$makeOrder->count() && !$waitOrder->count() && !$orderProcess->count())
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <strong>Pesanan kosong.</strong> Pilih menu untuk melakukan proses pemesanan.
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    @endif

    {{-- order confirm canceled --}}
    @if ($orderCanceled->count())
    @foreach ($orderCanceled as $cancle)
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <i class="bi bi-exclamation-triangle-fill"></i>
        <strong>{{ $cancle->menu }}
            @if ($cancle->note != 'none')
            <span
                class="{{ $cancle->note == 'Hot' ? 'badge bg-danger' : 'badge bg-primary' }}">{{ $cancle->note }}</span>
            @endif dibatalkan. </strong>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        <br>
        <div class="mt-3">
            {{ucfirst(trans($cancle->message))}}
            <form id="form" action="/confirmcancle/{{ $cancle->id }}" method="post">
                @csrf
                <div class="form-check">
                    <input class="form-check-input" onchange="$('#form').submit();" type="checkbox" value="OK"
                        name="checked" id="defaultCheck1">
                    <label class="form-check-label" for="defaultCheck1">
                        Konfirmasi pembatalan.
                    </label>
                </div>
            </form>
        </div>
    </div>
    @endforeach
    @endif

    @if (session()->has('success'))
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Berhasil</strong> {{ session('success') }}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    @endif




    {{-- Start -> Pesanan Make Order --}}
    @if ($makeOrder->count())
    <form action="/pesan" method="post" class="my-5">
        @csrf
        <input type="hidden" name="kodeID" value="{{ $kode}}">
        <span class="badge bg-primary mb-3 mt-4 text-end d-flex px-4 py-2">Make Order</span>
        <ol class="list-group list-group-numbered">
            @foreach ($makeOrder as $pesan)
            <li class="list-group-item d-flex justify-content-between align-items-start">
                <div class="ms-2 me-auto">
                    {{-- menu name --}}
                    <div class="fw-bold"> {{ \Illuminate\Support\Str::limit($pesan->menu, 10, $end='...') }}
                        {{-- if note not null --}}
                        <span
                            class="{{ $pesan->note == "Iced" ? "badge bg-info text-dark mr-1" : "" }} {{ $pesan->note == "Hot" ? "badge bg-danger mr-1" : "" }}">{{ $pesan->note == "Iced" || $pesan->note == "Hot" ? $pesan->note : "" }}</span>
                        {{-- quantity --}}
                        <span class="badge bg-secondary rounded-pill"> {{ $pesan->quantity }}</span>
                    </div>
                    @rp($pesan->harga)
                </div>
                {{-- edit menu link --}}
                <a href="/detailmenu/{{ $pesan->id }}/edit"><span class="badge rounded-pill bg-primary my-2 mx-2 p-2"><i
                            class="bi bi-pencil-fill"></i></span></a>
                {{-- delete menu --}}
                <a href="#" class="text-decoration-none" data-bs-target="#hapusPesanan{{ $pesan->id }}"
                    data-bs-toggle="modal"><span class="badge rounded-pill bg-danger my-2 mx-2 p-2"><i
                            class="bi bi-trash-fill"></i></span></a>
            </li>
            @endforeach
            {{-- price --}}
            <p class="list-group-item list-group-item-success text-end fw-bold mb-0">Total : @rp($sumMake)</p>
        </ol>

        {{-- kirim dan tambah menu --}}
        <div class="d-grid gap-2 d-lg-flex justify-content-lg-end">
            <a href="/kategorimenu" class="btn btn-primary btn-lg btn-block my-2" data-toggle="button"
                aria-pressed="false" autocomplete="off">Tambah pesanan <i class="bi bi-plus-lg"></i></a>
            <button type="button" class="btn btn-outline-primary btn-lg btn-block my-2" aria-pressed="false"
                autocomplete="off" data-bs-target="#kirim" data-bs-toggle="modal">Kirim</button>
            {{-- modal kirim --}}
            <div class="modal fade" id="kirim" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Kirim Pesanan</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            Mulai mengirim pesanan Anda?
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Kirim</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>
    {{-- modal delete --}}
    @foreach ($makeOrder as $pesan)
    <div class="modal fade" id="hapusPesanan{{ $pesan->id }}" tabindex="-1"
        aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">" {{ $pesan->menu }} "</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                        aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    Pesanan <span class="font-weight-bold"
                        style="font-weight: bold;">{{ $pesan->menu }}</span>
                    akan dihapus. Yakin akan menghapus?
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button>
                    <form action="detailmenu/{{ $pesan->id }}" method="post">
                        @method('delete')
                        @csrf
                        <button type="submit" class="btn btn-danger">Hapus</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    @endforeach
    @endif





    {{-- Start-> Pesanan Wait Order --}}
    @if ($waitOrder->count())
    <div class="card text-white bg-secondary mx-auto mt-5" style="border-radius: 5px 5px 0px 0px">
        <div class="card-header">Wait Order</div>
        <div class="card-body">
            <p class="bi bi-clock-history fs-1"></p>
            <h5 class="card-title">Dalam antrian</h5>
            <p class="card-text">Pesanan menunggu untuk segera dibuat. Tunggu beberapa saat lagi.</p>
        </div>
    </div>
    {{-- <span class="badge bg-secondary mt-5 mb-3 text-end d-flex px-4 py-2 text-light">Wait Order</span> --}}
    <ol class="list-group list-group-numbered mb-3" style="border-radius: 0px 0px 5px 5px">
        @foreach ($waitOrder as $pesan)
        <li class="list-group-item d-flex justify-content-between align-items-start">
            <div class="ms-2 me-auto">
                {{-- menu name --}}
                <div class="fw-bold">{{ \Illuminate\Support\Str::limit($pesan->menu, 10, $end='...') }}
                    {{-- if note not null --}}
                    <span
                        class="{{ $pesan->note == "Iced" ? "badge bg-info text-dark mr-1 rounded-pill" : "badge bg-danger mr-1 rounded-pill" }}">{{ $pesan->note == "Iced" || $pesan->note == "Hot" ? $pesan->note : "" }}</span>
                    {{-- quantity --}}
                    <span class="badge bg-secondary rounded-pill"> {{ $pesan->quantity }}</span>
                </div>
                @rp($pesan->harga)
            </div>
        </li>
        @endforeach
        {{-- price --}}
        <p class="list-group-item list-group-item-success text-end mb-5 fw-bold">Total : @rp($sumWait)</p>
    </ol>
    {{-- End-> Pesanan Wait Order --}}
    @endif




    {{-- Start-> Pesanan Order Process --}}
    @if ($orderProcess->count())
    <div class="card text-dark bg-warning mt-3 mx-auto" style="border-radius: 5px 5px 0px 0px">
        <div class="card-header">In the Process</div>
        <div class="card-body">
            <p class="bi bi-egg-fried fs-1"></p>
            <h5 class="card-title">Sedang dibuat</h5>
            <p class="card-text">Pesanan yang telah selesai dapat Anda lihat di tab <strong><a href="/detail-pesanan"
                        class="link-dark">Detail Pesanan</a></strong> . </p>
        </div>
    </div>
    {{-- <span class="badge bg-warning mt-5 mb-3 text-end d-flex px-4 py-2" style="color: black">Wait Order</span> --}}
    <ol class="list-group list-group-numbered mb-3" style="border-radius: 0px 0px 5px 5px">
        @foreach ($orderProcess as $pesan)
        <li class="list-group-item d-flex justify-content-between align-items-start">
            <div class="ms-2 me-auto">
                {{-- menu name --}}
                <div class="fw-bold">{{ \Illuminate\Support\Str::limit($pesan->menu, 10, $end='...') }}
                    @if ($pesan->note != 'none')
                    <span
                        class="{{ $pesan->note == "Iced" ? "badge bg-info text-dark mr-1 rounded-pill" : "" }} {{ $pesan->note == "Hot" ? "badge bg-danger mr-1 rounded-pill" : "" }}">{{ $pesan->note == "Iced" || "Hot" ? $pesan->note : "" }}</span>
                    @endif
                    {{-- quantity --}}
                    <span class="badge bg-secondary rounded-pill"> {{ $pesan->quantity }}</span>
                </div>
                @rp($pesan->harga)
            </div>
        </li>
        @endforeach
        {{-- price --}}
        <p class="list-group-item list-group-item-success text-end mb-5 fw-bold">Total : @rp($sumProcess)</p>
    </ol>
    {{-- End-> Pesanan Wait Order --}}
    @endif

</div>
@endsection
