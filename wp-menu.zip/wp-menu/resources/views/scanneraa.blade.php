<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.88.1">
    <title>{{ $title }}</title>

    <link rel="canonical" href="https://getbootstrap.com/docs/5.1/examples/sign-in/">
    {{-- <link rel="stylesheet" href="{{ asset('js/jquery.min.js') }}">
    <link rel="stylesheet" href="{{ asset('js/instascan.min.js') }}"> --}}

    <!-- Bootstrap core CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    <style>
        .bd-placeholder-img {
            font-size: 1.125rem;
            text-anchor: middle;
            -webkit-user-select: none;
            -moz-user-select: none;
            user-select: none;
        }

        @media (min-width: 768px) {
            .bd-placeholder-img-lg {
                font-size: 3.5rem;
            }
        }
    </style>
    <!-- Custom styles for this template -->
    <link href="/css/signin.css" rel="stylesheet">
</head>
<body>
    <div class="container">
        <h3 class="text-center">QR-Code Scanner</h3>
        <div class="row">
            <div class="col-sm-4 mx-auto">
                <div id="reader" width="100%" class="mt-4"></div>
            </div>
            <div class="row">
                <div class="col-md-5 mx-auto mt-3 text-center">
                    <a href="/" class="text-decoration-none text-white mx-auto"><button class="w-50 btn btn-lg btn-primary my-3">Back</button></a>
                </div>
            </div>
        </div>
    </div>
    <script src="https://unpkg.com/html5-qrcode" type="text/javascript"></script>
    <script>
        // function onScanSuccess(decodedText, decodedResult) {
        //     // handle the scanned code as you like, for example:
        //     console.log(`Code matched = ${decodedText}`, decodedResult);
        // }

        // function onScanFailure(error) {
        //     // handle scan failure, usually better to ignore and keep scanning.
        //     // for example:
        //     console.warn(`Code scan error = ${error}`);
        // }

        // let html5QrcodeScanner = new Html5QrcodeScanner(
        //     "reader", {
        //         fps: 10,
        //         qrbox: {
        //             width: 250,
        //             height: 250
        //         }
        //     },
        //     /* verbose= */
        //     false);
        //     html5QrcodeScanner.render(onScanSuccess, onScanFailure);


        function onScanSuccess(decodedText, decodedResult) {
            // handle the scanned code as you like, for example:
            console.log(`Code matched = ${decodedText}`, decodedResult);
            document.getElementById('result').innerHTML = '<input class="result" type="hidden" value="'+ decodedResult +'" name="kode_generate"> <button type="submit" class="btn btn-success">Login Now!</button>';
        }

        function onScanFailure(error) {
            // handle scan failure, usually better to ignore and keep scanning.
            // for example:
            console.warn(`Code scan error = ${error}`);
        }

        let html5QrcodeScanner = new Html5QrcodeScanner(
            "reader", {
                fps: 10,
                qrbox: {
                    width: 250,
                    height: 250
                }
            });
        html5QrcodeScanner.render(onScanSuccess, onScanFailure);
    </script>
</body>
</html>
