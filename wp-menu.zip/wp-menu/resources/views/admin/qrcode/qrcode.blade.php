@extends('layouts.base')

@if($user == 1)
@include('partials.navadmin')
@else
@include('partials.navkasir')
@endif

@section('container')
<div class="container">
    <div class="d-flex flex-column align-items-stretch flex-shrink-0 bg-white mt-4">
        <a href="/dashboard-admin" class="d-flex align-items-center flex-shrink-0 p-3 link-dark text-decoration-none">
            <span class="fs-5 fw-semibold"><i class="bi bi-qr-code-scan fs-3"></i> QR-Code</span>
        </a>
        <nav class="border-bottom mb-5" style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">QR-Code</li>
                <li class="breadcrumb-item active" aria-current="page">Tabel data</li>
            </ol>
        </nav>
    </div>

    @if (session()->has('success'))
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Berhasil!</strong> {{ session('success') }}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    @endif

    @if (session()->has('failed'))
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <strong>Gagal!</strong> {{ session('failed') }}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    @endif

    <button class="btn btn-success mb-2" data-bs-toggle="modal" data-bs-target="#add">
        <i class="bi bi-qr-code-scan"></i> New QR-Code
    </button>
    {{-- modal tambah--}}
    <form action="/qrcode" method="POST">
        @csrf
        <div class="modal fade" id="add" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header bg-success text-light">
                        <h5 class="modal-title mx-3" id="exampleModalLabel"><i class="bi bi-qr-code-scan"></i> Tambah
                            QR-Code
                        </h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"
                            aria-label="Close"></button>
                    </div>
                    <div class="modal-body mx-3 my-3 pb-5">
                        {{-- no meja --}}
                        <div class="">
                            <label class="labels">No. Meja</label>
                            <div class="mb-5"
                                style="width:100%; padding:20px 30px 20px 0px; height: 100px; position: absolute; display:block">
                                <select class="form-select @error('no_meja') is-invalid @enderror"
                                    aria-label="Default select example" name="no_meja" onfocus='this.size=3;'
                                    onblur='this.size=1;' onchange='this.size=1; this.blur();'
                                    style="overflow-y: scroll">
                                    @foreach ($mejaselect as $m)
                                    <option value="{{ $m->id }}">{{ $m->no_meja }}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer mt-5">
                        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-success">Tambah</button>
                    </div>
                </div>
            </div>
        </div>
    </form>

    {{-- table --}}
    <div class="table-responsive">
        <table id="datatable" class="table table-striped table-hover cell-border table-borderless">
            <thead class="table-dark">
                <tr>
                    <td>#</td>
                    <td>ID Meja</td>
                    <td>Kode Generate</td>
                    <td>Waktu</td>
                    <td>Status</td>
                    <td>Aksi</td>
                </tr>
            </thead>
            <tbody>
                @if ($kode->count())
                @foreach ($kode as $kode)
                <tr>
                    <td>{{ $loop->iteration }}</td>
                    <td>{{ $kode->meja->active == 0 ? 'EMPTY' : $kode->meja->no_meja }}</td>
                    <td>{{ $kode->kode_generate }}</td>
                    <td>{{ $kode->updated_at }}</td>
                    <td>
                        @if ($kode->status == 'ready')
                        <span class="badge bg-primary">READY</span>
                        @elseif ($kode->status == 'used')
                        <span class="badge bg-success">USED</span>
                        @else
                        <span class="badge bg-secondary">FINISH</span>
                        @endif
                    </td>
                    <td>
                        @if ($user == 1)
                        @if ($kode->status != 'finish')
                        <a href="/print/{{ $kode->kode_generate }}" target="_blank" class="text-decoration-none"><button type="button" class="btn btn-primary"
                            title="print"><i
                               class="bi bi-printer"></i></button></a>
                        @endif
                        <a href="#" class="text-decoration-none"><button type="button" class="btn btn-warning"
                                data-bs-toggle="modal" data-bs-target="#edit{{ $kode->id }}" title="edit"><i
                                    class="bi bi-pencil"></i></button></a>
                        <a href="#" class="text-decoration-none"><button type="button" class="btn btn-danger"
                                data-bs-toggle="tooltip" data-bs-placement="top" title="delete"><i class="bi bi-trash"
                                    data-bs-toggle="modal" data-bs-target="#delete{{ $kode->id }}"></i></button></a>
                        @endif
                        @if ($user == 2)
                        @if ($kode->status != 'finish')
                        <a href="/print/{{ $kode->kode_generate }}" target="_blank" class="text-decoration-none"><button type="button" class="btn btn-primary"
                                 title="print"><i
                                    class="bi bi-printer"></i></button></a>
                        @endif
                        <a href="#" class="text-decoration-none"><button type="button" class="btn btn-warning"
                                data-bs-toggle="modal" data-bs-target="#edit{{ $kode->id }}" title="edit"><i
                                    class="bi bi-pencil"></i></button></a>
                        @endif
                        {{-- modal edit --}}
                        <form action="/qrcode/{{ $kode->id }}" method="POST">
                            @csrf
                            @method('put')
                            <input type="hidden" value="{{ $kode->meja_id }}" name="oldMeja">
                            <div class="modal fade" id="edit{{ $kode->id }}" tabindex="-1"
                                aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog modal-dialog-centered">
                                    <div class="modal-content">
                                        <div class="modal-header bg-warning text-dark">
                                            <h5 class="modal-title mx-3" id="edit{{ $kode->id }}"><i
                                                    class="bi bi-qr-code-scan"></i> Edit
                                                QR-Code
                                            </h5>
                                            <button type="button" class="btn-close btn-close-white"
                                                data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body mx-3 my-3" style="height: 210px">
                                            {{-- status --}}
                                            <div class="mb-3 mt-0 pt-2">
                                                <label class="labels">Status</label>
                                                <select class="form-select @error('status') is-invalid @enderror"
                                                    aria-label="Default select example" name="status">
                                                    @if (old('status') == $kode->status)
                                                    <option value="{{ $kode->status }}" selected>
                                                        {{ $kode->status }}</option>
                                                    @else
                                                    <option value="{{ $kode->status }}" selected>
                                                        {{ strtoupper($kode->status) }}</option>
                                                    <option value="ready">READY</option>
                                                    <option value="used">USED</option>
                                                    <option value="finish">FINISH</option>
                                                    @endif
                                                </select>
                                            </div>
                                            {{-- no meja --}}
                                            <div class="mb-3">
                                                <label class="labels">No. Meja</label>
                                                <div class="mb-5"
                                                    style="width:100%; margin-right:20px; padding:6px 30px 20px 0px; height: 100px; position: absolute; display:block">
                                                    <select class="form-select @error('no_meja') is-invalid @enderror"
                                                        aria-label="Default select example" name="no_meja"
                                                        onfocus='this.size=3;' onblur='this.size=1;'
                                                        onchange='this.size=1; this.blur();' style="overflow-y: scroll">
                                                        @if (old('no_meja') == $m->id)
                                                        <option value="{{ $m->id }}" selected>
                                                            {{ $m->no_meja }}</option>
                                                        @else
                                                        <option value="{{ $kode->meja_id }}" selected>
                                                            {{ $kode->meja->no_meja }}</option>
                                                        @endif
                                                        @foreach ($mejaselect as $m)
                                                        <option value="{{ $m->id }}">{{ $m->no_meja }}</option>
                                                        @endforeach
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-light"
                                                data-bs-dismiss="modal">Close</button>
                                            <button type="submit" class="btn btn-warning">Edit</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                        {{-- modal delete --}}
                        <div class="modal fade" id="delete{{ $kode->id }}" tabindex="-1"
                            aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Hapus</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                            aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        Data yang dihapus tidak dapat diakses kembali. <br> Yakin akan menghapus?
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-light"
                                            data-bs-dismiss="modal">Close</button>
                                        <form action="/qrcode/{{ $kode->id }}" method="post">
                                            @method('delete')
                                            @csrf
                                            <button type="submit" class="btn btn-danger">Hapus</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </td>
                </tr>
            </tbody>
            @endforeach
            @else
            <div class="alert alert-warning alert-dismissible fade show" role="alert">
                <strong>Data kosong!</strong> Tambahkan data untuk mengisi tabel.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            @endif
        </table>
    </div>

</div>

@endsection
