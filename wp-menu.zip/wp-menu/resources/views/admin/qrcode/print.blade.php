<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Print QR-Code</title>
    <style>
        @media print {
            body * {
                visibility: hidden;
            }

            #section-to-print,
            #section-to-print * {
                visibility: visible;
            }

            #section-to-print {
                position: absolute;
                left: 0;
                top: 0;
            }
        }

        @media print {
            @page {
                margin-top: 0;
                margin-bottom: 0;
                /* size: 58mm 58mm; */
            }

            body {
                padding-top: 72px;
                padding-bottom: 72px;
                /* max-width: 58mm;
                max-height: 100mm; */
            }
        }

    </style>
</head>
<body>
    <div style="">
        <div style="width:147px; height:232px" id="section-to-print">
            <h3 style="text-align:center">{{ $kode->kode_generate }}</h3>
            {!! DNS2D::getBarcodeSVG($kode->kode_generate, 'QRCODE', 7,7) !!}
        </div>
        <form class="">
            <input type="button" value="Print"
                   onclick="window.print()"/>
        </form>
    </div>
</body>
</html>
