@extends('layouts.base')

@include('partials.navadmin')

@section('container')
<div class="container">
    <div class="d-flex flex-column align-items-stretch flex-shrink-0 bg-white mt-4">
        <a href="/dashboard-admin" class="d-flex align-items-center flex-shrink-0 p-3 link-dark text-decoration-none">
            <span class="fs-5 fw-semibold"><i class="bi bi-clock-history fs-3"></i> History</span>
        </a>
        <nav class="border-bottom mb-5" style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">History</li>
                <li class="breadcrumb-item active" aria-current="page">list</li>
            </ol>
        </nav>
    </div>

    @if (session()->has('success'))

    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Berhasil!</strong> {{ session('success') }}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    @endif

    {{-- table --}}
    <div class="table-responsive">
        <table id="datatable" class="table table-striped table-hover cell-border table-borderless">
            <thead class="table-dark">
                <tr>
                    <td>#</td>
                    <td>Kode</td>
                    <td>Meja</td>
                    <td>Waktu</td>
                    <td>Aksi</td>
                </tr>
            </thead>
            <tbody>
                @if ($history->count())
                @foreach ($history as $history)
                <tr>
                    <td>{{ $loop->iteration }}</td>
                    <td>{{ $history->kode_generate }}</td>
                    <td>{{ $history->meja->no_meja }}</td>
                    <td>{{ $history->updated_at }}</td>
                    <td>
                        <a href="#" class="text-decoration-none"><button type="button" class="btn btn-primary"
                            data-bs-toggle="modal" data-bs-target="#detail{{ $history->id }}" title="detail"><i
                                class="bi bi-eye"></i></button></a>
                        <a href="#" class="text-decoration-none" data-bs-toggle="modal"
                            data-bs-target="#exampleModal{{ $history->id }}"><button type="button"
                                class="btn btn-danger" data-bs-toggle="tooltip" data-bs-placement="top"
                                title="delete"><i class="bi bi-trash"></i></button></a>
                        {{-- modal delete--}}
                        <div class="modal fade" id="exampleModal{{ $history->id }}" tabindex="-1"
                            aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Hapus History</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                            aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        Data yang dihapus tidak dapat diakses kembali. <br> Yakin akan menghapus?
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-light"
                                            data-bs-dismiss="modal">Close</button>
                                        <form action="/historypenjualan/{{ $history->id }}" method="post">
                                            @method('put')
                                            @csrf
                                            <button type="submit" class="btn btn-danger">Hapus</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        {{-- modal detail --}}
                        <div class="modal fade" id="detail{{ $history->id }}" tabindex="-1"
                            aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-centered">
                                <div class="modal-content">
                                    <div class="modal-header bg-primary text-light">
                                        <h5 class="modal-title mx-3" id="exampleModalLabel">{{ $history->meja->no_meja }}
                                        </h5>
                                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"
                                            aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body my-3">
                                        <table class="table table-borderless">
                                            <thead>
                                              <tr>
                                                <th scope="col">Menu</th>
                                                <th scope="col">Qty</th>
                                                <th scope="col">Harga</th>
                                              </tr>
                                            </thead>
                                            <tbody>
                                                @php
                                                    $total = 0;
                                                @endphp
                                                @foreach ($history->pesanan as $menu)
                                                @if ($menu->status == "orderSuccess")
                                                <tr>
                                                    <td>{{ $menu->menu }}</td>
                                                    <td>{{ $menu->quantity }}</td>
                                                    <td>@rp($menu->jumlah)</td>
                                                  </tr>
                                                  @php
                                                      $total += $menu->jumlah;
                                                  @endphp
                                                @endif
                                                @endforeach
                                            </tbody>
                                            <tfoot>
                                                <tr>
                                                    <td colspan="2"><strong>Total</strong></td>
                                                    <td><strong>@rp($total)</strong></td>
                                                </tr>
                                            </tfoot>
                                          </table>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-light"
                                            data-bs-dismiss="modal">Close</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </td>

                </tr>
                @endforeach
                @else
                <div class="alert alert-warning alert-dismissible fade show" role="alert">
                    <strong>History kosong.</strong>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                @endif
            </tbody>
        </table>
    </div>
</div>
@endsection
