@extends('layouts.base')

@include('partials.navadmin')

@section('container')

<div class="container">
    <div class="d-flex flex-column align-items-stretch flex-shrink-0 bg-white mt-4">
        <a href="/" class="d-flex align-items-center flex-shrink-0 p-3 link-dark text-decoration-none">
            <span class="fs-5 fw-semibold"><i class="bi bi-person-workspace fs-3"></i> Admin</span>
        </a>
        <nav class="border-bottom" style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">Admin</li>
                <li class="breadcrumb-item" aria-current="page">Data admin</li>
                <li class="breadcrumb-item active" aria-current="page">Edit admin</li>
            </ol>
        </nav>
    </div>

    @if (session()->has('failed'))
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Berhasil!</strong> {{ session('failed') }}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    @endif


    {{-- profile --}}
    <form action="{{ route('admin.update',$admin->id) }}" method="post" enctype="multipart/form-data">
        @csrf
        @method('put')
        {{-- oldimage --}}
        <input type="hidden" value="{{ $admin->gambar }}" name="oldImage">
        {{-- oldNumber --}}
        <input type="hidden" value="{{ $admin->no_tlp }}" name="oldNumber">
        {{-- oldUsername --}}
        <input type="hidden" value="{{ $admin->user->username }}" name="oldUsername">
        <div class="container rounded bg-white mb-5">
            <div class="row">
                {{-- picture --}}
                <div class="col-md-3 border-right">
                    <div class="d-flex flex-column align-items-center text-center">
                        @if ($admin->gambar)
                        <img class="img-fluid img-preview mt-5 rounded-circle" style="width:150px; height:150px"
                            src="/upload/{{ $admin->gambar }}"> <br>
                        @else
                        <img class="img-fluid img-preview mt-5 rounded-circle" style="width:150px; height:150px"> <br>
                        @endif
                        <p class="font-weight-bold lh-1">Upload Foto Baru</p>
                        <span class="text-black-50">
                            <input class="form-control form-control-sm @error('gambar') is-invalid @enderror"
                                id="gambar" onchange="previewImage()" type="file" name="gambar">
                            @error('gambar')
                            <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </span>
                    </div>
                </div>


                <div class="col-md-5 border-right">
                    <div class="p-3 pt-5">
                        <div class="d-flex justify-content-between align-items-center mb-4">
                            <h4 class="text-right">Edit Admin</h4>
                        </div>
                        {{-- nama --}}
                        <div class="row mb-3">
                            <div class="col-md-12"><label class="labels">Nama</label><input type="text"
                                    class="form-control @error('nama') is-invalid @enderror" value="{{ old('nama', $admin->nama) }}"
                                    name="nama" autocomplete="off" >
                                @error('nama')
                                <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>
                        {{-- tempat lahir --}}
                        <div class="row mb-3">
                            <div class="col-md-12"><label class="labels">Tempat Lahir</label><input type="text"
                                    class="form-control @error('tempat_lahir') is-invalid @enderror"
                                    value="{{ old('tempat_lahir', $admin->tempat_lahir) }}" name="tempat_lahir" autocomplete="off" >
                                @error('tempat_lahir')
                                <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>
                        {{-- tgl lahir --}}
                        <div class="row mb-3">
                            <div class="col-md-12"><label class="labels">Tanggal Lahir</label><input type="date"
                                    class="form-control @error('tgl_lahir') is-invalid @enderror"
                                    value="{{ old('tgl_lahir', $admin->tgl_lahir) }}" name="tgl_lahir" autocomplete="off" >
                                @error('tgl_lahir')
                                <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>
                        {{-- gender --}}
                        <div class="row mb-3">
                            <div class="col-md-12"><label class="labels">Gender</label>
                                <select class="form-select @error('gender') is-invalid @enderror"
                                    aria-label="Default select example" name="gender">
                                    @if (old('gender', $admin->gender))
                                    <option value="{{ old('gender', $admin->gender) }}" selected>{{ old('gender', $admin->gender) }}</option>
                                    @else
                                    <option value="Laki-Laki" selected>Laki-Laki</option>
                                    @endif
                                    <option value="Perempuan">Perempuan</option>
                                    <option value="Laki-laki">Laki-laki</option>
                                </select>
                                @error('gender')
                                <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>
                        {{-- alamat --}}
                        <div class="row mb-3">
                            <div class="col-md-12"><label class="labels">Alamat</label><textarea
                                    class="form-control @error('alamat') is-invalid @enderror"
                                    id="exampleFormControlTextarea1" rows="3" name="alamat"
                                    >{{ old('alamat', $admin->alamat) }}</textarea>
                                @error('alamat')
                                <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>
                        {{-- no.tlp --}}
                        <div class="row mb-3">
                            <div class="col-md-12"><label class="labels">No. Tlp</label><input type="text"
                                    class="form-control @error('no_tlp') is-invalid @enderror"
                                    value="{{ old('no_tlp', $admin->no_tlp)}}" name="no_tlp" autocomplete="off" >
                                @error('no_tlp')
                                <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>
                    </div>
                </div>


                {{-- Side --}}
                <div class="col-md-4">
                    <div class="p-3 pt-5">
                        <div class="d-flex justify-content-between align-items-center mb-4">
                            <h4>Akses login</h4>
                        </div>
                        {{-- username --}}
                        <div class="row mb-3">
                            <div class="col-md-12"><label class="labels">Username</label><input type="text"
                                    class="form-control @error('username') is-invalid @enderror"
                                    value="{{ $admin->user->username }}" name="username" autocomplete="off" >
                                @error('username')
                                <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>
                        {{-- password --}}
                        <div class="row mb-3">
                            <div class="col-md-12"><label class="labels">Password Baru</label><input type="text"
                                    class="form-control @error('password') is-invalid @enderror" name="password"
                                    id="pass-able" autocomplete="off">
                                @error('password')
                                <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                            <small>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="" id="flexCheckChecked"
                                        onclick="myFunction()" checked>
                                    <label class="form-check-label" for="flexCheckChecked">
                                        Tampilkan password
                                    </label>
                                </div>
                            </small>
                        </div>
                    </div>
                </div>
            </div>
            {{-- button --}}
            <div class="mt-5 text-center">
                <button class="btn btn-success profile-button" type="button" data-bs-toggle="modal"
                    data-bs-target="#exampleModal"> <i class="bi bi-pencil"></i> Edit Data</button>
            </div>
            {{-- Modal --}}
            <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel"
                aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Simpan perubahan?</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            Apakah Anda ingin mengubah profile dengan data yang baru?
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-success">Simpan</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>

<script>
    function myFunction() {
        var x = document.getElementById("pass-able");
        if (x.type === "password") {
            x.type = "text";
        } else {
            x.type = "password";
        }
    }
</script>

@endsection
