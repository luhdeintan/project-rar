@extends('layouts.base')

@include('partials.navadmin')

@section('container')
<div class="container">
    <div class="d-flex flex-column align-items-stretch flex-shrink-0 bg-white mt-4">
        <a href="/admin" class="d-flex align-items-center flex-shrink-0 p-3 link-dark text-decoration-none">
            <span class="fs-5 fw-semibold"><i class="bi bi-person-workspace fs-3"></i> Admin</span>
        </a>
        <nav class="border-bottom" style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">Admin</li>
                <li class="breadcrumb-item active" aria-current="page">Data Admin</li>
            </ol>
        </nav>
    </div>

    @if (session()->has('success'))
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Berhasil!</strong> {{ session('success') }}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    @endif

    <a href="/admin/create" class="text-end d-flex mb-2 text-decoration-none mt-5">
        <button class="btn btn-success"><i class="bi bi-person-workspace"></i> New Admin</button>
    </a>

    <table id="datatable" class="table table-striped table-hover cell-border table-borderless">
        <thead class="table-dark">
            <tr>
                <th>#</th>
                <th>Nama</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            @if ($admin->count())
            @foreach ($admin as $admin)
            <tr>
                <td>{{ $loop->iteration }}</td>
                <td>{{ $admin->nama }}</td>
                <td>
                    <a href="/admin/{{ $admin->id }}" class="text-decoration-none"><button type="button"
                            class="btn btn-primary" data-bs-toggle="tooltip" data-bs-placement="top" title="see"><i
                                class="bi bi-eye"></i></button></a>
                    <a href="/admin/{{ $admin->id }}/edit" class="text-decoration-none"><button type="button"
                            class="btn btn-warning" data-bs-toggle="tooltip" data-bs-placement="top" title="edit"><i
                                class="bi bi-pencil"></i></button></a>
                    {{-- delete --}}
                    <a href="#" class="text-decoration-none" data-bs-toggle="modal"
                            data-bs-target="#exampleModal{{ $admin->id }}"><button type="button"
                                class="btn btn-danger" data-bs-toggle="tooltip"
                                title="delete"><i class="bi bi-trash"></i></button></a>
                    <!-- Modal Delete -->
                    <div class="modal fade" id="exampleModal{{ $admin->id }}" tabindex="-1"
                        aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Hapus</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                        aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    Data yang dihapus tidak dapat diakses kembali. <br> Yakin akan menghapus?
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-light"
                                        data-bs-dismiss="modal">Close</button>
                                    <form action="/admin/{{ $admin->id }}" method="post">
                                        @method('delete')
                                        @csrf
                                        <button type="submit" class="btn btn-danger">Hapus</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </td>
            </tr>
            @endforeach
            @else
            <div class="alert alert-warning alert-dismissible fade show" role="alert">
                <strong>Data kosong!</strong> Tambahkan data untuk mengisi tabel.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            @endif
        </tbody>
    </table>
</div>

<script>
    var myModal = document.getElementById('myModal')
    var myInput = document.getElementById('myInput')

    myModal.addEventListener('shown.bs.modal', function () {
        myInput.focus()
    })
</script>
@endsection
