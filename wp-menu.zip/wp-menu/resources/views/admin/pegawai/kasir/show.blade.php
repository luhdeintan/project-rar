@extends('layouts.base')

@include('partials.navadmin')

@section('container')

<div class="container">
    <div class="d-flex flex-column align-items-stretch flex-shrink-0 bg-white mt-4">
        <a href="/" class="d-flex align-items-center flex-shrink-0 p-3 link-dark text-decoration-none">
            <span class="fs-5 fw-semibold"><i class="bi bi-people-fill fs-3"></i> Kasir</span>
        </a>
        <nav class="border-bottom" style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">Kasir</li>
                <li class="breadcrumb-item" aria-current="page">Data kasir</li>
                <li class="breadcrumb-item active" aria-current="page">Detail kasir</li>
            </ol>
        </nav>
    </div>


    {{-- profile --}}
    <form action="" method="post">
        @csrf
        <div class="container rounded bg-white mb-5">
            <div class="row">
                {{-- picture --}}
                <div class="col-md-3 border-right">
                    <div class="d-flex flex-column align-items-center text-center">
                        <img class="rounded-circle mt-5" style="height:150px; width:150px;"
                            src="{{ asset('upload/'. $kasir->gambar) }}"> <br>
                    </div>
                </div>


                <div class="col-md-5 border-right">
                    <div class="p-3 pt-5">
                        <div class="d-flex justify-content-between align-items-center mb-4">
                            <h4 class="text-right">Profile Kasir</h4>
                        </div>
                        {{-- nama --}}
                        <div class="row mb-3">
                            <div class="col-md-12"><label class="labels">Nama</label><input type="text"
                                    class="form-control"  value="{{ $kasir->nama }}" disabled>
                            </div>
                        </div>
                        {{-- tempat lahir --}}
                        <div class="row mb-3">
                            <div class="col-md-12"><label class="labels">Tempat Lahir</label><input type="text"
                                    class="form-control"  value="{{ $kasir->tempat_lahir }}" disabled>
                            </div>
                        </div>
                        {{-- tgl_lahir --}}
                        <div class="row mb-3">
                            <div class="col-md-12"><label class="labels">Tgl. Lahir</label><input type="text"
                                    class="form-control"  value="{{ $kasir->tgl_lahir }}" disabled>
                            </div>
                        </div>
                        {{-- gender --}}
                        <div class="row mb-3">
                            <div class="col-md-12"><label class="labels">Gender</label><input type="text"
                                    class="form-control"  value="{{ $kasir->gender }}" disabled>
                            </div>
                        </div>
                        {{-- alamalt --}}
                        <div class="row mb-3">
                            <div class="col-md-12"><label class="labels">Alamat</label><input type="text"
                                    class="form-control"  value="{{ $kasir->alamat }}"
                                    disabled></div>
                        </div>
                        {{-- no.tlp --}}
                        <div class="row mb-3">
                            <div class="col-md-12"><label class="labels">No. Tlp</label><input type="text"
                                    class="form-control"  value="{{ $kasir->no_tlp }}"
                                    disabled></div>
                        </div>
                    </div>
                </div>


                {{-- Side --}}
                <div class="col-md-4">
                    <div class="p-3 pt-5">
                        <div class="d-flex justify-content-between align-items-center mb-4">
                            <h4>Akses login</h4>
                        </div>
                        {{-- username --}}
                        <div class="row mb-3">
                            <div class="col-md-12"><label class="labels">Username</label><input type="text"
                                    class="form-control"  value="{{ $kasir->user->username }}"  disabled>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            {{-- button --}}
            <div class="mt-5 text-center">
                <a href="/kasir/{{ $kasir->id }}/edit" class="text-decoration-none">
                    <button class="btn btn-success profile-button" type="button" data-bs-toggle="modal"
                        data-bs-target="#exampleModal"><i class="bi bi-pencil"></i> Edit Data</button>
                </a>
            </div>
        </div>
    </form>
</div>

<script>
    function myFunction() {
        var x = document.getElementById("pass-able");
        if (x.type === "password") {
            x.type = "text";
        } else {
            x.type = "password";
        }
    }
</script>
@endsection
