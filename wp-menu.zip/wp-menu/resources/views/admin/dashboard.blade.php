@extends('layouts.base')

@include('partials.navadmin')

@section('container')
<main class="container">
    <div class="d-flex flex-column align-items-stretch flex-shrink-0 bg-white mt-4">
        <a href="/dashboard-admin" class="d-flex align-items-center flex-shrink-0 p-3 link-dark text-decoration-none">
            <span class="fs-5 fw-semibold"><i class="bi bi-speedometer2 fs-3"></i> Dashboard</span>
        </a>
        <nav class="border-bottom" style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">Dashboard</li>
                <li class="breadcrumb-item active" aria-current="page">info</li>
            </ol>
        </nav>
    </div>

    <div class="container">
        <div class="row my-5">
            <div class="col-sm-6">
                <a href="/history-penjualan" class="text-white" style="text-decoration: none">
                    <div class="card text-white bg-success">
                        <div class="card-body">
                            <h5 class="card-title"><i class="bi bi-cash-coin"></i> Penjualan hari ini</h5>
                            <h1 class="card-text">@rupiahnya($order)</h1>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-sm-6">
                <a href="/history-penjualan" class="text-white"  style="text-decoration: none;">
                    <div class="card text-white bg-primary" >
                        <div class="card-body">
                            <h5 class="card-title"><i class="bi bi-people-fill"></i> Pengunjung hari ini</h5>
                            <h1 class="card-text">{{ $user }}</h1>
                        </div>
                    </div>
                </a>
            </div>
        </div>



        {{-- <div class="d-flex align-items-center p-3 mt-5 mb-3 text-white bg-purple rounded shadow-sm">
            <img class="me-3" src="../assets/brand/bootstrap-logo-white.svg" alt="" width="48" height="38">
            <div class="lh-1">
                <h1 class="h6 mb-0 text-white lh-1">Bootstrap</h1>
                <small>Since 2011</small>
            </div>
        </div>

        <div class="my-3 p-3 bg-body rounded shadow-sm">
            <h6 class="border-bottom pb-2 mb-0">Recent updates</h6>
            <div class="d-flex text-muted pt-3">
                <svg class="bd-placeholder-img flex-shrink-0 me-2 rounded" width="32" height="32"
                    xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: 32x32"
                    preserveAspectRatio="xMidYMid slice" focusable="false">
                    <title>Placeholder</title>
                    <rect width="100%" height="100%" fill="#007bff" /><text x="50%" y="50%" fill="#007bff"
                        dy=".3em">32x32</text>
                </svg>

                <p class="pb-3 mb-0 small lh-sm border-bottom">
                    <strong class="d-block text-gray-dark">@username</strong>
                    Some representative placeholder content, with some information about this user. Imagine this being some
                    sort of status update, perhaps?
                </p>
            </div>
            <div class="d-flex text-muted pt-3">
                <svg class="bd-placeholder-img flex-shrink-0 me-2 rounded" width="32" height="32"
                    xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: 32x32"
                    preserveAspectRatio="xMidYMid slice" focusable="false">
                    <title>Placeholder</title>
                    <rect width="100%" height="100%" fill="#e83e8c" /><text x="50%" y="50%" fill="#e83e8c"
                        dy=".3em">32x32</text>
                </svg>

                <p class="pb-3 mb-0 small lh-sm border-bottom">
                    <strong class="d-block text-gray-dark">@username</strong>
                    Some more representative placeholder content, related to this other user. Another status update,
                    perhaps.
                </p>
            </div>
            <div class="d-flex text-muted pt-3">
                <svg class="bd-placeholder-img flex-shrink-0 me-2 rounded" width="32" height="32"
                    xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: 32x32"
                    preserveAspectRatio="xMidYMid slice" focusable="false">
                    <title>Placeholder</title>
                    <rect width="100%" height="100%" fill="#6f42c1" /><text x="50%" y="50%" fill="#6f42c1"
                        dy=".3em">32x32</text>
                </svg>

                <p class="pb-3 mb-0 small lh-sm border-bottom">
                    <strong class="d-block text-gray-dark">@username</strong>
                    This user also gets some representative placeholder content. Maybe they did something interesting, and
                    you really want to highlight this in the recent updates.
                </p>
            </div>
            <small class="d-block text-end mt-3">
                <a href="#">All updates</a>
            </small>
        </div>

        <div class="my-3 p-3 bg-body rounded shadow-sm">
            <h6 class="border-bottom pb-2 mb-0">Suggestions</h6>
            <div class="d-flex text-muted pt-3">
                <svg class="bd-placeholder-img flex-shrink-0 me-2 rounded" width="32" height="32"
                    xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: 32x32"
                    preserveAspectRatio="xMidYMid slice" focusable="false">
                    <title>Placeholder</title>
                    <rect width="100%" height="100%" fill="#007bff" /><text x="50%" y="50%" fill="#007bff"
                        dy=".3em">32x32</text>
                </svg>

                <div class="pb-3 mb-0 small lh-sm border-bottom w-100">
                    <div class="d-flex justify-content-between">
                        <strong class="text-gray-dark">Full Name</strong>
                        <a href="#">Follow</a>
                    </div>
                    <span class="d-block">@username</span>
                </div>
            </div>
            <div class="d-flex text-muted pt-3">
                <svg class="bd-placeholder-img flex-shrink-0 me-2 rounded" width="32" height="32"
                    xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: 32x32"
                    preserveAspectRatio="xMidYMid slice" focusable="false">
                    <title>Placeholder</title>
                    <rect width="100%" height="100%" fill="#007bff" /><text x="50%" y="50%" fill="#007bff"
                        dy=".3em">32x32</text>
                </svg>

                <div class="pb-3 mb-0 small lh-sm border-bottom w-100">
                    <div class="d-flex justify-content-between">
                        <strong class="text-gray-dark">Full Name</strong>
                        <a href="#">Follow</a>
                    </div>
                    <span class="d-block">@username</span>
                </div>
            </div>
            <div class="d-flex text-muted pt-3">
                <svg class="bd-placeholder-img flex-shrink-0 me-2 rounded" width="32" height="32"
                    xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: 32x32"
                    preserveAspectRatio="xMidYMid slice" focusable="false">
                    <title>Placeholder</title>
                    <rect width="100%" height="100%" fill="#007bff" /><text x="50%" y="50%" fill="#007bff"
                        dy=".3em">32x32</text>
                </svg>

                <div class="pb-3 mb-0 small lh-sm border-bottom w-100">
                    <div class="d-flex justify-content-between">
                        <strong class="text-gray-dark">Full Name</strong>
                        <a href="#">Follow</a>
                    </div>
                    <span class="d-block">@username</span>
                </div>
            </div>
            <small class="d-block text-end mt-3">
                <a href="#">All suggestions</a>
            </small>
        </div> --}}
    </div>


</main>
{{-- <div class="container"> --}}

{{-- <div class="container">
        <div class="d-flex flex-column align-items-stretch flex-shrink-0 bg-white mt-4">
            <a href="/dashboard-admin"
                class="d-flex align-items-center flex-shrink-0 p-3 link-dark text-decoration-none">
                <span class="fs-5 fw-semibold"><i class="bi bi-speedometer2 fs-3"></i> Dashboard</span>
            </a>
            <nav class="border-bottom" style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">Dashboard</li>
                    <li class="breadcrumb-item active" aria-current="page">info</li>
                </ol>
            </nav>
        </div>

        <div class="container mt-5 mb-2">
            <div class="row justify-content-start">
                <p class="h3 fw-bold">Selamat Datang <span>{{ $admin->nama }}</span></p>

<div class="containern-fluid">
    <div class="row justify-content-evenly">
        <div class="col-6 col-sm-4">
            <div class="card" style="width: 18rem;">
                <div class="card-body">
                    <h5 class="card-title">Menu</h5>
                    <h6 class="card-subtitle mb-2 text-muted">jumlah menu</h6>
                    <h1 class="display-6 text-center fw-bold">36 Menus</h1>
                    <a href="#" class="card-link">Card link</a>
                    <a href="#" class="card-link">Another link</a>
                </div>
            </div>
        </div>
        <div class="col-6 col-sm-4">
            <div class="card" style="width: 18rem;">
                <div class="card-body">
                    <h5 class="card-title">Menu</h5>
                    <h6 class="card-subtitle mb-2 text-muted">jumlah menu</h6>
                    <h1 class="display-6 text-center fw-bold">36 Menus</h1>
                    <a href="#" class="card-link">Card link</a>
                    <a href="#" class="card-link">Another link</a>
                </div>
            </div>
        </div>
        <div class="col-6 col-sm-4">
            <div class="card" style="width: 18rem;">
                <div class="card-body">
                    <h5 class="card-title">Menu</h5>
                    <h6 class="card-subtitle mb-2 text-muted">jumlah menu</h6>
                    <h1 class="display-6 text-center fw-bold">36 Menus</h1>
                    <a href="#" class="card-link">Card link</a>
                    <a href="#" class="card-link">Another link</a>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
</div>

<div class="row row-cols-1 row-cols-md-2 g-2 mb-5">
    <div class="col">
        <div class="card text-light bg-dark">
            <div class="card-body">
                <h5 class="card-title">Pengunjung</h5>
                <small><i class="bi bi-arrow-up"></i></small>
                <h3 class="card-text">{{ $user }}</h3>
            </div>
        </div>
    </div>
    <div class="col">
        <div class="card text-light bg-dark">
            <div class="card-body">
                <h5 class="card-title">Penjualan</h5>
                <small class="fw-bold text-danger"><i class="bi bi-arrow-down"></i></small>
                <h3 class="card-text">{{ $order }}</h3>
            </div>
        </div>
    </div>
</div>
</div> --}}

{{-- </div> --}}

@endsection
