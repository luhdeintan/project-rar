@extends('layouts.base')

@include('partials.navadmin')

@section('container')
<div class="container">
    <div class="d-flex flex-column align-items-stretch flex-shrink-0 bg-white mt-4">
        <a href="/dashboard-admin" class="d-flex align-items-center flex-shrink-0 p-3 link-dark text-decoration-none">
            <span class="fs-5 fw-semibold"><i class="bi bi-file-earmark-binary fs-3"></i> Meja</span>
        </a>
        <nav class="border-bottom mb-5" style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">Meja</li>
                <li class="breadcrumb-item active" aria-current="page">Tabel data</li>
            </ol>
        </nav>
    </div>

    @if (session()->has('success'))
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Berhasil!</strong> {{ session('success') }}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    @endif

    @if (session()->has('failed'))
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <strong>Gagal!</strong> {{ session('failed') }}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    @endif

    {{-- tambah data --}}
    <button class="btn btn-success mb-2" data-bs-toggle="modal" data-bs-target="#add"><i
            class="bi bi-file-earmark-binary"></i> New Meja</button>
    {{-- modal tambah--}}
    <form action="/meja" method="POST">
        @csrf
        <div class="modal fade" id="add" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header bg-success text-light">
                        <h5 class="modal-title" id="exampleModalLabel"><i class="bi bi-file-earmark-binary"></i> Tambah
                            Meja</h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"
                            aria-label="Close"></button>
                    </div>
                    <div class="modal-body mx-3 mb-3">
                        <label class="labels">No. Meja</label><input type="text" class="form-control mb-2"
                            placeholder="ex: DE01" value="" name="no_meja" required autocomplete="off">
                            @error('no_meja')
                            <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        <label class="labels">Lokasi</label><input type="text" class="form-control"
                            placeholder="ex: depan" value="" name="lokasi" required autocomplete="off">
                            @error('lokasi')
                            <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-success">Tambah</button>
                    </div>
                </div>
            </div>
        </div>
    </form>


    {{-- table --}}
    <div class="table-responsive-xl">
        <table id="datatable" class="table table-striped table-hover cell-border table-borderless">
            <thead class="table-dark">
                <tr>
                    <td>#</td>
                    <td>No. Meja</td>
                    <td>Lokasi</td>
                    <td>Aksi</td>
                </tr>
            </thead>
            <tbody>
                @if ($meja->count())
                @foreach ($meja as $meja)
                <tr>
                    <td>{{ $loop->iteration }}</td>
                    <td>{{ $meja->no_meja }}</td>
                    <td>{{ $meja->lokasi }}</td>
                    <td>
                        <a href="#" class="text-decoration-none" data-bs-toggle="modal"
                            data-bs-target="#edit{{ $meja->id }}"><button type="button" class="btn btn-warning"
                                data-bs-toggle="tooltip" data-bs-placement="top" title="edit"><i
                                    class="bi bi-pencil"></i></button></a>
                        <a href="#" class="text-decoration-none" data-bs-toggle="modal"
                            data-bs-target="#exampleModal{{ $meja->id }}"><button type="button" class="btn btn-danger"
                                data-bs-toggle="tooltip" data-bs-placement="top" title="delete"><i
                                    class="bi bi-trash"></i></button></a>
                        {{-- modal delete--}}
                        <div class="modal fade" id="exampleModal{{ $meja->id }}" tabindex="-1"
                            aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Hapus</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                            aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        Data yang dihapus tidak dapat diakses kembali. <br> Yakin akan menghapus?
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-light"
                                            data-bs-dismiss="modal">Close</button>
                                        <form action="/meja/{{ $meja->id }}" method="post">
                                            @method('delete')
                                            @csrf
                                            <button type="submit" class="btn btn-danger">Hapus</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        {{-- modal edit --}}
                        <form action="/meja/{{ $meja->id }}" method="post">
                            @csrf
                            @method('put')
                            <input type="hidden" name="oldMeja" value="{{ $meja->no_meja }}">
                            <div class="modal fade" id="edit{{ $meja->id }}" tabindex="-1"
                                aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog modal-dialog-centered">
                                    <div class="modal-content">
                                        <div class="modal-header bg-primary text-light">
                                            <h5 class="modal-title" id="exampleModalLabel"><i class="bi bi-pencil"></i>
                                                Edit Meja</h5>
                                            <button type="button" class="btn-close btn-close-white"
                                                data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body mx-3 mb-3">
                                            <label class="labels">No. Meja</label>
                                            <input type="text" class="form-control mb-2"
                                                value="{{ old('no_meja', $meja->no_meja) }}" name="no_meja" required autocomplete="off">
                                            <label class="labels">Lokasi</label>
                                            <input type="text" class="form-control"
                                                value="{{ old('lokasi', $meja->lokasi) }}" name="lokasi" required autocomplete="off">
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-light"
                                                data-bs-dismiss="modal">Close</button>
                                            <button type="submit" class="btn btn-primary">Edit</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </td>
                </tr>
                @endforeach
                @else
                <div class="alert alert-warning alert-dismissible fade show" role="alert">
                    <strong>Data kosong!</strong> Tambahkan data untuk mengisi tabel.
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                @endif

            </tbody>
        </table>
    </div>
</div>
@endsection
