@extends('layouts.base')

@include('partials.navadmin')

@section('container')
<div class="container">
    <div class="d-flex flex-column align-items-stretch flex-shrink-0 bg-white mt-4">
        <a href="/dashboard-admin" class="d-flex align-items-center flex-shrink-0 p-3 link-dark text-decoration-none">
            <span class="fs-5 fw-semibold"><i class="bi bi-tag fs-3"></i> Kategori</span>
        </a>
        <nav class="border-bottom mb-5" style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">Kategori</li>
                <li class="breadcrumb-item active" aria-current="page">Tabel data</li>
            </ol>
        </nav>
    </div>

    @if (session()->has('success'))
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Berhasil!</strong> {{ session('success') }}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    @endif

    @if (session()->has('failed'))
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <strong>Gagal!</strong> {{ session('failed') }}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    @endif

    @if ($errors->has('nama'))
    <div class="alert alert-success alert-dismissible fade show invalid-feedback" role="alert">
        <strong>Failed!</strong> {{ $errors->first('nama') }}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    @endif

    <button class="btn btn-success mb-2" data-bs-toggle="modal" data-bs-target="#add"><i class="bi bi-tag"></i> New
        Kategori</button>
    {{-- modal tambah--}}
    <form action="/kategori" method="POST">
        @csrf
        <div class="modal fade" id="add" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header bg-success text-light">
                        <h5 class="modal-title" id="exampleModalLabel"><i class="bi bi-tag"></i> Tambah
                            Kategori</h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"
                            aria-label="Close"></button>
                    </div>
                    <div class="modal-body mx-3 mb-4">
                        <label class="labels mb-1">Kategori</label>
                        <input type="text" class="form-control mb-2" placeholder="ex: Snack" value="" name="nama"
                            required autocomplete="off">
                        <label class="labels mb-1">Type</label>
                        <select class="form-select @error('type') is-invalid @enderror"
                            aria-label="Default select example" name="type">
                            <option value="Makanan" selected>Makanan</option>
                            <option value="Minuman">Minuman</option>
                        </select>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-success">Tambah</button>
                    </div>
                </div>
            </div>
        </div>
    </form>


    {{-- table --}}
    <div class="table-responsive-xl">
        <table id="datatable" class="table table-striped table-hover cell-border table-borderless">
            <thead class="table-dark">
                <tr>
                    <td>#</td>
                    <td>Kategori</td>
                    <td>Type</td>
                    <td>Aksi</td>
                </tr>
            </thead>
            <tbody>
                @if ($kategori->count())
                @foreach ($kategori as $kategori)
                <tr>
                    <td>{{ $loop->iteration }}</td>
                    <td>{{ $kategori->nama }}</td>
                    <td>{{ $kategori->type }}</td>
                    <td>
                        <a href="#" class="text-decoration-none" data-bs-toggle="modal"
                            data-bs-target="#edit{{ $kategori->id }}"><button type="button" class="btn btn-warning"
                                data-bs-toggle="tooltip" data-bs-placement="top" title="edit"><i
                                    class="bi bi-pencil"></i></button></a>
                        <a href="#" class="text-decoration-none" data-bs-toggle="modal"
                            data-bs-target="#exampleModal{{ $kategori->id }}"><button type="button"
                                class="btn btn-danger" data-bs-toggle="tooltip" data-bs-placement="top"
                                title="delete"><i class="bi bi-trash"></i></button></a>
                        {{-- modal delete--}}
                        <div class="modal fade" id="exampleModal{{ $kategori->id }}" tabindex="-1"
                            aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Hapus</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                            aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        Data yang dihapus tidak dapat diakses kembali. <br> Yakin akan menghapus?
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-light"
                                            data-bs-dismiss="modal">Close</button>
                                        <form action="/kategori/{{ $kategori->id }}" method="post">
                                            @method('delete')
                                            @csrf
                                            <button type="submit" class="btn btn-danger">Hapus</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        {{-- modal edit --}}
                        <form action="/kategori/{{ $kategori->id }}" method="post">
                            @csrf
                            @method('put')
                            <input type="hidden" value="{{ $kategori->nama }}" name="oldKategori">
                            <div class="modal fade" id="edit{{ $kategori->id }}" tabindex="-1"
                                aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog modal-dialog-centered">
                                    <div class="modal-content">
                                        <div class="modal-header bg-primary text-light">
                                            <h5 class="modal-title" id="exampleModalLabel"><i class="bi bi-pencil"></i>
                                                Edit Kategori</h5>
                                            <button type="button" class="btn-close btn-close-white"
                                                data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body mx-3 mb-4">
                                            {{-- kategori --}}
                                            <label class="labels mb-1">Kategori</label>
                                            <input type="text mb-2"
                                                class="form-control mb-2  @error('nama') is-invalid @enderror"
                                                value="{{ old('nama', $kategori->nama) }}" name="nama" required autocomplete="off">
                                            {{-- type --}}
                                            <label class="labels mb-1">Type</label>
                                            <select class="form-select @error('type') is-invalid @enderror"
                                                aria-label="Default select example" name="type">
                                                @if (old('type', $kategori->type))
                                                <option value="{{ old('type', $kategori->type) }}" selected>
                                                    {{ old('type', $kategori->type) }}</option>
                                                @else
                                                @endif
                                                <option value="Makanan">Makanan</option>
                                                <option value="Minuman">Minuman</option>
                                            </select>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-light"
                                                data-bs-dismiss="modal">Close</button>
                                            <button type="submit" class="btn btn-primary">Edit</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                        {{-- <form action="/kategori-menu/{{ $kategori->id }}" method="post">
                        @csrf
                        @method('put')
                        <div class="modal fade" id="edit{{ $kategori->id }}" tabindex="-1"
                            aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-centered">
                                <div class="modal-content">
                                    <div class="modal-header bg-primary text-light">
                                        <h5 class="modal-title" id="exampleModalLabel"><i class="bi bi-pencil"></i>
                                            Edit Kategori</h5>
                                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"
                                            aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body mx-3 mb-3">
                                        <label class="labels">Kategori</label>
                                        <input type="text" class="form-control"
                                            value="{{ old('nama', $kategori->nama) }}" name="nama" required>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-light"
                                            data-bs-dismiss="modal">Close</button>
                                        <button type="submit" class="btn btn-primary">Edit</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        </form> --}}
                    </td>

                </tr>
                @endforeach
                @else
                <div class="alert alert-warning alert-dismissible fade show" role="alert">
                    <strong>Data kosong!</strong> Tambahkan data untuk mengisi tabel.
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                @endif
            </tbody>
        </table>
    </div>
</div>
@endsection
