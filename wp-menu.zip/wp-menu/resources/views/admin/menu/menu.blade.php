@extends('layouts.base')

@if ($user == 1)
    @include('partials.navadmin')
@else
    @include('partials.navkasir')
@endif

{{-- @include('partials.navadmin') --}}

@section('container')
    <div class="container">
        <div class="d-flex flex-column align-items-stretch flex-shrink-0 bg-white mt-4">
            <a href="/menu" class="d-flex align-items-center flex-shrink-0 p-3 link-dark text-decoration-none">
                <span class="fs-5 fw-semibold"><i class="bi bi-journal-text fs-3"></i> Menu</span>
            </a>
            <nav class="border-bottom mb-5" style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">Menu</li>
                    <li class="breadcrumb-item active" aria-current="page">Tabel data</li>
                </ol>
            </nav>
        </div>

        @if (session()->has('success'))
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong>Berhasil!</strong> {{ session('success') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        @endif

        @if ($user == 1)
            <a href="/menu/create" class="text-end d-flex mb-2 text-decoration-none">
                <button class="btn btn-success"><i class="bi bi-journal-text"></i> New Menu</button>
            </a>
        @endif

        {{-- table --}}
        <div class="table-responsive" style="">
            <table id="datatable" class="table table-striped table-hover cell-border table-borderless" style="">
                <thead class="table-dark">
                    <tr>
                        <td>No.</td>
                        <td>Menu</td>
                        {{-- @if ($user == 1) --}}
                        <td>Kategori</td>
                        <td>Harga</td>
                        <td>Status</td>
                        {{-- @endif --}}
                        <td>Aksi</td>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($menu as $menu)
                        <tr>
                            <td>{{ $loop->iteration }}</td>
                            <td>{{ $menu->nama }}</td>
                            {{-- @if ($user == 1) --}}
                            <td>{{ $menu->kategori->active == 0 ? 'none' : $menu->kategori->nama }}</td>
                            <td>{{ $menu->harga }}</td>
                            <td><span
                                    class="{{ $menu->status == 'ready' ? 'badge bg-primary' : 'badge bg-secondary' }}">{{ $menu->status }}</span>
                            </td>
                            {{-- @endif --}}
                            <td>
                                {{-- see --}}
                                @if ($user == 1)
                                    <a href="/menu/{{ $menu->id }}" class="text-decoration-none"><button type="button"
                                            class="btn btn-primary" data-bs-toggle="tooltip" data-bs-placement="top"
                                            title="see"><i class="bi bi-eye"></i></button></a>
                                    {{-- edit --}}
                                    <a href="/menu/{{ $menu->id }}/edit" class="text-decoration-none"><button
                                            type="button" class="btn btn-warning" data-bs-toggle="tooltip"
                                            data-bs-placement="top" title="edit"><i class="bi bi-pencil"></i></button></a>
                                    {{-- delete --}}
                                    <button class="btn btn-danger" type="submit" title="delete" data-bs-toggle="modal"
                                        data-bs-target="#exampleModal{{ $menu->id }}" data-bs-toggle="tooltip"
                                        data-bs-placement="top" title="delete"><i class="bi bi-trash"></i>
                                    </button>
                                    {{-- modal delete --}}
                                    <div class="modal fade" id="exampleModal{{ $menu->id }}" tabindex="-1"
                                        aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="exampleModalLabel">Hapus</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                        aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">
                                                    Data yang dihapus tidak dapat diakses kembali. <br> Yakin akan
                                                    menghapus?
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-light"
                                                        data-bs-dismiss="modal">Close</button>
                                                    <form action="/menu/{{ $menu->id }}" method="post">
                                                        @method('delete')
                                                        @csrf
                                                        <button type="submit" class="btn btn-danger">Hapus</button>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                @else
                                    {{-- edit --}}
                                    <a href="/menu/{{ $menu->id }}/edit" class="text-decoration-none"
                                        data-bs-toggle="modal" data-bs-target="#exampleModal{{ $menu->id }}"><button
                                            type="button" class="btn btn-success" data-bs-toggle="tooltip"
                                            data-bs-placement="top" title="edit"><i class="bi bi-pencil"></i></button>
                                    </a>
                                    <form action="/statuschange/{{ $menu->id }}" method="post">
                                        @csrf
                                        <div class="modal fade" id="exampleModal{{ $menu->id }}" tabindex="-1"
                                            aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header bg-success text-white">
                                                        <h5 class="modal-title" id="exampleModalLabel">
                                                            {{ $menu->nama }}</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                            aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <label for="status">Status menu: </label>
                                                        <select id="status" name="status" class="form-select mt-2 mb-3"
                                                            aria-label="Default select example">
                                                            <option selected value="{{ $menu->status }}">
                                                                {{ Str::upper($menu->status) }}</option>
                                                            <option value="ready">READY</option>
                                                            <option value="empty">EMPTY</option>
                                                        </select>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary"
                                                            data-bs-dismiss="modal">Close</button>
                                                        <button type="submit" class="btn btn-success">Save</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                @endif
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
@endsection
