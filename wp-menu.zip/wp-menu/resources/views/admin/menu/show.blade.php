@extends('layouts.base')

@include('partials.navadmin')

@section('container')
<div class="container">
    <div class="d-flex flex-column align-items-stretch flex-shrink-0 bg-white mt-4">
        <a href="/dashboard-admin" class="d-flex align-items-center flex-shrink-0 p-3 link-dark text-decoration-none">
            <span class="fs-5 fw-semibold"><i class="bi bi-journal-text fs-3"></i> Menu</span>
        </a>
        <nav class="border-bottom mb-5" style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">Menu</li>
                <li class="breadcrumb-item " aria-current="page">Tabel data</li>
                <li class="breadcrumb-item active" aria-current="page">Detail</li>
            </ol>
        </nav>
    </div>
    <form action="" method="post">
        @csrf
        <div class="container rounded bg-white mb-5">
            <div class="row">
                {{-- picture --}}
                <div class="col-md-6 border-right">
                    <div class="d-flex flex-column align-items-center text-center">
                        <img class="fluid" width="300px"
                            src="{{ asset('menu-img/'. $menu->gambar) }}"> <br>
                    </div>
                </div>


                <div class="col-md-6 border-right">
                    <div class="px-3">
                        <div class="d-flex justify-content-between align-items-center mb-4">
                            <h4 class="text-right">Menu</h4>
                        </div>
                        {{-- gambar --}}
                        {{-- <div class="row mb-3">
                            <div class="col-md-12"><label class="labels">Gambar</label><input type="text"
                                    class="form-control" value="{{ $menu->gambar }}" readonly name="menu" >
                            </div>
                        </div> --}}
                        {{-- nama --}}
                        <div class="row mb-3">
                            <div class="col-md-12"><label class="labels">Menu</label><input type="text"
                                    class="form-control" value="{{ $menu->nama }}" readonly name="menu" >
                            </div>
                        </div>
                        {{-- kategori --}}
                        <div class="row mb-3">
                            <div class="col-md-12"><label class="labels">Kategori</label><input type="text"
                                    class="form-control" value="{{ $menu->kategori->active == 0 ? 'none' : $menu->kategori->nama }}" readonly name="menu" >
                            </div>
                        </div>
                        {{-- harga --}}
                        <div class="row mb-3">
                            <div class="col-md-12"><label class="labels">Harga</label><input type="text"
                                    class="form-control" value="{{ $menu->harga }}" readonly name="harga"
                                    ></div>
                        </div>
                        {{-- status --}}
                        <div class="row mb-3">
                            <div class="col-md-12"><label class="labels">Status</label><input type="text"
                                    class="form-control" value="{{ $menu->status }}" readonly name="harga"
                                    ></div>
                        </div>
                        {{-- bahan --}}
                        <div class="row mb-3">
                            <div class="col-md-12"><label class="labels">Bahan</label><input type="text"
                                    class="form-control" value="{{ $menu->bahan }}" readonly name="harga"
                                    ></div>
                        </div>
                        {{-- deskripsi --}}
                        <div class="row mb-3">
                            <div class="col-md-12">
                                <label class="labels">Deskripsi</label>
                                <textarea class="form-control"
                                    id="exampleFormControlTextarea1" rows="3"
                                name="deskripsi" readonly>
                                    {{ $menu->deskripsi }}
                                </textarea>
                            </div>
                        </div>
                    </div>
                    {{-- button --}}
                    <div class="mt-5 text-center">
                        <button class="btn btn-warning profile-button" type="button"><a href="/menu/{{ $menu->id }}/edit" class="text-decoration-none text-dark"><i class="bi bi-pencil"></i> Edit</a></button>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>

</div>
@endsection
