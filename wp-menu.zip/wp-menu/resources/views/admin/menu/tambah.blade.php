@extends('layouts.base')

@include('partials.navadmin')

@section('container')
<div class="container">
    <div class="d-flex flex-column align-items-stretch flex-shrink-0 bg-white mt-4">
        <a href="/dashboard-admin" class="d-flex align-items-center flex-shrink-0 p-3 link-dark text-decoration-none">
            <span class="fs-5 fw-semibold"><i class="bi bi-journal-text fs-3"></i> Menu</span>
        </a>
        <nav class="border-bottom mb-5" style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">Menu</li>
                <li class="breadcrumb-item " aria-current="page">Tabel data</li>
                <li class="breadcrumb-item active" aria-current="page">Tambah</li>
            </ol>
        </nav>
    </div>

    @if (session()->has('failed'))
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <strong>Gagal!</strong> {{ session('failed') }}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    @endif

    <form action="/menu" method="post" enctype="multipart/form-data" autocomplete="off">
        @csrf
        <div class="container rounded bg-white mb-5">
            <div class="row">
                {{-- picture --}}
                <div class="col-md-6 border-right">
                    <div class="d-flex flex-column align-items-center text-center">
                        <img class="img-preview" width="300px" id="view">
                        <br>
                    </div>
                </div>


                <div class="col-md-6 border-right">
                    <div class="px-3">
                        <div class="d-flex justify-content-between align-items-center mb-4">
                            <h4 class="text-right">Tambah Menu</h4>
                        </div>
                        {{-- gambar --}}
                        <div class="row mb-3">
                            <div class="col-md-12"><label class="labels">Gambar</label>
                                <input type="file" class="form-control @error('gambar') is-invalid @enderror"
                                    name="gambar" id="gambar" onchange="previewImage()" required autocomplete="off">
                                @error('gambar')
                                <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>
                        {{-- kategori --}}
                        <div class="row mb-3">
                            <div class="col-md-12"><label class="labels">Kategori</label>
                                <select class="form-select @error('kategori_id') is-invalid @enderror"
                                    aria-label="Default select example" name="kategori_id">
                                    @foreach ($kategori as $k)
                                    @if (old('kategori_id') == $k->id)
                                    <option value="{{ $k->id }}" selected>{{ $k->nama }}</option>
                                    @else
                                    <option value="{{ $k->id }}">{{ $k->nama }}</option>
                                    @endif
                                    @endforeach
                                </select>
                                @error('kategori_id')
                                <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>
                        {{-- nama --}}
                        <div class="row mb-3">
                            <div class="col-md-12">
                                <label class="labels">Nama Menu</label>
                                <input type="text" class="form-control @error('nama') is-invalid @enderror"
                                    placeholder="nama menu" value="{{ old('nama') }}" name="nama" required
                                    autocomplete="off">
                                @error('nama')
                                <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>
                        {{-- harga --}}
                        <div class="row mb-3">
                            <div class="col-md-12">
                                <label class="labels">Harga</label>
                                <input type="text" class="form-control @error('harga') is-invalid @enderror"
                                    placeholder="ex: 12000" value="{{ old('harga') }}" name="harga" required
                                    autocomplete="off">
                                @error('harga')
                                <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>
                        {{-- bahan --}}
                        <div class="row mb-3">
                            <div class="col-md-12">
                                <label class="labels">Bahan</label>
                                <input type="text" class="form-control @error('bahan') is-invalid @enderror"
                                    placeholder="ex: kopi, susu" value="{{ old('bahan') }}" name="bahan" required
                                    autocomplete="off">
                                @error('bahan')
                                <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>
                        {{-- status --}}
                        <input type="hidden" value="ready" name="status">
                        <div class="row mb-3">
                            <div class="col-md-12"><label class="labels">Status</label>
                                <select class="form-select @error('status') is-invalid @enderror"
                                    aria-label="Default select example" name="status">
                                    @if (old('status'))
                                    <option value="{{ old('status') }}" selected>{{ ucfirst(trans(old('status')))}}
                                    </option>
                                    @endif
                                    <option value="ready">Ready</option>
                                    <option value="empty">Empty</option>
                                </select>
                                @error('status')
                                <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>
                        {{-- deskripsi --}}
                        <div class="row mb-3">
                            <div class="col-md-12">
                                <label class="labels">Deskripsi</label>
                                <textarea class="form-control @error('deskripsi') is-invalid @enderror"
                                    id="exampleFormControlTextarea1" rows="3" name="deskripsi"
                                    required>{{ old('deskripsi') }}</textarea>
                                @error('deskripsi')
                                <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>
                        {{-- button --}}
                        <div class="mt-5 text-center">
                            <button class="btn btn-success profile-button" type="submit">Simpan</button>
                        </div>
                    </div>
                </div>
            </div>
    </form>
</div>
@endsection
