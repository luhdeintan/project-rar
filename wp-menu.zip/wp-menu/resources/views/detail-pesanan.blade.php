@extends('layouts.base')

@include('partials.navuser')

@section('container')
<div class="container ">
    <div class="p-4 p-md-5 mb-4 text-white rounded bg-dark">
        <div class="col-md-10 px-0">
            <h3 class="display-6 fst-italic">Detail Pesanan</h3>
            <p class="lad my-3">Informasi menu pesanan Anda beserta total pembayaran</p>
            <small class=" mb-0 text-white fw-bold">#bill #smallesanan #menus</p>
        </div>
    </div>

    @if($bill)
    <div class="card text-white bg-success mb-3 mx-auto">
        <div class="card-header">Order list detail</div>
        <div class="card-body">
            <p class="bi bi-patch-check-fill fs-1"></p>
            <h5 class="card-title mb-0">Info Pembayaran</h5>
            <small class="opacity-50">At {{ $bill->updated_at->format('g:i a') }} |
                {{ $bill->updated_at->format('F d, Y') }}</small>
            <p class="card-text mt-3 fst-italic">* Pembayaran dilakukan di kasir, sesuai dengan informasi berikut.</p>
            <div class="container mt-3">
                <div class="row border border-light mb-2">
                    <div class="col-2 fw-bold">
                        No.
                    </div>
                    <div class="col-4 fw-bold">
                        Menu
                    </div>
                    <div class="col-2 fw-bold text-center">
                        Qty
                    </div>
                    <div class="col-4 fw-bold">
                        Jumlah
                    </div>
                </div>
                @php
                $total;
                @endphp
                @foreach ($bills as $pesan)
                <div class="row">
                    <div class="col-2">
                        {{ $loop->iteration }}
                    </div>
                    <div class="col-4">
                        {{ $pesan->menu }}
                    </div>
                    <div class="col-2 text-center">
                        {{ $pesan->quantity }}
                    </div>
                    <div class="col-4">
                        @rp($pesan->jumlah)
                    </div>
                </div>
                @php
                $total =+ $pesan->jumlah
                @endphp
                @endforeach
                <div class="row bg-light text-success mt-2">
                    <div class="col-8 text-end">
                        <strong>Total :</strong>
                    </div>
                    <div class="col-4">
                        <strong>@rp($sum)</strong>
                    </div>
                </div>
            </div>
        </div>
    </div>
    @else
    <div class="alert alert-warning" role="alert">
        <strong>Belum melakukan pemesanan.</strong> Lakukan pemesanan terlebih dahulu pada <a href="/kategori" class="alert-link">Kategori</a> atau melalui <a href="/welcome" class="alert-link">Menu</a>.
    </div>
    @endif
</div>
@endsection
