@extends('layouts.base')

@section('container')
<div class="container">
    <div class="px-4 py-3 mb-4 bg-light rounded-3 col-lg-8 offset-lg-2 mt-4 shadow">
        <div class="card text-white">
            <img src="https://source.unsplash.com/1200x500?{{ $menu->nama }}" class="card-img" alt="...">
            <div class="card-img-overlay">
                <a href="{{ url()->previous() }}">
                    <button type="button" class="btn btn-light fs-6 fw-bold">
                        <i class="bi bi-chevron-left"></i>
                    </button>
                </a>
            </div>
        </div>
        <div class="container-fluid">
            <h6 class="display-5 fw-bold mt-3 fs-2 lh-sm">{{ $menu->nama }}</h6>
            <p class="fw-bold color-danger fs-4 lh-sm" style="color: #198754;">@harga($menu->harga)</p>
            <p class="col-md-12 fs-5 lh-base d-flex mt-4">{{ $menu->deskripsi }}</p>
            <form action="/detailmenu" method="post">
                @csrf
                <input type="hidden" value="{{ $menu->id }}" name="menu_id">
                <input type="hidden" value="{{ $menu->harga }}" name="harga">
                {{-- iced and hot --}}
                @if ($menu->kategori->type == 'Minuman')
                <h6>Type:</h6>
                <div class="container mb-3">
                    <div class="row">
                        <div class="form-check col-2">
                            <input class="form-check-input" type="radio" name="note" id="exampleRadios1" value="Iced"
                            {{ old('note', $menu->note) == "Iced" ? "checked" : "" }}>
                            <label class="form-check-label" for="exampleRadios1">
                                Iced
                            </label>

                        </div>
                        <div class="form-check col-2">
                            <input class="form-check-input" type="radio" name="note" id="exampleRadios2" value="Hot" {{ old('note', $menu->note) == "Iced" ? "checked" : "" }}>
                            <label class="form-check-label" for="exampleRadios2">
                                Hot
                            </label>
                        </div>

                        {{-- <div class="form-check col-2">
                            <input class="form-check-input" type="radio" name="note" id="exampleRadios1" value="Iced"
                                checked>
                            <label class="form-check-label" for="exampleRadios1">
                                Iced
                            </label>

                        </div>
                        <div class="form-check col-2">
                            <input class="form-check-input" type="radio" name="note" id="exampleRadios2" value="Hot">
                            <label class="form-check-label" for="exampleRadios2">
                                Hot
                            </label>
                        </div> --}}
                    </div>
                </div>
                @endif
                {{-- Button add and min --}}
                <!-- Change the `data-field` of buttons and `name` of input field's for multiple plus minus buttons-->
                <div class="row">
                    <div class="input-group plus-minus-input col-xs-3">
                        <div class="input-group-button">
                            <button type="button" class="button hollow circle btn btn-danger" data-quantity="minus"
                                data-field="quantity">
                                <i class="bi bi-dash-lg" aria-hidden="true"></i>
                            </button>
                        </div>
                        <input class="input-group-field form-control cek mx-3" type="number" style="text-align: center;"
                            name="quantity" min="0" max="20" value="{{ old('quantity', $menu->quantity) ? $menu->quantity : "0" }}">
                        <div class="input-group-button">
                            <button type="button" class="button hollow circle btn btn-success" data-quantity="plus"
                                data-field="quantity">
                                <i class="bi bi-plus-lg"" aria-hidden=" true"></i>
                            </button>
                        </div>
                    </div>
                </div>


                {{-- <div class="row col-xs-4">
                    <div class="col-auto"><button class="btn btn-danger col-auto" onclick="decrement()"><i
                                class="bi bi-dash-lg"></i></button></div>
                    <div class="col-auto"><input class="form-control col-lg-4" style="text-align: center;" id=demoInput
                            type=number min=1 max=100></div>
                    <div class="col-auto"><button class="btn btn-success col-auto" onclick="increment()"><i
                                class="bi bi-plus-lg"></i></button></div>
                </div> --}}


                <br><button type="submit" class="btn btn-outline-primary btn-block"><i class="bi bi-bag-plus-fill"></i>
                    Keranjang</button>
            </form>
        </div>
    </div>
</div>

{{-- <script>
    function increment() {
        document
            .getElementById('demoInput')
            .stepUp();
    }

    function decrement() {
        document
            .getElementById('demoInput')
            .stepDown();
    }
</script> --}}

<script>
    jQuery(document).ready(function () {
        // This button will increment the value
        $('[data-quantity="plus"]').click(function (e) {
            // Stop acting like a button
            e.preventDefault();
            // Get the field name
            fieldName = $(this).attr('data-field');
            // Get its current value
            var currentVal = parseInt($('input[name=' + fieldName + ']').val());
            // If is not undefined
            if (!isNaN(currentVal)) {
                // Increment
                $('input[name=' + fieldName + ']').val(currentVal + 1);
            } else {
                // Otherwise put a 0 there
                $('input[name=' + fieldName + ']').val(0);
            }
        });
        // This button will decrement the value till 0
        $('[data-quantity="minus"]').click(function (e) {
            // Stop acting like a button
            e.preventDefault();
            // Get the field name
            fieldName = $(this).attr('data-field');
            // Get its current value
            var currentVal = parseInt($('input[name=' + fieldName + ']').val());
            // If it isn't undefined or its greater than 0
            if (!isNaN(currentVal) && currentVal > 0) {
                // Decrement one
                $('input[name=' + fieldName + ']').val(currentVal - 1);
            } else {
                // Otherwise put a 0 there
                $('input[name=' + fieldName + ']').val(0);
            }
        });
    });
</script>

@endsection
