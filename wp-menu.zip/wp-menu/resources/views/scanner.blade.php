<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.88.1">
    <title>{{ $title }}</title>

    <link rel="canonical" href="https://getbootstrap.com/docs/5.1/examples/sign-in/">
    {{-- <link rel="stylesheet" href="{{ asset('js/jquery.min.js') }}">
    <link rel="stylesheet" href="{{ asset('js/instascan.min.js') }}"> --}}

    <!-- Bootstrap core CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <script src="js/qrcodehtml5.min.js"></script>
    <style>
        .bd-placeholder-img {
            font-size: 1.125rem;
            text-anchor: middle;
            -webkit-user-select: none;
            -moz-user-select: none;
            user-select: none;
        }

        @media (min-width: 768px) {
            .bd-placeholder-img-lg {
                font-size: 3.5rem;
            }
        }

        .result {
            background-color: green;
            color: #fff;
            padding: 20px;
        }

        .row {
            display: flex;
        }

    </style>
    <!-- Custom styles for this template -->
    <link href="/css/signin.css" rel="stylesheet">
</head>

<body>
    <div class="container">
        <div class="card px-3 shadow border rounded border-secondary" style="width=25rem">
            <h3 class="text-center mt-4">QR-Code Scanner</h3>
            <div class="row justify-content-md-center">
                <div class="col-md-5 mt-3 text-center">
                    <div style="width:100%;" id="reader"></div>
                    <small class="" style="color: gray">Masuk dengan Kode? <a href="/">Input kode
                            akses</a></small>
                    <div style="padding:30px;">
                        <h4>SCAN RESULT</h4>
                        <form action="/" method="POST">
                            @csrf
                            <div id="result">Result Here</div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script type="text/javascript">
        function onScanSuccess(qrCodeMessage) {
            document.getElementById('result').innerHTML = '<input class="result" type="hidden" value="' +
                qrCodeMessage +
                '" name="kode_generate"> <button type="submit" class="btn btn-success">Click to Sign In</button>';
        }

        function onScanError(errorMessage) {
            //handle scan error
        }
        var html5QrcodeScanner = new Html5QrcodeScanner(
            "reader", {
                fps: 10,
                qrbox: 250
            });
        html5QrcodeScanner.render(onScanSuccess, onScanError);
    </script>
</body>

</html>
