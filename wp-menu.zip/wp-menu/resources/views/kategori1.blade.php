@extends('layouts.base')

@include('partials.navuser')

@section('container')
<div class="container">
    <div class="p-4 p-md-5 mb-4 text-white rounded bg-dark">
        <div class="col-md-10 px-0">
            <h1 class="display-4 fst-italic">Varian menu dalam kategori</h1>
            <p class="lead my-3">Pencarian menu berdasarkan kategori</p>
            <p class="lead mb-0 text-white fw-bold">#menu #kategori</p>
        </div>
    </div>
    <div class="card">
        <div class="card-body tab-content">
            <!-- Nav tabs -->
            <ul class="nav nav-tabs" role="tablist">
                @foreach ($kategori as $k)
                @if ($loop->first)
                <li class="nav-item">
                    <a class="nav-link active" data-toggle="tab"
                        href="#{{ str_replace(' ', '', $k->nama) }}">{{ $k->nama }}</a>
                </li>
                @else
                <li class="nav-item">
                    <a class="nav-link" data-toggle="tab"
                        href="#{{ str_replace(' ', '', $k->nama) }}">{{ $k->nama }}</a>
                </li>
                @endif
                @endforeach
            </ul>

            <!-- Tab panes -->
            <div class="tab-content">
                @foreach ($kategori as $k)
                @if ($loop->first)
                <div id="{{ str_replace(' ', '', $k->nama) }}" class="container tab-pane active"><br>
                    <h3>{{ $k->nama }}</h3>
                    <div class="row ">
                        @foreach ($k->menu as $item)
                        <div class="card px-0 my-3 mx-4 justify-content-center" style="width: 18rem;">
                            <img src="https://source.unsplash.com/1200x800?{{ $item->nama }}" class="card-img-top"
                                alt="{{ $item->nama }}" style="{{ ($item->status == 'empty') ? 'filter: grayscale(100%)' : ''}}">
                            <div class="card-body" style="{{ ($item->status == 'empty') ? 'background-color: #ceccbf' : ''}}">
                                <h3 class="mb-0 {{ ($item->status == 'empty') ? 'text-muted' : ''}}">{{ $item->nama }}</h3>
                                <div class="mb-1 text-muted">{{ $item->bahan }}</div>
                                <strong class="d-inline-block mb-2 text-success {{ ($item->status == 'empty') ? 'text-muted' : ''}}">@price($item->harga)</strong><br>
                                <a href="{{ ($item->status == 'empty') ? '#' : '/detailmenu/'.$item->id}}" class="text-decoration-none {{ ($item->status == 'empty') ? 'disabled text-secondary' : 'stretched-link text-primary'}}">{{ ($item->status == 'empty') ? 'Empty' : 'Detail menu'}}</a>
                            </div>
                        </div>
                        @endforeach
                    </div>
                </div>
                @else
                <div id="{{ str_replace(' ', '', $k->nama) }}" class="container tab-pane fade"><br>
                    <h3>{{ $k->nama }}</h3>
                    <div class="row">
                        @foreach ($k->menu as $item)
                        <div class="card px-0 my-3 mx-4 justify-content-center" style="width: 18rem;">
                            <img src="https://source.unsplash.com/1200x800?{{ $item->nama }}" class="card-img-top" style="{{ ($item->status == 'empty') ? 'filter: grayscale(100%)' : ''}}"
                                alt="{{ $item->nama }}">
                            <div class="card-body" style="{{ ($item->status == 'empty') ? 'background-color: #ceccbf' : ''}}">
                                <h3 class="mb-0 {{ ($item->status == 'empty') ? 'text-muted' : ''}}">{{ $item->nama }}</h3>
                                <div class="mb-1 text-muted">{{ $item->bahan }}</div>
                                <strong class="d-inline-block mb-2 text-success {{ ($item->status == 'empty') ? 'text-muted' : ''}}">@price($item->harga)</strong><br>
                                <a href="{{ ($item->status == 'empty') ? '' : '/detailmenu/'.$item->id}}" class="text-decoration-none {{ ($item->status == 'empty') ? 'disabled text-secondary' : 'stretched-link text-primary'}}">{{ ($item->status == 'empty') ? 'Empty' : 'Detail Menu'}}</a>
                            </div>
                        </div>
                        @endforeach
                    </div>
                </div>
                @endif
                @endforeach
            </div>

        </div>
    </div>
</div>



@endsection
