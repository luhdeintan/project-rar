@extends('layouts.base')

@include('partials.navadmin')

@section('container')
<div class="container">
    <div class="d-flex flex-column align-items-stretch flex-shrink-0 bg-white mt-4">
        <a href="/dashboard-admin" class="d-flex align-items-center flex-shrink-0 p-3 link-dark text-decoration-none">
            <span class="fs-5 fw-semibold"><i class="bi bi-journal-text fs-3"></i> Menu</span>
        </a>
        <nav class="border-bottom mb-5" style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">Menu</li>
                <li class="breadcrumb-item active" aria-current="page">Tabel data</li>
            </ol>
        </nav>
    </div>

    @if (session()->has('success'))

    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Berhasil!</strong> {{ session('success') }}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    @endif

    <a href="/menu/create" class="text-end d-flex mb-2 text-decoration-none">
        <button class="btn btn-success"><i class="bi bi-journal-text"></i> New Menu</button>
    </a>

    {{-- table --}}
    <div class="table-responsive-xl">
        <table class="table table-striped table-hover table-bordered">
            <thead class="table-dark">
                <tr>
                    <td>No.</td>
                    <td>Nama</td>
                    <td>Kategori</td>
                    <td>Harga</td>
                    <td>type</td>
                    <td>Aksi</td>
                </tr>
            </thead>
            <tbody>
                @foreach ($menu as $menu)
                <tr>
                    <td>{{ $loop->iteration }}</td>
                    <td>{{ $menu->nama }}</td>
                    <td>{{ $menu->kategori->nama }}</td>
                    <td>{{ $menu->harga }}</td>
                    <td>{{ $menu->type }}</td>
                    <td>
                        {{-- see --}}
                        <a href="/menu/{{ $menu->id }}" class="text-decoration-none"><button type="button"
                                class="btn btn-primary" data-bs-toggle="tooltip" data-bs-placement="top" title="see"><i
                                    class="bi bi-eye"></i></button></a>
                        {{-- edit --}}
                        <a href="/menu/{{ $menu->id }}/edit" class="text-decoration-none"><button type="button"
                                class="btn btn-warning" data-bs-toggle="tooltip" data-bs-placement="top" title="edit"><i
                                    class="bi bi-pencil"></i></button></a>
                        {{-- delete --}}
                        <form action="/menu/{{ $menu->id }}" method="post" class="d-inline">
                            @method('delete')
                            @csrf
                            <button
                                class="btn btn-danger" type="submit" title="delete" onclick="return confirm('Hapus data menu?')"><i class="bi bi-trash"></i>
                            </button>
                        </form>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</div>
@endsection
