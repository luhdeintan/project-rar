@extends('layouts.base')

@include('partials.navkasir')

@section('container')
<div class="container">
    <div class="d-flex flex-column align-items-stretch flex-shrink-0 bg-white mt-4">
        <a href="/" class="d-flex align-items-center flex-shrink-0 p-3 link-dark text-decoration-none">
            <span class="fs-5 fw-semibold"><i class="bi bi-clock-history"></i> Process</span>
        </a>
        <nav class="border-bottom" style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">Process</li>
                <li class="breadcrumb-item active" aria-current="page">Order Process List</li>
            </ol>
        </nav>

        <div class="my-3 p-3 bg-body rounded shadow-sm">
            @if (session()->has('success'))
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong>Berhasil!</strong> {{ session('success') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            @endif

            @if (!$pesanan->count())
            <div class="alert alert-warning alert-dismissible fade show" role="alert">
                <strong>Pesanan kosong.</strong> Data pesanan pelanggan belum tersedia saat ini.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            @else
            <h6 class="border-bottom pb-2 mb-0">Order List</h6>
            @foreach($pesanan as $pesan)
            <div class="d-flex text-muted pt-3">
                <input type="hidden" name="id_pesan" value="{{ $pesan->id }}">
                <button class="btn btn-success text-center" type="button" data-bs-toggle="modal"
                    data-bs-target="#finish{{ $pesan->id }}" data-bs-toggle="tooltip" data-bs-placement="top"
                    title="finish" style="height:32; width:32; padding:0; margin-right:8"><i class="bi bi-plus-lg"
                        style="margin: auto"></i></button>
                {{-- modal finish --}}
                <div class="modal fade" id="finish{{ $pesan->id }}" tabindex="-1" aria-labelledby="exampleModalLabel"
                    aria-hidden="true">
                    <form action="/process" method="post">
                        @csrf
                        <input type="hidden" name="id_pesan" value="{{ $pesan->id }}">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Ready</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                        aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    Ubah menjadi status "Ready" pesanan {{ $pesan->menu }} ?
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button>

                                    <button type="submit" class="btn btn-Success">Ready</button>

                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="pb-3 mb-0 small lh-sm border-bottom w-100">
                    <div class="d-flex justify-content-between mb-2">
                        <strong class="text-dark">{{ $pesan->menu }}
                            <span class="badge rounded-pill bg-secondary">{{ $pesan->quantity }}</span>
                            @if($pesan->note != 'none')
                            <span
                                class="strong d-inline px-3 badge {{ $pesan->note == "Hot" ? "bg-danger" : "bg-primary" }}">{{ $pesan->note }}</span>
                            @endif
                        </strong>
                        <a href="#" class="text-danger" data-bs-toggle="modal"
                            data-bs-target="#exampleModal{{ $pesan->id }}" data-bs-toggle="tooltip"
                            data-bs-placement="top">Cancle</a>

                        {{-- modal delete --}}
                        <div class="modal fade" id="exampleModal{{ $pesan->id }}" tabindex="-1"
                            aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <form action="/process/{{ $pesan->id }}" method="post">
                                @method('put')
                                @csrf
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="exampleModalLabel">Batalkan Pesanan?</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            Berikan konfirmasi Anda mengapa membatalkan
                                            <strong>{{ $pesan->menu }}</strong> : <br>
                                            <div class="form-group mt-2">
                                                {{-- <label for="exampleFormControlTextarea1">Example textarea</label> --}}
                                                <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"
                                                    name="message">menu habis</textarea>
                                                <small class="text-danger">*wajib mengisi</small>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-light"
                                                data-bs-dismiss="modal">Close</button>
                                            <button type="submit" class="btn btn-danger">Send</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>

                    </div>
                    <span class="d-block">Time : <span>{{ $pesan->updated_at->format('g:i a') }}</span> | <span>Meja
                            {{ $pesan->kode->meja->no_meja }} <i class="bi bi-dash-lg"></i>
                            {{ $pesan->kode->meja->lokasi }}</span></span>
                </div>
            </div>
            @endforeach
            {{-- <small class="d-block text-end mt-3">
                <a href="#">All suggestions</a>
            </small> --}}
            @endif
        </div>
    </div>
</div>
@endsection
