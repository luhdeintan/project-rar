@extends('layouts.base')

@include('partials.navkasir')

@section('container')
<div class="container">
    <div class="d-flex flex-column align-items-stretch flex-shrink-0 bg-white mt-4">
        <a href="/" class="d-flex align-items-center flex-shrink-0 p-3 link-dark text-decoration-none">
            <span class="fs-5 fw-semibold"><i class="bi bi-receipt fs-3"></i> History</span>
        </a>
        <nav class="border-bottom" style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">History</li>
                <li class="breadcrumb-item active" aria-current="page">Orders Today</li>
            </ol>
        </nav>

        <div class="mb-5 mt-3 p-3 bg-body rounded shadow-sm responsive">

            <div class="btn-group mb-5" role="group" aria-label="Basic mixed styles example" style="width: 19em">
                <button type="button" id="btn-1" data-showbutton="1" class="btn btn-success">Success</button>
                <button type="button" id="btn-2" data-showbutton="2" class="btn btn-danger">Canceled</button>
            </div>

            <div data-button="1" class="mb-5">
                @if (!$historySuccess->count())
                <div class="alert alert-warning alert-dismissible fade show" role="alert">
                    <strong>History Success kosong.</strong> Data history belum tersedia saat ini.
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                @else
                <h6 class="border-bottom pb-2 mb-0">Success Order</h6>
                @foreach($historySuccess as $history)
                <div class="d-flex text-muted pt-3">
                    {{-- Success Sign --}}
                    <h2 class="bi bi-square-fill text-success" style="height:42; margin-right:8"></h2>

                    <div class="pb-3 mb-0 small lh-sm border-bottom w-100">
                        <div class="d-flex justify-content-between mb-2">
                            <div class="pe-2">
                                <strong class="text-dark" style="line-height: 1.6;">
                                    {{ $history->menu }}
                                </strong>
                            </div>
                            <span class="d-block"><span>{{ $history->kode->meja->no_meja }} | <span>{{ $history->updated_at->format('g:i a') }}</span></span>
                            </span>

                        </div>
                        <span class="badge rounded-pill bg-secondary">{{ $history->quantity }}</span>
                        @if($history->note != 'none')
                        <span class="strong d-inline px-3 badge bg-secondary">{{ $history->note }}</span>
                        @endif
                    </div>
                </div>
                @endforeach
                @endif
            </div>

            <div data-button="2" class="mb-5">
                @if (!$historyCanceled->count())
                <div class="alert alert-warning alert-dismissible fade show" role="alert">
                    <strong>History Success kosong.</strong> Data history belum tersedia saat ini.
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                @else
                <h6 class="border-bottom pb-2 mb-0">Canceled Order</h6>
                @foreach($historyCanceled as $history)
                <div class="d-flex text-muted pt-3">
                    {{-- Canceled Sign --}}
                    <h2 class="bi bi-square-fill text-danger" style="height:42; margin-right:8"></h2>

                    <div class="pb-3 mb-0 small lh-sm border-bottom w-100">
                        <div class="d-flex justify-content-between mb-2">
                            <div class="pe-2">
                                <strong class="text-dark my-auto" style="line-height: 1.6;">
                                    {{ $history->menu }}
                                </strong>
                            </div>
                            <span class="d-block my-auto"><span>{{ $history->kode->meja->no_meja }} | <span>{{ $history->updated_at->format('g:i a') }}</span></span>
                            </span>
                        </div>
                        <span class="badge rounded-pill bg-secondary">{{ $history->quantity }}</span>
                        @if($history->note != 'none')
                        <span class="strong d-inline px-3 badge bg-secondary">{{ $history->note }}</span>
                        @endif
                    </div>
                </div>
                @endforeach
                @endif
            </div>
        </div>
    </div>
</div>

<script>
    $('#btn-1,#btn-2').click(function () {
        var btn = $(this).data("showbutton");
        showButtonText(btn);
    });

    function showButtonText(btn) {
        // reset
        $('.text').hide();
        $('[data-button]').hide();
        $('[data-showbutton]').removeClass('clicked');

        // only show the selected
        $('[data-showbutton=' + btn + ']').addClass('clicked');
        $('[data-button=' + btn + ']').show();
    }
</script>


@endsection
