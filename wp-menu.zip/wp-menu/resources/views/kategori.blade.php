@extends('layouts.base')

@include('partials.navuser')

@section('container')
<div class="container">
    <div class="p-4 p-md-5 mb-4 text-white rounded bg-dark">
        <div class="col-md-10 px-0">
            <h1 class="display-6 fst-italic">Various Categories</h1>
            <p class=" my-3">Pencarian menu berdasarkan kategori</p>
            <small class=" mb-0 text-white fw-bold">#menu #kategori</small>
        </div>
    </div>
    <div class="card">
        <div class="card-body tab-content">
            <!-- Nav tabs -->
            <ul class="nav nav-tabs" role="tablist">
                @foreach ($kategori as $k)
                @if ($loop->first)
                <li class="nav-item">
                    <a class="nav-link active" data-toggle="tab"
                        href="#{{ str_replace(' ', '', $k->nama) }}">{{ $k->nama }}</a>
                </li>
                @else
                <li class="nav-item">
                    <a class="nav-link" data-toggle="tab"
                        href="#{{ str_replace(' ', '', $k->nama) }}">{{ $k->nama }}</a>
                </li>
                @endif
                @endforeach
            </ul>

            <!-- Tab panes -->
            <div class="tab-content">
                @foreach ($kategori as $k)
                @if ($loop->first)
                <div id="{{ str_replace(' ', '', $k->nama) }}" class="container tab-pane active" style="padding-left: 0px"><br>
                    <h3 style="margin-left: 12px">{{ $k->nama }}</h3>
                    <div class="row" style="padding-right: 38px;">
                        @foreach ($k->menu as $item)
                        @if ($item->active == 1)
                        <a href="{{ ($item->status == 'empty') ? '#' : '/detailmenu/'.$item->id}}"
                            class="text-decoration-none {{ ($item->status == 'empty') ? 'disabled text-secondary' : 'text-primary'}}">

                            <div class="card shadow px-0 my-3 mx-4 justify-content-center d-flex flex-column-reverse"
                                style="{{ ($item->status == 'empty') ? 'background-color: #ceccbf' : ''}}">
                                <div class="d-flex flex-row pe-2 ps-3" style="margin-left: 0px;">
                                    <div>
                                        <img src="{{ asset('menu-img/'. $item->gambar) }}"
                                            class="card-img-top mt-3" alt="{{ $item->nama }}"
                                            style="{{ ($item->status == 'empty') ? 'filter: grayscale(100%)' : ''}}; width:64px; height:64px; object-fit: cover; border-radius:5%;">
                                    </div>
                                    <div class=" media-body px-3" style="width:100%; padding-top: 10px; padding-bottom:10px">
                                        <h4 class="mb-0 {{ ($item->status == 'empty') ? 'text-muted' : ''}}">
                                            {{ $item->nama }}</h4>
                                        <div class="mb-1 text-muted">{{ $item->bahan }}</div>
                                        <strong
                                            class="d-inline-block mb-2 text-success {{ ($item->status == 'empty') ? 'text-muted' : ''}}">@price($item->harga)</strong><br>
                                        <a href="{{ ($item->status == 'empty') ? '#' : '/detailmenu/'.$item->id}}"
                                            class="text-decoration-none {{ ($item->status == 'empty') ? 'disabled text-secondary' : 'text-primary'}}">{{ ($item->status == 'empty') ? 'Empty' : 'Detail menu'}}</a>
                                    </div>
                                </div>
                            </div>
                        </a>
                        @endif
                        @endforeach
                    </div>
                </div>
                @else
                <div id="{{ str_replace(' ', '', $k->nama) }}" class="container tab-pane fade" style="padding-left: 0px"><br>
                    <h3 style="margin-left: 12px">{{ $k->nama }}</h3>
                    <div class="row" style="padding-right: 38px;">
                        @foreach ($k->menu as $item)
                        @if ($item->active == 1)
                        <a href="{{ ($item->status == 'empty') ? '#' : '/detailmenu/'.$item->id}}"
                            class="text-decoration-none {{ ($item->status == 'empty') ? 'disabled text-secondary' : 'text-primary'}}">

                            <div class="card shadow px-0 my-3 mx-4 justify-content-center d-flex flex-column-reverse"
                                style="{{ ($item->status == 'empty') ? 'background-color: #ceccbf' : ''}}">
                                <div class="d-flex flex-row px-3">
                                    <div>
                                        <img src="{{ asset('menu-img/'. $item->gambar) }}"
                                            class="card-img-top mt-3" alt="{{ $item->nama }}"
                                            style="{{ ($item->status == 'empty') ? 'filter: grayscale(100%)' : ''}}; width:64px; height:64px; object-fit: cover; border-radius:5%">
                                    </div>
                                    <div class=" media-body px-3" style="width:100%; padding-top: 10px; padding-bottom:10px">
                                        <h4 class="mb-0 {{ ($item->status == 'empty') ? 'text-muted' : ''}}">
                                            {{ $item->nama }}</h4>
                                        <div class="mb-1 text-muted">{{ $item->bahan }}</div>
                                        <strong
                                            class="d-inline-block mb-2 text-success {{ ($item->status == 'empty') ? 'text-muted' : ''}}">@price($item->harga)</strong><br>
                                        <a href="{{ ($item->status == 'empty') ? '#' : '/detailmenu/'.$item->id}}"
                                            class="text-decoration-none {{ ($item->status == 'empty') ? 'disabled text-secondary' : 'text-primary'}}">{{ ($item->status == 'empty') ? 'Empty' : 'Detail menu'}}</a>
                                    </div>
                                </div>
                            </div>
                        </a>
                        @endif
                        @endforeach
                    </div>
                </div>
                @endif
                @endforeach
            </div>

        </div>
    </div>
</div>
@endsection
