<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
        <p class="navbar-brand my-auto">Warung Pejalan | </p>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link {{ $active == 'dashboard' ? 'active' : '' }}" aria-current="page" href="/dashboard">Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link {{ $active == 'process' ? 'active' : '' }}" href="/process">Process</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link {{ $active == 'profile' ? 'active' : '' }}" href="/profileupdate">Profile</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link {{ $active == 'menu' ? 'active' : '' }}" href="/menus">Menu</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link {{ $active == 'history' ? 'active' : '' }}" href="/history">History</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link {{ $active == 'qrcode' ? 'active' : '' }}" href="/qrcode"><i
                            class="bi bi-qr-code-scan"></i> QR-Code</a>
                </li>
            </ul>
            <form action="/logout" method="get" class="d-flex my-auto">
                @csrf
                <button class="btn btn-outline-success" type="submit">Logout</button>
            </form>
        </div>
    </div>
</nav>
