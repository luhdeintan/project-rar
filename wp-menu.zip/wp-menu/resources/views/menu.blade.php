@extends('layouts.base')

@include('partials.navuser')

@section('container')
<main class="container">
    <div class="p-4 p-md-5 mb-4 text-white rounded bg-dark">
        <div class="col-md-10 px-0">
            <h3 class="display-6 fst-italic">All Menu Variants</h3>
            <p class=" my-3">Pilihan menu menarik untuk menemani waktu bersantai!</p>
            <small class="mb-0 text-white fw-bold">#menu #coffee #drink #snack</small>
        </div>
    </div>

    <div class="row justify-content-center">
        <div class="col-md-8">
            <form action="/welcome" method="get">
                <div class="input-group mb-3">
                    <input type="text" class="form-control" placeholder="Cari menu.." name="search" value="{{ request('search') }}" style="height: 30px">
                    <div class="input-group-append">
                        <button class="btn btn-dark bi bi-search" type="submit"></button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <div>
        {{-- jika ada data search terisi --}}
        @if ($menu != null)
        <div class="row px-3 mb-2 justify-content-center mb-6">
            @foreach ($menu as $menus)
            <a href="{{ ($menus->status == 'empty') ? '#' : '/detailmenu/'.$menus->id}}"
                class="text-decoration-none {{ ($menus->status == 'empty') ? 'disabled text-secondary' : 'text-primary'}}">
                <div class="card shadow px-0 py-0 my-3 mx-4 justify-content-center d-flex flex-column-reverse"
                    style="{{ ($menus->status == 'empty') ? 'background-color: #ceccbf' : ''}}">
                    <div class="d-flex flex-row px-3">
                        <div class="pt-2">
                            <img src="menu-img/{{ $menus->gambar }}" class="card-img-top my-2"
                                style="{{ ($menus->status == 'empty') ? 'filter: grayscale(100%)' : ''}}; width:64px; height:64px; object-fit: cover; border-radius:5%"
                                alt="{{ $menus->nama }}">
                        </div>
                        <div class="px-3 py-2" style="width:100%">
                            <h3 class="mb-0 {{ ($menus->status == 'empty') ? 'text-muted' : ''}}">{{ $menus->nama }}
                            </h3>
                            <div class="mb-1 text-muted">{{ $menus->bahan }}</div>
                            <strong
                                class="d-inline-block mb-2 text-success {{ ($menus->status == 'empty') ? 'text-muted' : ''}}">@currency($menus->harga)</strong><br>
                            <a href="{{ ($menus->status == 'empty') ? '#' : '/detailmenu/'.$menus->id}}"
                                class="text-decoration-none {{ ($menus->status == 'empty') ? 'disabled text-secondary' : 'text-primary'}}">{{ ($menus->status == 'empty') ? 'Empty' : 'Ready'}}</a>
                        </div>
                    </div>
                </div>
            </a>
            @endforeach
        </div>
        @endif
        {{-- else --}}
        @foreach ($kategori as $k)
        <h3 class="mx-3">{{ $k->nama }}</h3>
        <hr>
        <div class="row px-3 mb-2 justify-content-center mb-6">
            @foreach ($k->menu as $menus)
            @if ($menus->active == 1)
            <a href="{{ ($menus->status == 'empty') ? '#' : '/detailmenu/'.$menus->id}}"
                class="text-decoration-none {{ ($menus->status == 'empty') ? 'disabled text-secondary' : 'text-primary'}}">
                <div class="card shadow px-0 py-0 my-3 mx-4 justify-content-center d-flex flex-column-reverse"
                    style="{{ ($menus->status == 'empty') ? 'background-color: #ceccbf' : ''}}">
                    <div class="d-flex flex-row px-3">
                        <div class="pt-2">
                            <img src="menu-img/{{ $menus->gambar }}" class="card-img-top my-2"
                                style="{{ ($menus->status == 'empty') ? 'filter: grayscale(100%)' : ''}}; width:64px; height:64px; object-fit: cover; border-radius:5%"
                                alt="{{ $menus->nama }}">
                        </div>
                        <div class="px-3 py-2" style="width:100%">
                            <h3 class="mb-0 {{ ($menus->status == 'empty') ? 'text-muted' : ''}}">{{ $menus->nama }}
                            </h3>
                            <div class="mb-1 text-muted">{{ $menus->bahan }}</div>
                            <strong
                                class="d-inline-block mb-2 text-success {{ ($menus->status == 'empty') ? 'text-muted' : ''}}">@currency($menus->harga)</strong><br>
                            <a href="{{ ($menus->status == 'empty') ? '#' : '/detailmenu/'.$menus->id}}"
                                class="text-decoration-none {{ ($menus->status == 'empty') ? 'disabled text-secondary' : 'text-primary'}}">{{ ($menus->status == 'empty') ? 'Empty' : 'Ready'}}</a>
                        </div>
                    </div>
                </div>
            </a>
            @endif
            @endforeach
        </div>
        @endforeach
    </div>
</main>
@endsection
